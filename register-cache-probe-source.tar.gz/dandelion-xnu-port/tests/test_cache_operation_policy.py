# SPDX-License-Identifier: MIT
import unittest
from cache_operation_policy import classify_dc
class Policy(unittest.TestCase):
 def test_zero_is_not_skipped(self):self.assertEqual(classify_dc('zva, x0'),'stop_memory_write')
 def test_unknown_is_not_skipped(self):self.assertEqual(classify_dc('gzva, x0'),'stop_unknown')
 def test_empty_is_not_skipped(self):self.assertEqual(classify_dc(''),'stop_unknown')
 def test_maintenance(self):
  for op in ['ivac','isw','csw','cisw','cvac','cvau','civac']:self.assertEqual(classify_dc(op+', x2'),'coherent_maintenance')
if __name__=='__main__':unittest.main()
