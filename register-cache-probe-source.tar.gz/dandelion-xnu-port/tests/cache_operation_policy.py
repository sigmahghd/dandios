# SPDX-License-Identifier: MIT
"""Coherent CPU model policy; DC ZVA is a RAM write, never a no-op."""
_MAINTENANCE={'ivac','isw','csw','cisw','cvac','cvau','civac'}
def classify_dc(operands):
 op=operands.split(',',1)[0].strip().lower()
 return 'coherent_maintenance' if op in _MAINTENANCE else 'stop_memory_write' if op=='zva' else 'stop_unknown'
