#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Complete raw Image -> copy -> EL2/EL1h handoff CPU MODEL -> bounded XNU bootstrap.
No phone interaction. ERET, system registers, barriers/cache/TLB effects are MODELED,
not real CPU validation. Default stops before MMU; opt-in virtual probe uses
bounded shared-backing software aliases. Hardware MMU stays off. Never invent MMIO.
"""
import argparse,hashlib,io,json,re,struct,sys
from collections import deque
from bisect import bisect_right
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import *
import unicorn.arm64_const as A
from test_lk_fdt import fdt_fixture
from test_real_kernel_fixture import check_mapping
from check_bootstrap_tables import check as check_tables
from cache_operation_policy import classify_dc
from virtual_bootstrap_memory import OwnedMemory,install as install_aliases

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--virtual-bootstrap',action='store_true');p.add_argument('--kernel',type=Path);a=p.parse_args()
 if a.out.exists():p.error('refusing existing report')
 layout=json.loads((a.build/'layout.json').read_text());raw=(a.build/'MODEL-ONLY-NOT-FOR-PHONE-handoff.Image').read_bytes()
 assert layout['handoff_model_only'] and not layout['prepare_only'] and not layout['flashable'] and not layout['hardware_tested']
 assert hashlib.sha256(raw).hexdigest()==layout['image_sha256']
 sym=layout['symbols'];head=sym['_head'];end=sym['_image_end'];base=sym['_kernel_window_start'];window=sym['_kernel_window_end']-base
 payload=raw[sym['_payload_start']-head:sym['_payload_end']-head];assert hashlib.sha256(payload).hexdigest()==layout['payload_sha256']
 elf=ELFFile(io.BytesIO((a.build/'handoff-model.elf').read_bytes()));md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
 assert elf.header['e_entry']==head and len(raw)==end-head
 audit=[];exec_ranges=[];erets=[]
 for sec in elf.iter_sections():
  if not sec['sh_flags']&4:continue
  data=sec.data()[:4] if sec.name=='.head' else sec.data();insns=list(md.disasm(data,sec['sh_addr']));assert sum(i.size for i in insns)==len(data)
  for i in insns:
   assert i.mnemonic not in ['br','blr'] and not re.search(r'\b[vqdshb][0-9]+\b',i.op_str),(hex(i.address),i.mnemonic,i.op_str)
   assert not re.match(r'^(?:cas|swp|ldadd|stadd|ldapr|pac|aut|retaa|retab|sha|aes)',i.mnemonic)
   if i.mnemonic=='eret':erets.append(i.address)
  exec_ranges.append((sec['sh_addr'],sec['sh_addr']+len(data)));audit.append({'section':sec.name,'instruction_count':len(insns)})
 assert erets==[sym['handoff_eret']]
 for sec in elf.iter_sections():
  if not sec['sh_flags']&4:continue
  for i in md.disasm(sec.data()[:4] if sec.name=='.head' else sec.data(),sec['sh_addr']):
   if i.mnemonic in ['b','bl','cbz','cbnz','tbz','tbnz'] or i.mnemonic.startswith('b.'):
    assert any(lo<=i.operands[-1].imm<hi for lo,hi in exec_ranges),('branch escapes loader',i)
 kernel_symbols={}
 if a.virtual_bootstrap:
  if not a.kernel:p.error('--virtual-bootstrap requires exact --kernel')
  kb=a.kernel.read_bytes();assert hashlib.sha256(kb).hexdigest()==layout['kernel_sha256']
  pos=32
  for _ in range(struct.unpack_from('<I',kb,16)[0]):
   cmd,n=struct.unpack_from('<II',kb,pos)
   if cmd==2:
    so,ns,st,ss=struct.unpack_from('<4I',kb,pos+8);assert ns<1000000 and so+ns*16<=len(kb) and st+ss<=len(kb)
    for j in range(ns):
     no,typ,section,desc,value=struct.unpack_from('<IBBHQ',kb,so+j*16)
     if no<ss and typ&0xe==0xe:
      endname=kb.find(b'\0',st+no,st+ss)
      if endname>=0:kernel_symbols[kb[st+no:endname].decode('utf8',errors='replace')]=value
   pos+=n
  assert '_arm_init' in kernel_symbols and '_panic' in kernel_symbols
 symbol_addresses=sorted((v,k) for k,v in kernel_symbols.items());symbol_values=[v for v,k in symbol_addresses]
 def symbol_at(pc):
  i=bisect_right(symbol_values,pc)-1
  return ({'symbol':symbol_addresses[i][1],'offset':pc-symbol_addresses[i][0]} if i>=0 else {})
 cases=[]
 def run(name,*,bootstrap=False):
  u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);backing=OwnedMemory(head,raw);backing.map(u,head,head,len(raw),UC_PROT_READ|UC_PROT_WRITE);initial=bytearray(raw)
  if name=='corrupt_payload':initial[sym['_payload_start']-head]^=1
  u.mem_write(head,bytes(initial));u.mem_protect(head,0x10000,UC_PROT_READ|UC_PROT_WRITE|UC_PROT_EXEC)
  u.mem_protect(sym['_payload_start'],(layout['payload_bytes']+4095)&~4095,UC_PROT_READ)
  u.mem_protect(sym['image_el1_vectors'],4096,UC_PROT_READ|UC_PROT_EXEC)
  fd=fdt_fixture(include=name!='missing_mblock')
  if name=='bad_fdt_magic':fd[0]=0
  u.mem_map(0x47880000,0x80000,UC_PROT_READ|UC_PROT_WRITE);u.mem_write(0x47880000,bytes(fd));u.mem_protect(0x47880000,0x80000,UC_PROT_READ)
  cpu={'midr_el1':0x410fd034,'currentel':8,'sctlr_el2':0x30c50830,'hcr_el2':0,'mpidr_el1':0x80000000,'cntfrq_el0':13000000,'icc_sre_el2':0}
  trace=[];stop=[];bridge_mem=[];kernel_trace=[];kernel_writes=[];entry_verified=[];fault=[];bridge_hooks=[];tables=[];instruction_count=[0];virtual_state=[];milestones=[];post_trace=[];counter_reads=[];synthetic_counter=[1];tail=deque(maxlen=32)
  regs=lambda n:getattr(A,'UC_ARM64_REG_'+n.upper())
  def val(n):return 0 if n=='xzr' else (int(n[1:],0) if n.startswith('#') else u.reg_read(regs(n)))
  def skip(pc):u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  reads={sym['image_read_el']:('x19','currentel'),sym['image_read_sctlr']:('x20','sctlr_el2'),sym['image_read_hcr']:('x21','hcr_el2'),sym['image_read_mpidr']:('x9','mpidr_el1'),sym['image_read_cntfrq']:('x22','cntfrq_el0'),sym['stage0_gate_el']:('x3','currentel'),sym['stage0_gate_sctlr']:('x3','sctlr_el2'),sym['stage0_gate_hcr']:('x3','hcr_el2')}
  def code(uc,pc,size,user):
   if pc in [sym['image_wait'],sym['handoff_park']]:stop.append('prepare_rejected' if pc==sym['image_wait'] else 'handoff_rejected');u.emu_stop();return
   if pc==sym['dandelion_enter_xnu_el2']:
    bridge_hooks.append(u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,bridge_guard))
    # Fault injection happens only at the actual bridge call, after real copy.
    if name=='bridge_wrong_el':cpu['currentel']=4
    if name=='bridge_stage2':cpu['hcr_el2']=1
    if name.startswith('bridge_sctlr_'):cpu['sctlr_el2']|=1<<int(name.rsplit('_',1)[1])
    for key,regid,value in [('entry_null',A.UC_ARM64_REG_X0,0),('entry_unaligned',A.UC_ARM64_REG_X0,3),('args_null',A.UC_ARM64_REG_X1,0),('args_unaligned',A.UC_ARM64_REG_X1,3),('stack_null',A.UC_ARM64_REG_X2,0),('stack_unaligned',A.UC_ARM64_REG_X2,3),('vectors_null',A.UC_ARM64_REG_X3,0),('vectors_unaligned',A.UC_ARM64_REG_X3,3)]:
     if name==key:u.reg_write(regid,value)
   if name=='missing_midr':cpu.pop('midr_el1',None)
   if pc in reads:
    dst,src=reads[pc];u.reg_write(regs(dst),cpu[src]);skip(pc);return
   ins=next(md.disasm(bytes(u.mem_read(pc,4)),pc));op=ins.mnemonic
   if op=='mrs':
    dst,src=ins.op_str.split(', ');v=cpu[src]
    if src=='icc_sre_el2' and name.startswith('locked_sre_'):v=int(name.rsplit('_',1)[1])
    u.reg_write(regs(dst),v);trace.append(['read',src,v]);skip(pc)
   elif op=='msr':
    dst,src=ins.op_str.split(', ');assert dst in ['daifset','spsel','vbar_el2','hcr_el2','vttbr_el2','cptr_el2','mdcr_el2','cnthctl_el2','cntvoff_el2','cntkctl_el1','icc_sre_el2','sctlr_el1','cpacr_el1','vbar_el1','sp_el1','cntv_ctl_el0','cntp_ctl_el0','elr_el2','spsr_el2'],('unexpected bridge control write',dst);cpu[dst]=val(src);trace.append(['write',dst,cpu[dst]]);skip(pc)
   elif op in ['dsb','isb','ic','tlbi']:
    trace.append([op,ins.op_str]);skip(pc)
   elif op=='eret':
    assert pc==sym['handoff_eret']
    rec=struct.unpack('<18Q',u.mem_read(sym['image_record'],144));entry,args,stack,vectors=rec[14:18]
    for key,value in {'elr_el2':entry,'spsr_el2':0x3c5,'sp_el1':stack,'vbar_el1':vectors,'hcr_el2':1<<31,'vttbr_el2':0,'cptr_el2':0x33ff,'mdcr_el2':0,'sctlr_el1':0x30d00800,'cpacr_el1':0,'cnthctl_el2':3,'cntvoff_el2':0,'cntv_ctl_el0':0,'cntp_ctl_el0':0,'cntkctl_el1':0,'icc_sre_el2':9}.items():assert cpu[key]==value,(name,key,cpu)
    assert [u.reg_read(regs('x'+str(i))) for i in range(4)]==[args,0,0,0]
    digest=check_mapping(bytes(u.mem_read(base,window)),payload,layout['payload_report'],(entry,args,args+4096),fill=0)
    entry_verified.append({'entry':entry,'bootargs':args,'el1_stack':stack,'el1_vectors':vectors,'kernel_window_sha256':digest})
    if not bootstrap:stop.append('eret_boundary_verified');u.emu_stop();return
    # Explicit modeled exception return, NOT execution of hardware ERET.
    # Execute actual copied XNU instructions with only its file-backed text executable.
    for seg in layout['payload_report']['segments']:
     if seg['initprot']&4:u.mem_protect(base+seg['va']-layout['payload_report']['virtual_base'],seg['size'],UC_PROT_READ|UC_PROT_EXEC)
    for handle in bridge_hooks:u.hook_del(handle)
    bridge_hooks.clear();u.hook_add(UC_HOOK_MEM_WRITE,kwrite)
    cpu['currentel']=4;u.reg_write(A.UC_ARM64_REG_SP,stack);u.reg_write(A.UC_ARM64_REG_PC,entry)
  u.hook_add(UC_HOOK_CODE,code,begin=sym['image_start'],end=sym['image_start_asm_end'])
  u.hook_add(UC_HOOK_CODE,code,begin=sym['dandelion_stage0_fdt_gate'],end=sym['stage0_gate_fail']+4)
  u.hook_add(UC_HOOK_CODE,code,begin=sym['dandelion_enter_xnu_el2'],end=sym['handoff_park']+4)
  def bridge_guard(uc,access,address,size,value,user):
   pc=u.reg_read(A.UC_ARM64_REG_PC)
   if sym['dandelion_enter_xnu_el2']<=pc<=sym['handoff_park']+4:bridge_mem.append((address,size));raise AssertionError('bridge data dereference')
  def kernel_code(uc,pc,size,user):
   if not bootstrap or not entry_verified:raise AssertionError('unexpected XNU fetch')
   ins=next(md.disasm(bytes(u.mem_read(pc,4)),pc));op=ins.mnemonic
   if re.search(r'\b[vqdshb][0-9]+\b',ins.op_str) and (cpu.get('cpacr_el1',0)>>20)&3!=3:
    stop.append('fp_before_enable');fault.append({'pc':hex(pc),'instruction':ins.mnemonic+' '+ins.op_str});u.emu_stop();return
   instruction_count[0]+=1;tail.append([hex(pc),op,ins.op_str])
   if instruction_count[0]>2000000:stop.append('instruction_budget');u.emu_stop();return
   if virtual_state:
    if (len(post_trace)<80 or op in ['mrs','msr','ret']) and len(post_trace)<256:post_trace.append([hex(pc),op,ins.op_str])
    for milestone in ['_arm_init','_PE_init_platform','_cpu_data_init','_ml_parse_cpu_topology','_kernel_startup_bootstrap','_cpu_bootstrap','_cpu_init','_arm_vm_init','_panic']:
     if pc==kernel_symbols.get(milestone):
      milestones.append(milestone)
      if milestone in ['_panic','_arm_vm_init']:
       stop.append('kernel_panic_entry' if milestone=='_panic' else 'before_arm_vm_init');u.emu_stop();return
   if (len(kernel_trace)<40 or op in ['mrs','msr','ret','br','blr']) and len(kernel_trace)<256:kernel_trace.append([hex(pc),op,ins.op_str])
   if op=='msr':
    dst,src=ins.op_str.split(', ');value=val(src)
    if dst=='sctlr_el1' and value&1 and not virtual_state:
     vb=layout['payload_report']['virtual_base'];entry=entry_verified[0]['entry'];args=entry_verified[0]['bootargs']
     def physical(va):return base+va-vb
     points=[('next_physical_instruction',pc+4,pc+4),('kernel_entry_va',vb+entry-base,entry),('bootargs_va',vb+args-base,args),('exception_vectors_va',cpu['vbar_el1'],physical(cpu['vbar_el1'])),('arm_init_lr',val('x30'),physical(val('x30'))),('interrupt_stack',val('sp')-16,physical(val('sp')-16))]
     def read_table(pa,n):
      if not base<=pa or pa+n>base+window:raise ValueError('page table pointer outside owned window')
      return bytes(u.mem_read(pa,n))
     tables.append(check_tables(read_table,cpu,points))
     if not a.virtual_bootstrap:stop.append('before_xnu_mmu_enable');u.emu_stop();return
     assert tables[-1]['all_match']
     print('Installing software stage1 aliases:',name,flush=True)
     def tamper(pa,data):
      target=tables[-1]['points'][1]['path'][-1][0]
      if pa==target:return struct.pack('<Q',struct.unpack('<Q',data)[0]&~1)
      return data
     try:state=install_aliases(u,backing,head=head,end=end,base=base,size=window,vb=vb,cpu=cpu,mutate=tamper if name=='tampered_table' else None)
     except ValueError as error:
      if name!='tampered_table':raise
      stop.append('alias_validation_rejected');fault.append({'error':str(error)});u.emu_stop();return
     print('Aliases installed:',state['pages'],flush=True)
     virtual_state.append(state)
     if name=='deny_virtual_exec':u.mem_protect(val('x30')&~4095,4096,UC_PROT_READ|UC_PROT_WRITE)
     if name=='omit_bootargs_alias':u.mem_unmap((vb+args-base)&~4095,4096)
     cpu[dst]=value;trace.append(['software_stage1_aliases_installed',state['pages']]);skip(pc);return
    if virtual_state and dst in ['ttbr0_el1','ttbr1_el1','tcr_el1','sctlr_el1']:
     stop.append('translation_state_change');fault.append({'pc':hex(pc),'register':dst,'value':value});u.emu_stop();return
    if dst not in ['oslar_el1','daifset','vbar_el1','tpidrro_el0','tpidr_el0','tpidr_el1','contextidr_el1','cntkctl_el1','spsel','tcr_el1','ttbr0_el1','ttbr1_el1','mair_el1','cpacr_el1','sctlr_el1']:
     stop.append('unsupported_xnu_system_write');fault.append({'pc':hex(pc),'register':dst,'value':value});u.emu_stop();return
    cpu[dst]=value
    if name=='fp_stays_disabled' and dst=='cpacr_el1':cpu[dst]=0
    trace.append(['xnu_write',dst,value]);skip(pc)
   elif op=='mrs':
    dst,src=ins.op_str.split(', ')
    if src in ['cntvct_el0','cntpct_el0'] and name=='virtual_with_counter_model':
     # Explicit synthetic monotonic 13MHz timer profile; no interrupt delivery.
     # A read advances by 13000 ticks (1ms), not emulator wall-clock time.
     cpu[src]=synthetic_counter[0];synthetic_counter[0]+=13000
     if len(counter_reads)<16:counter_reads.append([src,cpu[src]])
    if src not in cpu:stop.append('unsupported_xnu_system_read');fault.append({'pc':hex(pc),'register':src});u.emu_stop();return
    u.reg_write(regs(dst),cpu[src]);skip(pc)
   elif op in ['at','sys','sysl','hvc','smc','svc','eret','brk','wfi','wfe']:
    stop.append('unsupported_privileged_instruction');fault.append({'pc':hex(pc),'instruction':op+' '+ins.op_str});u.emu_stop();return
   elif op=='dc':
    policy=classify_dc(ins.op_str)
    if policy!='coherent_maintenance':
     stop.append('unsupported_cache_memory_effect');fault.append({'pc':hex(pc),'instruction':op+' '+ins.op_str,'policy':policy});u.emu_stop();return
    trace.append(['xnu_coherent_cache_maintenance',ins.op_str]);skip(pc)
   elif op in ['dsb','isb','ic','tlbi']:
    trace.append(['xnu_'+op,ins.op_str]);skip(pc)
  if bootstrap:
   u.hook_add(UC_HOOK_CODE,kernel_code,begin=base,end=base+window-1)
   if a.virtual_bootstrap:u.hook_add(UC_HOOK_CODE,kernel_code,begin=layout['payload_report']['virtual_base'],end=layout['payload_report']['virtual_base']+window-1)
   def kwrite(uc,access,address,size,value,user):
    pc=u.reg_read(A.UC_ARM64_REG_PC)
    if virtual_state:
     alias=virtual_state[0]['aliases'].get(address&~4095)
     if alias is None or size>4096-(address&4095):
      stop.append('write_outside_alias');u.emu_stop();return
     pa=alias['pa']+(address&4095)
     if pa&~4095 in virtual_state[0]['table_pages']:
      stop.append('translation_table_write');fault.append({'pc':hex(pc),'pa':hex(pa)});u.emu_stop();return
     kernel_writes.append((pa,size));return
    if base<=pc<base+window:
     assert base<=address and address+size<=base+window,('XNU write leaves owned kernel window',hex(pc),hex(address))
     kernel_writes.append((address,size))
   def invalid(uc,access,address,size,value,user):
    fault.append({'pc':hex(u.reg_read(A.UC_ARM64_REG_PC)),'address':hex(address),'size':size,'access':access});return False
   u.hook_add(UC_HOOK_MEM_INVALID,invalid)
  u.reg_write(A.UC_ARM64_REG_X0,0x47881000 if name=='wrong_dtb_pointer' else 0x47880000);u.reg_write(A.UC_ARM64_REG_SP,0xdeadbeef)
  try:u.emu_start(head,0,timeout=120000000,count=500000000)
  except UcError:
   if not fault:raise
   stop.append('unmapped_or_protected_access')
  assert len(stop)==1,(name,stop,hex(u.reg_read(A.UC_ARM64_REG_PC)))
  assert not bridge_mem
  if name in ['bad_fdt_magic','missing_mblock','wrong_dtb_pointer','corrupt_payload']:
   assert stop==['prepare_rejected'] and not entry_verified;assert not any(u.mem_read(base,window))
  elif name=='valid':assert stop==['eret_boundary_verified'] and len(entry_verified)==1
  elif not bootstrap:assert stop==['handoff_rejected'] and not entry_verified
  assert bytes(backing.read(sym['_payload_start'],len(payload)))==bytes(initial[sym['_payload_start']-head:sym['_payload_end']-head])
  if not virtual_state:assert bytes(u.mem_read(0x47880000,len(fd)))==bytes(fd)
  return {'case':name,'stop':stop[0],'hardware_tested':False,'hardware_eret_executed':False,'exception_return_modeled':bootstrap,'xnu_instructions_executed_in_emulator':bootstrap,'entry_verified':entry_verified,'bridge_data_accesses':0,'register_trace':trace,'xnu_instruction_trace':kernel_trace,'synthetic_counter_model':name=='virtual_with_counter_model','counter_reads_sample':counter_reads,'terminal_pc':hex(u.reg_read(A.UC_ARM64_REG_PC)),'terminal_symbol':symbol_at(u.reg_read(A.UC_ARM64_REG_PC)),'instruction_tail':list(tail),'virtual_milestones':milestones,'post_mmu_instruction_trace':post_trace,'virtual_alias_model':([{k:v for k,v in virtual_state[0].items() if k not in ['aliases','table_pages']} ] if virtual_state else []),'kernel_write_count':len(kernel_writes),'kernel_instruction_count':instruction_count[0],'bootstrap_tables':tables,'fault':fault}
 if a.virtual_bootstrap:
  for name in ['no_counter_profile','virtual_with_counter_model','missing_midr','tampered_table','deny_virtual_exec','omit_bootargs_alias','fp_stays_disabled']:
   cases.append(run(name,bootstrap=True))
  indexed={c['case']:c for c in cases}
  n=indexed['no_counter_profile'];assert n['stop']=='unsupported_xnu_system_read' and n['fault'][0]['register']=='cntvct_el0'
  c=indexed['virtual_with_counter_model'];assert c['stop']=='unsupported_xnu_system_read' and c['fault'][0]['register']=='clidr_el1'
  assert all(m in c['virtual_milestones'] for m in ['_arm_init','_PE_init_platform','_ml_parse_cpu_topology','_kernel_startup_bootstrap','_cpu_init'])
  m=indexed['missing_midr'];assert m['stop']=='unsupported_xnu_system_read' and m['fault'][0]['register']=='midr_el1' and not m['virtual_milestones']
  t=indexed['tampered_table'];assert t['stop']=='alias_validation_rejected' and not t['virtual_alias_model']
  d=indexed['deny_virtual_exec'];assert d['stop']=='unmapped_or_protected_access' and not d['virtual_milestones'] and d['fault'][0]['access'] in [UC_MEM_FETCH_PROT,UC_MEM_FETCH_UNMAPPED]
  b=indexed['omit_bootargs_alias'];assert b['stop']=='unmapped_or_protected_access' and '_arm_init' in b['virtual_milestones']
  f=indexed['fp_stays_disabled'];assert f['stop']=='fp_before_enable'

 else:
  cases.append(run('valid'))
  for n in ['bad_fdt_magic','missing_mblock','wrong_dtb_pointer','corrupt_payload','bridge_wrong_el','bridge_stage2',*[f'bridge_sctlr_{b}' for b in [0,2,12,25]],'locked_sre_0','locked_sre_1','entry_null','entry_unaligned','args_null','args_unaligned','stack_null','stack_unaligned','vectors_null','vectors_unaligned']:cases.append(run(n))
  bootstrap=run('bounded_xnu_bootstrap',bootstrap=True)
  assert bootstrap['stop']=='before_xnu_mmu_enable' and bootstrap['bootstrap_tables'][0]['all_match'],bootstrap
  cases.append(bootstrap)
 result={'image_sha256':layout['image_sha256'],'kernel_sha256':layout['kernel_sha256'],'hardware_tested':False,'synthetic_only':True,'software_mmu_probe':a.virtual_bootstrap,'all_expected_stops_verified':True,'hardware_eret_executed':False,'privileged_effects':'modeled','instruction_audit':audit,'case_count':len(cases),'cases':cases,'limitations':['Not for phone use; predictable seed/synthetic ADT and modeled CPU/GIC/cache state','Default stops before MMU; opt-in virtual probe uses shared software aliases, not hardware MMU; unknown register reads are not zero','No full LK/ATF/watchdog/interrupt/MMU or device driver model; no iOS userspace']}
 a.out.write_text(json.dumps(result,indent=2)+'\n');print('Probe cases:',len(cases));print([(c['case'],c['stop'],c['virtual_milestones'],c['fault']) for c in cases])
if __name__=='__main__':main()
