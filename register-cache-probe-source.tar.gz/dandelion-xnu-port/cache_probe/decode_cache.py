#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
import argparse,json
from pathlib import Path
from profile import read_dump,decode
p=argparse.ArgumentParser(description='Offline strict ATF cache snapshot decoder. No device access.')
p.add_argument('--dump',type=Path,required=True);p.add_argument('--manifest',type=Path,default=Path(__file__).with_name('probe-manifest.json'));p.add_argument('--out',type=Path,required=True);a=p.parse_args()
try:
 result=decode(read_dump(a.dump),json.loads(a.manifest.read_text()))
 with a.out.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
 print('DECODED selected cache registers only:',a.out,'; NOT proof of XNU/iOS boot')
except (ValueError,OSError,KeyError) as e:raise SystemExit('STOP: '+str(e))
