#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Host CPU MODEL, synthetic cache values only. Never hardware validation."""
import argparse,hashlib,io,json,re,struct,sys,tempfile,unittest,zipfile,subprocess,gzip
from pathlib import Path
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from elftools.elf.elffile import ELFFile
from unicorn import *
import unicorn.arm64_const as A
from profile import decode,frames,Invalid,read_dump,geometry,DONE
from prepare_on_pc import pack,verify_container,dtb_from_boot
P=argparse.ArgumentParser();P.add_argument('--build',type=Path,required=True);P.add_argument('--out',type=Path);args=P.parse_args();sys.argv=[sys.argv[0]]
M=json.loads((args.build/'probe-manifest.json').read_text());RAW=(args.build/'cache-probe.Image').read_bytes();S=M['symbols'];BASE=S['_head'];MD=Cs(CS_ARCH_ARM64,CS_MODE_ARM);MD.detail=True
# Explicitly hypothetical unit-test geometry. NOT read from Redmi, not a device profile.
SYNTH={'currentel':8,'sctlr_el2':0x30c50830,'hcr_el2':0,'midr_el1':0x410fd034,'mpidr_el1':0x80000000,'cntfrq_el0':13000000,'clidr_el1':0x0a200023,'ctr_el0':0x8444c004,'id_aa64mmfr0_el1':0x1122,'id_aa64mmfr1_el1':0,'dczid_el0':4,'csselr_el1':0}
CC={0:(127<<13)|(3<<3)|2,1:(255<<13)|(1<<3)|2,2:(511<<13)|(15<<3)|2}
def run(overrides=None,cc=None,fdt=0x47880000,restore_bad=False,exception=False):
 cpu={**SYNTH,**(overrides or {})};cache={**CC,**(cc or {})};u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,4096,UC_PROT_ALL);u.mem_write(BASE,RAW);u.mem_protect(BASE,4096,UC_PROT_READ|UC_PROT_EXEC);u.reg_write(A.UC_ARM64_REG_X0,fdt);u.reg_write(A.UC_ARM64_REG_SP,0x12345678)
 stop=[];writes=[];data=[];reads=[]
 def reg(n):return getattr(A,'UC_ARM64_REG_'+n.upper())
 def val(n):return 0 if n=='xzr' else int(n[1:],0) if n.startswith('#') else u.reg_read(reg(n))
 def hook(uc,pc,size,user):
  if pc in [S['probe_park'],S['probe_fail_park'],S['probe_exception_park']]:stop.append(pc);u.emu_stop();return
  i=next(MD.disasm(bytes(u.mem_read(pc,4)),pc));op=i.mnemonic
  if op=='mrs':
   dst,src=i.op_str.split(', ')
   v=(cache[cpu['csselr_el1']] if src=='ccsidr_el1' else cpu[src]);reads.append(src)
   if restore_bad and src=='csselr_el1' and reads.count(src)>1:v^=1
   u.reg_write(reg(dst),v);u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif op=='msr':
   dst,src=i.op_str.split(', ');assert dst in ['daifset','vbar_el2','csselr_el1'];v=val(src);writes.append((dst,v));cpu[dst]=v;u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif op=='isb':u.reg_write(A.UC_ARM64_REG_PC,pc+4)
 def memory(uc,access,address,size,value,user):data.append((access,address,size));raise AssertionError('unexpected data RAM/MMIO access')
 u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,memory)
 start=BASE
 if exception:
  start=S['probe_vectors']+128*4;cpu.update(esr_el2=0x123,elr_el2=0x456,far_el2=0x789,spsr_el2=0x3c9)
 u.emu_start(start,BASE+4096,count=1000);assert len(stop)==1 and not data
 return {'regs':{i:u.reg_read(reg('x'+str(i))) for i in range(30)},'lr':u.reg_read(A.UC_ARM64_REG_X30),'pc':stop[0],'sp':u.reg_read(A.UC_ARM64_REG_SP),'pstate':0x600003c9,'writes':writes,'reads':reads}
def snapshot(f):
 r=f['regs'];s='[ATF] aee_wdt_dump: on cpu0\n'
 s+=f"[ATF] (0) pc:<{f['pc']:016x}> lr:<{f['lr']:016x}> sp:<{f['sp']:016x}> pstate={f['pstate']:08x}\n"
 for hi in range(29,-1,-3):s+='[ATF] (0) '+' '.join(f'x{j:02d}: {r[j]:016x}' for j in range(hi,max(-1,hi-3),-1))+'\n'
 return s.encode()
class ProbeTests(unittest.TestCase):
 def test_static_audit(self):
  self.assertEqual(hashlib.sha256(RAW).hexdigest(),M['image_sha256']);elf=ELFFile(io.BytesIO((args.build/'cache-probe.elf').read_bytes()));count=0;ranges=[];instructions=[]
  allowed={'adr','b','mov','movk','movz','mrs','msr','cmp','tbnz','cbnz','and','ubfx','orr','isb','wfe','nop'}
  for sec in elf.iter_sections():
   if not sec['sh_flags']&4:continue
   data=sec.data()[:4] if sec.name=='.head' else sec.data();ins=list(MD.disasm(data,sec['sh_addr']));self.assertEqual(sum(i.size for i in ins),len(data));ranges.append((sec['sh_addr'],sec['sh_addr']+len(data)));instructions+=ins
   for i in ins:
    self.assertTrue(i.mnemonic in allowed or i.mnemonic.startswith('b.'),(i.mnemonic,i.op_str));self.assertNotRegex(i.op_str,r'\b[vqdshb][0-9]+\b');count+=1
    if i.mnemonic=='msr':self.assertIn(i.op_str.split(', ')[0],['daifset','vbar_el2','csselr_el1'])
  for i in instructions:
   if i.mnemonic in ['b','tbnz','cbnz'] or i.mnemonic.startswith('b.'):self.assertTrue(any(lo<=i.operands[-1].imm<hi for lo,hi in ranges))
  self.assertGreater(count,500)
 def test_success_restore(self):
  f=run({'csselr_el1':7});self.assertEqual(f['regs'][19],DONE);self.assertEqual(f['regs'][28],7);self.assertEqual(f['regs'][8],7);self.assertEqual([v for k,v in f['writes'] if k=='csselr_el1'],[0,1,2,7]);p=decode(snapshot(f),M);self.assertEqual(p['caches']['l1_data']['size_bytes'],32768)
 def test_el_guard(self):self.assertEqual(run({'currentel':4})['regs'][20],1)
 def test_sctlr_guards(self):
  for bit in [0,2,12,25]:self.assertEqual(run({'sctlr_el2':SYNTH['sctlr_el2']|(1<<bit)})['regs'][20],2)
 def test_stage2_guard(self):self.assertEqual(run({'hcr_el2':1})['regs'][20],3)
 def test_midr_guard(self):self.assertEqual(run({'midr_el1':0x410fd050})['regs'][20],4)
 def test_affinity_guards(self):
  for v in [0x80000001,0x80000100,0x180000000]:self.assertEqual(run({'mpidr_el1':v})['regs'][20],5)
 def test_freq_guard(self):self.assertEqual(run({'cntfrq_el0':1})['regs'][20],6)
 def test_fdt_guard(self):self.assertEqual(run(fdt=0)['regs'][20],10)
 def test_restore_fail(self):self.assertEqual(run(restore_bad=True)['regs'][20],8)
 def test_exception_vector(self):
  f=run(exception=True);self.assertEqual(f['regs'][19],0x4439414345584331);self.assertEqual(f['regs'][20],0x123)
 def test_absent_caches(self):
  f=run({'clidr_el1':0});p=decode(snapshot(f),M);self.assertEqual(p['caches'],{});self.assertEqual(f['regs'][25],(1<<64)-1)
 def test_unified_l1(self):self.assertEqual(set(decode(snapshot(run({'clidr_el1':4})),M)['caches']),{'l1_data'})
 def test_old_marker_rejected(self):
  f=run();f['regs'][19]=0x53544730444f4e45
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_stale_tag(self):
  f=run();f['regs'][11]^=1
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_truncated(self):
  with self.assertRaises(Invalid):decode(snapshot(run())[:-80],M)
 def test_duplicate(self):
  with self.assertRaises(Invalid):decode(snapshot(run())+b'x19: 4439414341434831\n',M)
 def test_no_cross_cpu_merge(self):
  b=snapshot(run());pos=b.index(b'x14:')
  with self.assertRaises(Invalid):decode(b[:pos]+b'wdt_dump: on cpu1\n'+b[pos:],M)
 def test_wrong_pc(self):
  f=run();f['pc']+=12
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_wrong_el_snapshot(self):
  f=run();f['pstate']=0x3c5
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_unknown_hierarchy(self):
  with self.assertRaises(Invalid):decode(snapshot(run({'clidr_el1':SYNTH['clidr_el1']|1<<6})),M)
 def test_conflict(self):
  with self.assertRaises(Invalid):decode(snapshot(run())+snapshot(run(cc={0:CC[0]^8})),M)
 def test_line_mismatch(self):
  with self.assertRaises(Invalid):decode(snapshot(run({'ctr_el0':0x8444c003})),M)
 def test_mask_mismatch(self):
  f=run();f['regs'][20]^=4
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_restore_snapshot_mismatch(self):
  f=run();f['regs'][8]^=1
  with self.assertRaises(Invalid):decode(snapshot(f),M)
 def test_zip(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'dump.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('capture/expdb-current.bin',snapshot(run()))
   self.assertEqual(decode(read_dump(p),M)['matching_frames'],1)
 def test_zip_ambiguous(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'dump.zip'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr('a/expdb-current.bin',b'x');z.writestr('b/expdb-current.bin',b'y')
   with self.assertRaises(Invalid):read_dump(p)
 def test_geometry(self):self.assertEqual(geometry(CC[2])['size_bytes'],524288)
 def test_ccidx_rejected(self):
  with self.assertRaises(Invalid):geometry(1<<40)
 def test_bad_backup(self):
  with self.assertRaises(Invalid):dtb_from_boot(b'ANDROID!')
 def test_bad_avb(self):
  with self.assertRaises(Invalid):verify_container(b'\0'*67108864,b'payload')
 def test_avb_roundtrip_and_corruption(self):
  with tempfile.TemporaryDirectory() as d:
   payload=pack(RAW,b'UNIT-TEST-DTB-NOT-FOR-PHONE');p=Path(d)/'boot.img';p.write_bytes(payload)
   avb=Path(__file__).with_name('avbtool.py')
   subprocess.run([sys.executable,str(avb),'add_hash_footer','--image',str(p),'--partition_name','boot','--partition_size','67108864','--algorithm','NONE','--salt','ab'*32],check=True)
   b=p.read_bytes();verify_container(b,payload)
   subprocess.run([sys.executable,str(avb),'verify_image','--image',str(p)],check=True,stdout=subprocess.DEVNULL)
   for index in [0,struct.unpack_from('>Q',b,len(b)-44)[0]+28,len(b)-64]:
    altered=bytearray(b);altered[index]^=1
    with self.assertRaises(Invalid):verify_container(bytes(altered),payload)
 def test_kernel_and_cpio_roundtrip(self):
  b=pack(RAW,b'SYNTHETIC-DTB');k=struct.unpack_from('<I',b,8)[0];r=struct.unpack_from('<I',b,16)[0];off=2048+(k+2047)//2048*2048
  self.assertEqual(gzip.decompress(b[2048:2048+k]),RAW);self.assertIn(b'TRAILER!!!',gzip.decompress(b[off:off+r]))
 def test_pack_nonempty_ramdisk(self):
  b=pack(RAW,b'FAKE-UNIT-TEST-DTB');k,ka,r=struct.unpack_from('<III',b,8);self.assertGreater(r,0);self.assertEqual(b[:8],b'ANDROID!')
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(ProbeTests);r=unittest.TextTestRunner(verbosity=2).run(suite)
 if args.out:args.out.write_text(json.dumps({'kind':'SYNTHETIC_CPU_MODEL_AND_HOST_TESTS','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'hardware_tested':False},indent=2)+'\n')
 sys.exit(not r.wasSuccessful())
