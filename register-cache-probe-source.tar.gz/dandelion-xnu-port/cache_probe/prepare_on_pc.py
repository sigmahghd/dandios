#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Offline, backup-bound candidate generation only. NEVER accesses a phone."""
import argparse,gzip,hashlib,json,struct,subprocess,sys
from pathlib import Path
from profile import require
from build_probe import BOOT_SHA,RECOVERY_SHA,DTB_SHA
R=Path(__file__).resolve().parent
SIZE=67108864
def sha(b):return hashlib.sha256(b).hexdigest()
def dtb_from_boot(b):
 require(len(b)==SIZE and sha(b)==BOOT_SHA,'original Boot size/SHA mismatch')
 require(b[:8]==b'ANDROID!','not Android Boot')
 k,ka,r,ra,s,sa,tags,page,ver,os=struct.unpack_from('<10I',b,8)
 require((ka,ra,s,sa,tags,page,ver)==(0x40080000,0x51b00000,0,0,0x47880000,2048,2),'unexpected original Boot v2 layout')
 require(struct.unpack_from('<IQI',b,1632)==(0,0,1660),'unexpected recovery DTBO/header')
 n,addr=struct.unpack_from('<IQ',b,1648);off=page+((k+page-1)//page)*page+((r+page-1)//page)*page
 dtb=b[off:off+n];require(n==127044 and addr==0x47880000 and sha(dtb)==DTB_SHA,'DTB differs from exact original backup');return dtb
def pack(image,dtb):
 name=b'TRAILER!!!\0';fields=[0,0,0,0,1,0,0,0,0,0,0,len(name),0]
 cpio=b'070701'+b''.join(f'{v:08x}'.encode() for v in fields)+name;cpio+=b'\0'*(-len(cpio)%4)
 rd=gzip.compress(cpio,mtime=0);kernel=gzip.compress(image,mtime=0);h=bytearray(2048);h[:8]=b'ANDROID!'
 struct.pack_into('<10I',h,8,len(kernel),0x40080000,len(rd),0x51b00000,0,0,0x47880000,2048,2,0)
 h[48:64]=b'd9a-cache-probe'.ljust(16,b'\0');cmd=b'bootopt=64S3,32N2,64N2';h[64:64+len(cmd)]=cmd
 struct.pack_into('<IQI',h,1632,0,0,1660);struct.pack_into('<IQ',h,1648,len(dtb),0x47880000)
 sh=hashlib.sha1()
 for d in (kernel,rd,b'',b'',dtb):sh.update(d);sh.update(struct.pack('<I',len(d)))
 h[576:596]=sh.digest();pad=lambda d:d+b'\0'*(-len(d)%2048)
 return bytes(h)+pad(kernel)+pad(rd)+pad(dtb)
def verify_container(b,original):
 require(len(b)==SIZE and b[:len(original)]==original,'container length/payload mismatch')
 magic,major,minor,orig,off,n=struct.unpack_from('>4sIIQQQ',b,len(b)-64)
 require(magic==b'AVBf' and orig==len(original) and off>=orig and n>=256 and off+n<=len(b)-64,'bad AVB footer')
 vb=b[off:off+n];require(vb[:4]==b'AVB0' and struct.unpack_from('>I',vb,28)[0]==0,'expected UNSIGNED AVB NONE only')
 auth,auxsz=struct.unpack_from('>QQ',vb,12);do,dn=struct.unpack_from('>QQ',vb,96);pos=256+auth+do
 require(auth==0 and 256+auxsz==n and 0<dn<=auxsz and pos+dn<=n,'bad AVB bounds')
 tag,nb=struct.unpack_from('>QQ',vb,pos);require(tag==2 and nb+16==dn and dn>=132,'bad hash descriptor')
 imsz=struct.unpack_from('>Q',vb,pos+16)[0];pn,sl,dl=struct.unpack_from('>III',vb,pos+56);start=pos+132
 require(imsz==orig and vb[pos+24:pos+56].rstrip(b'\0')==b'sha256' and pn==4 and sl==32 and dl==32 and start+pn+sl+dl<=pos+dn,'bad AVB hash fields')
 require(vb[start:start+pn]==b'boot','not boot partition');salt=vb[start+pn:start+pn+sl];digest=vb[start+pn+sl:start+pn+sl+dl]
 require(hashlib.sha256(salt+b[:imsz]).digest()==digest,'AVB payload hash mismatch')
def prepare(backup,out,kit=R):
 require(not out.exists(),'refusing existing output directory')
 boot=backup/'boot-current.img';recovery=backup/'recovery-current.img'
 require(boot.stat().st_size==SIZE and recovery.stat().st_size==SIZE,'backup size mismatch')
 original=boot.read_bytes();require(sha(recovery.read_bytes())==RECOVERY_SHA,'Recovery backup SHA mismatch');dtb=dtb_from_boot(original)
 m=json.loads((kit/'probe-manifest.json').read_text());image=(kit/'cache-probe.Image').read_bytes()
 require(m['kind']=='DANDELION_REGISTER_CACHE_PROBE_V1' and m['boot_original_sha256']==BOOT_SHA and m['recovery_original_sha256']==RECOVERY_SHA and m['base_dtb_sha256']==DTB_SHA,'wrong manifest/phone binding')
 require(len(image)==4096 and sha(image)==m['image_sha256'] and image[56:60]==b'ARMd' and struct.unpack_from('<Q',image,16)[0]==4096,'probe payload mismatch')
 avb=kit/'avbtool.py';require(sha(avb.read_bytes())==AVB_SHA,'avbtool SHA mismatch')
 out.mkdir(parents=True);partial=out/'UNVERIFIED-DO-NOT-FLASH.part';payload=pack(image,dtb);partial.write_bytes(payload)
 subprocess.run([sys.executable,str(avb),'add_hash_footer','--image',str(partial),'--partition_name','boot','--partition_size',str(SIZE),'--algorithm','NONE','--salt',sha(b'd9a-register-probe:'+m['image_sha256'].encode())],check=True)
 b=partial.read_bytes();verify_container(b,payload)
 require(sha(boot.read_bytes())==BOOT_SHA and sha(recovery.read_bytes())==RECOVERY_SHA,'original backup changed during preparation')
 report={'kind':'EXPERIMENTAL_REGISTER_ONLY_NOT_XNU_OR_IOS','file':'cache-probe-boot.img','bytes':len(b),'sha256':sha(b),'probe_tag':m['tag'],'hardware_tested':False,'signed':False,'avb_hash_verified':True,'original_boot_unchanged':True,'no_phone_access_performed':True,'warning':'May bootloop/reset. Recovery/fastboot rollback required. Do not use on another phone.'}
 (out/'candidate-report.json').write_text(json.dumps(report,indent=2)+'\n');partial.rename(out/report['file']);return report
AVB_SHA='e5a664a38db623da00f080219bc0ee60a640a9dc4a872803616fae4938ac749b'
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--backup',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--experimental-register-probe-only',action='store_true',required=True);a=p.parse_args()
 try:print(json.dumps(prepare(a.backup,a.out),indent=2))
 except (ValueError,OSError,KeyError,subprocess.CalledProcessError) as e:raise SystemExit('STOP: '+str(e)+'; never flash a .part file')
