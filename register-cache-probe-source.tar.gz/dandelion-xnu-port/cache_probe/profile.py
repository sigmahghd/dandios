# SPDX-License-Identifier: MIT
"""Strict ATF snapshot decoder; missing values are never zeros."""
import hashlib,json,re,zipfile
from pathlib import Path
DONE=0x4439414341434831
MAX=32*1024*1024
class Invalid(ValueError):pass
def require(ok,msg):
 if not ok:raise Invalid(msg)
def read_dump(path):
 p=Path(path);require(p.stat().st_size<=MAX,'input exceeds 32 MiB')
 if zipfile.is_zipfile(p):
  with zipfile.ZipFile(p) as z:
   matches=[i for i in z.infolist() if i.filename.replace('\\','/').split('/')[-1]=='expdb-current.bin']
   require(len(matches)==1,'ZIP must contain exactly one expdb-current.bin')
   require(matches[0].file_size<=MAX,'expanded input too large');return z.read(matches[0])
 return p.read_bytes()
def frames(data):
 text=data.decode('latin1');starts=list(re.finditer(r'wdt_dump: on cpu([0-9]+)',text))
 for i,m in enumerate(starts):
  if m[1]!='0':continue
  end=starts[i+1].start() if i+1<len(starts) else len(text)
  chunk=text[m.end():min(end,m.end()+8192)]
  pcs=list(re.finditer(r'pc:<([0-9a-fA-F]{16})>\s+lr:<([0-9a-fA-F]{16})>\s+sp:<([0-9a-fA-F]{16})>\s+pstate=([0-9a-fA-F]+)',chunk))
  if len(pcs)!=1:continue
  regs={};duplicate=False
  for r in re.finditer(r'\bx([0-2][0-9]):\s*(?:<)?([0-9a-fA-F]{16})(?:>)?',chunk):
   k=int(r[1]);duplicate|=k in regs;regs[k]=int(r[2],16)
  pc=pcs[0];yield {'regs':regs,'duplicate':duplicate,'pc':int(pc[1],16),'lr':int(pc[2],16),'sp':int(pc[3],16),'pstate':int(pc[4],16),'offset':m.start()}
def geometry(raw):
 require(0<=raw<=0xffffffff,'CCSIDR exceeds supported non-CCIDX width')
 line=1<<((raw&7)+4);ways=((raw>>3)&1023)+1;sets=((raw>>13)&32767)+1
 require(line<=2048,'unsupported cache line size')
 return {'line_bytes':line,'ways':ways,'sets':sets,'size_bytes':line*ways*sets}
def decode(data,manifest):
 require(manifest.get('kind')=='DANDELION_REGISTER_CACHE_PROBE_V1','wrong manifest kind')
 tag=int(manifest['tag'],16);park=manifest['symbols']['probe_park'];accepted=[];errors=[]
 for f in frames(data):
  r=f['regs']
  if r.get(19)!=DONE:continue
  try:
   require(not f['duplicate'] and set(r)==set(range(30)),'incomplete/duplicate CPU0 snapshot')
   require(r[11]==tag,'stale or wrong build tag')
   require(f['pc'] in (park,park+4),'PC outside successful park')
   require(f['sp']==0 and f['pstate']&15==9,'unexpected SP or EL2h state')
   require(r[12]==8 and r[17]==8,'incomplete progress or wrong EL')
   require(r[16]&((1<<0)|(1<<2)|(1<<12)|(1<<25))==0,'unsupported SCTLR_EL2')
   require(r[18]&1==0,'stage 2 translation enabled')
   require(r[23]&0xff0ffff0==0x410fd030,'not supported Cortex-A53')
   require(r[14]&0xff00ffffff==0,'not CPU0 affinity')
   require(r[15]==13000000 and r[0]==0x47880000,'wrong counter or FDT pointer')
   require(r[8]==r[28],'CSSELR restore mismatch')
   clidr=r[21];types=[(clidr>>(3*i))&7 for i in range(7)]
   require(types[0] in range(5) and types[1] in (0,4) and not any(types[2:]),'unsupported cache hierarchy; do not guess')
   expected=35;cache={}
   for name,reg,bit,present in [('l1_data',25,4,types[0] in (2,3,4)),('l1_instruction',26,8,types[0] in (1,3)),('l2_unified',27,16,types[1]==4)]:
    if present:expected|=bit;cache[name]={'raw':hex(r[reg]),**geometry(r[reg])}
    else:require(r[reg]==(1<<64)-1,'absent cache must remain unavailable sentinel')
   require(r[20]==expected,'cache-valid mask mismatch')
   require(r[22]<=0xffffffff and r[29]<=0xffffffff,'unexpected CTR/DCZID width')
   if 'l1_data' in cache:require(cache['l1_data']['line_bytes']==4<<(r[22]>>16&15),'CTR DminLine mismatch')
   if 'l1_instruction' in cache:require(cache['l1_instruction']['line_bytes']==4<<(r[22]&15),'CTR IminLine mismatch')
   selected={name:hex(r[reg]) for name,reg in [('midr_el1',23),('mpidr_el1',14),('cntfrq_el0',15),('clidr_el1',21),('ctr_el0',22),('dczid_el0',29),('id_aa64mmfr0_el1',24),('csselr_el1',28)]}
   selected['id_aa64mmfr1_el1']=hex(f['lr'])
   accepted.append({'registers':selected,'caches':cache})
  except (Invalid,KeyError,TypeError,ValueError) as e:errors.append(str(e))
 require(bool(accepted),'no complete matching successful CPU0 frame: '+('; '.join(errors[:4]) or 'marker absent'))
 require(not errors,'conflicting or malformed successful-marker frames: '+'; '.join(errors[:4]))
 require(all(a==accepted[0] for a in accepted),'conflicting matching snapshots')
 return {'kind':'DANDELION_CACHE_PROFILE_V1','source':'USER_PROVIDED_ATF_SNAPSHOT_NOT_ATTESTED','dump_sha256':hashlib.sha256(data).hexdigest(),'probe_image_sha256':manifest['image_sha256'],'probe_tag':manifest['tag'],'matching_frames':len(accepted),'hardware_xnu_boot_proven':False,**accepted[0]}
