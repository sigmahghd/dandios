#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Build only raw 4KiB register diagnostic. No phone DTB/Boot or device access."""
import argparse,hashlib,json,struct,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
BOOT_SHA='bffe6eb1d869f07a598677d92d23bf14b9b139ac04e1777ac8e1cc33b40d8362'
RECOVERY_SHA='dfcbbae0ed49b6484c601cc8cc6253d27d056c61db53c8bf2f220712f13affed'
DTB_SHA='82bb85356992b8007bf90df26902bbdb93ad4f4a9670e2ac341d5d38a509320e'
def sha(b):return hashlib.sha256(b).hexdigest()
def symbols(b):
 assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',b,18)[0]==183
 entry,ph,sh=struct.unpack_from('<QQQ',b,24);ps,pn,ss,sn,st=struct.unpack_from('<5H',b,54);assert ps==56 and ss==64 and 0<sn<100 and sh+ss*sn<=len(b)
 sections=[struct.unpack_from('<II4QII2Q',b,sh+i*ss) for i in range(sn)];out={}
 for s in sections:
  if s[1]!=2:continue
  assert s[9]==24 and s[5]%24==0 and s[6]<sn and s[4]+s[5]<=len(b)
  namesec=sections[s[6]];names=b[namesec[4]:namesec[4]+namesec[5]]
  for off in range(s[4],s[4]+s[5],24):
   no,info,other,index,value,size=struct.unpack_from('<IBBHQQ',b,off)
   if not no:continue
   assert no<len(names) and b'\0' in names[no:];name=names[no:names.index(0,no)].decode();assert index!=0,('undefined',name);out[name]=value
 for i in range(pn):
  typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<II6Q',b,ph+i*ps)
  if typ==1:assert not flags&2 and fs<=ms and 0x40080000<=va and va+ms<=0x40081000
 assert entry==0x40080000
 return out

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--zig',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--nonce',default='local-test');a=p.parse_args()
 if a.out.exists():p.error('refusing existing output directory')
 assert len(a.nonce)<128 and a.nonce.isascii()
 zig=a.zig.resolve();assert subprocess.check_output([str(zig),'version'],text=True).strip()=='0.13.0'
 tag=int.from_bytes(hashlib.sha256((R/'probe.S').read_bytes()+(R/'probe.ld').read_bytes()+a.nonce.encode()).digest()[:8],'big')
 a.out.mkdir(parents=True);out=a.out.resolve();elf=out/'cache-probe.elf';image=out/'cache-probe.Image'
 cmd=[str(zig),'cc','-target','aarch64-freestanding-none','-mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2','-nostdlib','-DPROBE_TAG='+hex(tag),'-Wl,-e,_head','-Wl,-T,'+str(R/'probe.ld'),'-Wl,--build-id=none',str(R/'probe.S'),'-o',str(elf)]
 with (out/'build.log').open('w') as log:
  subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True);subprocess.run([str(zig),'objcopy','-O','binary',str(elf),str(image)],stdout=log,stderr=subprocess.STDOUT,check=True)
 b=image.read_bytes();sym=symbols(elf.read_bytes());assert len(b)==4096 and b[56:60]==b'ARMd' and struct.unpack_from('<Q',b,16)[0]==4096 and struct.unpack_from('<Q',b,24)[0]==10
 manifest={'kind':'DANDELION_REGISTER_CACHE_PROBE_V1','nonce':a.nonce,'tag':hex(tag),'image_sha256':sha(b),'image_bytes':len(b),'boot_original_sha256':BOOT_SHA,'recovery_original_sha256':RECOVERY_SHA,'base_dtb_sha256':DTB_SHA,'hardware_tested':False,'xnu_executed':False,'symbols':{k:v for k,v in sym.items() if not k.startswith('$')},'scope':'Register-only Cortex-A53 CPU0 EL2 diagnostic. NO stack/data RAM/MMIO/storage/cache maintenance. Successful CSSELR restored. Watchdog/ATF capture NOT guaranteed.'}
 (out/'probe-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k] for k in ['image_bytes','image_sha256','tag','hardware_tested']},indent=2))
if __name__=='__main__':main()
