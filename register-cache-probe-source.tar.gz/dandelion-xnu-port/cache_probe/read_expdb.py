#!/usr/bin/env python3
"""Read only the expdb diagnostic partition in root recovery. Writes ONLY on PC."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

PARTITIONS = {'expdb': None}
TRAILER = b'__DANDELION_EXPDB_READ_REMOTE_RC__'
ADB = 'adb'


def run(args, timeout=30):
    return subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=timeout)


def remote(command, timeout=30):
    # Every command is a fixed string from this program, not a user-supplied path.
    wrapper = command + '; rc=$?; printf "\\n' + TRAILER.decode() + '%s\\n" "$rc"; exit "$rc"'
    r = run([ADB, 'shell', wrapper], timeout=timeout)
    match = re.search(rb'\r?\n' + TRAILER + rb'([0-9]{1,3})\r?\n\Z', r.stdout)
    if not match or r.returncode or int(match.group(1)) or r.stderr.strip():
        detail = (r.stdout[-500:] + b'\n' + r.stderr[-500:]).decode('utf-8', 'replace')
        raise RuntimeError('Remote read failed: ' + command + '\n' + detail)
    return r.stdout[:match.start()].decode('utf-8', 'strict').strip()


def remote_hash(name):
    path = '/dev/block/by-name/' + name
    text = remote('sha256sum ' + path, timeout=180)
    m = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?' + re.escape(path), text)
    if not m:
        raise RuntimeError('Cannot verify remote SHA256 for ' + name + '. Nothing will be flashed.')
    return m.group(1).lower()


def plan():
    state = run([ADB, 'get-state'])
    if state.returncode != 0 or state.stdout.strip() not in (b'device', b'recovery'):
        detail = state.stderr.decode('utf-8', 'replace').strip()
        raise RuntimeError('Exactly one accessible ADB device/recovery must be connected.' + ('\n' + detail if detail else ''))
    if remote('getprop ro.bootmode') != 'recovery':
        raise RuntimeError('Refused: device must remain in the existing OrangeFox recovery.')
    if remote('id -u') != '0':
        raise RuntimeError('Refused: recovery ADB shell is not root. No privilege changes attempted.')
    result = {}
    for name, block in PARTITIONS.items():
        path = '/dev/block/by-name/' + name
        target = remote('readlink -f ' + path)
        if name != 'expdb' or not re.fullmatch(r'/dev/block/mmcblk0p[1-9][0-9]{0,2}', target):
            raise RuntimeError('Unexpected expdb mapping: ' + target)
        block = target.rsplit('/', 1)[-1]
        remote('test -b ' + path)
        sectors = remote('cat /sys/class/block/' + block + '/size')
        if not re.fullmatch(r'[0-9]{1,12}', sectors):
            raise RuntimeError('Invalid sysfs sector count for ' + name)
        size = int(sectors) * 512  # sysfs /size units are always 512-byte sectors.
        if size < 4096 or size > 128 * 1024 * 1024:
            raise RuntimeError('Unexpected partition size for ' + name + ': ' + str(size))
        result[name] = {'source': path, 'resolved_source': target, 'size_bytes': size,
                        'sha256_before': remote_hash(name)}
    return result


def file_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def copy_one(name, info, folder):
    temp = folder / (name + '-current.bin.partial')
    final = folder / (name + '-current.bin')
    if temp.exists() or final.exists():
        raise RuntimeError('Refused to overwrite existing image: ' + name)
    try:
        with temp.open('xb') as f:
            # Direct binary subprocess pipe -> file. No CMD/PowerShell redirection.
            p = subprocess.Popen([ADB, 'exec-out', 'cat ' + info['source']],
                                 stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                # Concurrent drain prevents stderr deadlocks while streaming binary stdout.
                import threading
                error = bytearray()
                def drain_stderr():
                    while True:
                        b = p.stderr.read(4096)
                        if not b:
                            break
                        if len(error) < 65536:
                            error.extend(b[:65536-len(error)])
                thread = threading.Thread(target=drain_stderr, daemon=True)
                thread.start()
                import time
                start = time.monotonic()
                count = 0
                # Watchdog only kills host ADB process; never reboots the device.
                timer = threading.Timer(300, p.kill)
                timer.daemon = True
                timer.start()
                try:
                    while True:
                        data = p.stdout.read(1024 * 1024)
                        if not data:
                            break
                        count += len(data)
                        if count > info['size_bytes']:
                            raise RuntimeError('Too much data from ' + name)
                        f.write(data)
                    code = p.wait(timeout=10)
                    thread.join(timeout=10)
                    if code or error or count != info['size_bytes'] or time.monotonic()-start >= 300:
                        raise RuntimeError('Incomplete/failed read of ' + name + ': ' + error.decode('utf-8', 'replace'))
                finally:
                    timer.cancel()
            finally:
                if p.poll() is None:
                    p.kill()
                p.wait()
                p.stdout.close()
                p.stderr.close()
        local = file_hash(temp)
        after = remote_hash(name)
        if local != info['sha256_before'] or local != after:
            raise RuntimeError('SHA256 mismatch/source changed: ' + name)
        # This is a raw firmware read, NOT Android boot/recovery format.
        # Do not guess a firmware magic/header or call the file flash-ready.
        temp.rename(final)
        return dict(info, file=final.name, sha256_local=local, sha256_after=after,
                    size_verified=True, sha256_verified=True)
    except BaseException:
        # Never leave failed reads named as a verified .bin.
        if temp.exists():
            temp.unlink()
        raise


def main():
    global ADB
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, help='New output folder on the PC; must not already exist')
    args = ap.parse_args()
    ADB = shutil.which('adb') or shutil.which('adb.exe')
    if not ADB:
        ap.exit(2, 'ERROR: adb not found. Use the same CMD/PATH as before.\n')
    folder = args.out or Path('dandelion-expdb-read-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
    try:
        if folder.exists():
            raise RuntimeError('Output folder already exists. Choose a NEW folder; do not delete existing backups.')
        print('Checking recovery, exact partition paths, sizes and source hashes...', flush=True)
        items = plan()
        parent = folder.resolve().parent
        if not parent.is_dir():
            raise RuntimeError('Parent output directory must already exist.')
        need = sum(x['size_bytes'] for x in items.values()) + 32 * 1024 * 1024
        if shutil.disk_usage(parent).free < need:
            raise RuntimeError('Not enough free space on PC output drive.')
        folder.mkdir()
        manifest = {'status': 'INCOMPLETE', 'created_utc': datetime.now(timezone.utc).isoformat(),
                    'purpose': 'read-only expdb diagnostics; may contain private crash/memory data; NEVER flash this file',
                    'writes_on_phone': False, 'images': {}}
        def save_manifest():
            (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
        save_manifest()
        for name, info in items.items():
            print('Reading ' + name + ': ' + str(info['size_bytes']) + ' bytes...', flush=True)
            manifest['images'][name] = copy_one(name, info, folder)
            save_manifest()
            print(name + ': size + SHA256 verified.', flush=True)
        manifest['status'] = 'VERIFIED_EXPDB_READ'
        save_manifest()
        print('SUCCESS: ' + str(folder.resolve()))
        print('Keep expdb-current.bin and manifest.json unchanged. Inspect privacy before sharing; contains diagnostic data, not a flash image.')
        print('READ-ONLY ANALYSIS. Never flash/erase expdb or change any bootloader or security partition.')
    except (Exception, KeyboardInterrupt) as e:
        ap.exit(2, '\nSTOPPED: ' + str(e) + '\nNo phone partitions were written. This tool produces no images approved for flashing.\n')


if __name__ == '__main__':
    main()
