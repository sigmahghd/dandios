#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Install exact official Zig 0.13.0 to a new disposable directory.
No credentials, no billing, no system install. Download size and SHA256 pinned.
"""
import argparse,hashlib,json,platform,shutil,subprocess,tarfile,urllib.request
from pathlib import Path
PACKAGES={
 ('Darwin','arm64'):('zig-macos-aarch64-0.13.0',44892040,'46fae219656545dfaf4dce12fb4e8685cec5b51d721beee9389ab4194d43394c'),
 ('Darwin','x86_64'):('zig-macos-x86_64-0.13.0',48857012,'8b06ed1091b2269b700b3b07f8e3be3b833000841bae5aa6a09b1a8b4773effd'),
 ('Linux','x86_64'):('zig-linux-x86_64-0.13.0',47082308,'d45312e61ebcc48032b77bc4cf7fd6915c11fa16e4aad116b66c9468211230ea')}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args();key=(platform.system(),platform.machine())
 if key not in PACKAGES:p.error('unvalidated compiler host '+repr(key))
 if a.out.exists():p.error('refusing existing tool directory')
 prefix,size,expected=PACKAGES[key];out=a.out.resolve();out.mkdir(parents=True);archive=out/'zig.tar.xz';h=hashlib.sha256();received=0
 url='https://ziglang.org/download/0.13.0/'+prefix+'.tar.xz'
 with urllib.request.urlopen(url,timeout=120) as response,archive.open('wb') as dest:
  while True:
   b=response.read(1024*1024)
   if not b:break
   received+=len(b)
   if received>size:raise SystemExit('STOP: oversized compiler archive')
   dest.write(b);h.update(b)
 if received!=size or h.hexdigest()!=expected:raise SystemExit('STOP: compiler archive size/SHA256 mismatch')
 with tarfile.open(archive,'r:xz') as tf:
  members=tf.getmembers()
  if len(members)>30000 or sum(m.size for m in members)>768*1024*1024:raise SystemExit('STOP: compiler archive limits')
  planned=[]
  for m in members:
   parts=Path(m.name).parts
   if not parts or parts[0]!=prefix or Path(m.name).is_absolute() or '..' in parts or not(m.isfile() or m.isdir()) or m.size>256*1024*1024:raise SystemExit('STOP: unexpected compiler archive member')
   planned.append((m,out.joinpath(*parts)))
  for m,dest in planned:
   if m.isdir():dest.mkdir(parents=True,exist_ok=True);continue
   dest.parent.mkdir(parents=True,exist_ok=True)
   with tf.extractfile(m) as source,dest.open('wb') as target:shutil.copyfileobj(source,target)
   dest.chmod(0o755 if m.mode&0o111 else 0o644)
 zig=out/prefix/'zig';version=subprocess.check_output([str(zig),'version'],text=True).strip()
 if version!='0.13.0':raise SystemExit('STOP: compiler version mismatch')
 result={'zig':str(zig),'version':version,'archive_sha256':expected,'host':list(key)};(out/'toolchain.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
