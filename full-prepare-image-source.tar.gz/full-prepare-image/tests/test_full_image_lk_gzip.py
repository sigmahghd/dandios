#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Execute pinned LK gzip/inflate on complete public prepare-only Image.
Private LK is caller-supplied and never written/published. Isolated code, not whole LK.
Only allocator/free/log mocked, no MMIO. Synthetic heap/banks are not hardware proof.
"""
import argparse,hashlib,json,struct
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_PC

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--lk',type=Path,required=True);p.add_argument('--build',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 if a.out.exists():p.error('refusing existing result')
 lk=a.lk.read_bytes();assert hashlib.sha256(lk).hexdigest()=='aea8abdf754b3e80b2b76a448e15767830eda23577645e28c3c2310f14342802'
 image=(a.build/'NOT-FLASHABLE-prepare-only.Image').read_bytes();compressed=(a.build/'NOT-FLASHABLE-prepare-only.Image.gz').read_bytes();layout=json.loads((a.build/'layout.json').read_text());assert hashlib.sha256(image).hexdigest()==layout['image_sha256'];assert hashlib.sha256(compressed).hexdigest()==layout['gzip_sha256'];assert len(compressed)<=0x1000000
 def address(off):return 0x48000000+off-512
 def run(capacity):
  u=Uc(UC_ARCH_ARM,UC_MODE_THUMB);destination=0x40080000;reservation=0x7800000
  for base,size in [(destination,reservation),(0x48000000,0x200000),(0x50000000,0x20000),(0x48b00000,0x1000000),(0x58000000,0x400000)]:u.mem_map(base,size)
  u.mem_write(destination,b'\xa5'*reservation);u.mem_write(0x48000000,lk[512:512+0xcdb24]);u.mem_write(0x48b00000,compressed);u.mem_write(0x50001000,struct.pack('<I',len(compressed)))
  u.reg_write(UC_ARM_REG_SP,0x5001f000);u.reg_write(UC_ARM_REG_LR,0x50002001)
  for r,v in [(UC_ARM_REG_R0,0x48b00000),(UC_ARM_REG_R1,0x50001000),(UC_ARM_REG_R2,destination),(UC_ARM_REG_R3,capacity)]:u.reg_write(r,v)
  heap=[0x58000000];returned=[];logs=[]
  def ret(v=None):
   if v is not None:u.reg_write(UC_ARM_REG_R0,v)
   u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
  def hook(uc,pc,size,user):
   if pc==address(0x34fa0):
    n=u.reg_read(UC_ARM_REG_R0);result=heap[0];heap[0]+=(n+15)&~15;assert heap[0]<=0x58400000;ret(result)
   elif pc==address(0x34fd4):ret()
   elif pc==address(0x34328):
    logs.append('printf called');ret(0)
   elif pc==0x50002000:returned.append(True);u.emu_stop()
  handles=[u.hook_add(UC_HOOK_CODE,hook,begin=pc,end=pc) for pc in [address(0x34fa0),address(0x34fd4),address(0x34328),0x50002000]]
  u.emu_start(address(0x24f5c)|1,0,timeout=180000000,count=1500000000)
  assert returned,'LK decoder did not return within limits'
  for h in handles:u.hook_del(h)
  rc=u.reg_read(UC_ARM_REG_R0);size=struct.unpack('<I',u.mem_read(0x50001000,4))[0]
  result={'capacity':capacity,'return_code':rc,'reported_output_size':size,'heap_bytes':heap[0]-0x58000000,'logging_calls':len(logs)}
  if capacity>=len(image):
   assert rc==0 and size==len(image);output=bytes(u.mem_read(destination,len(image)));assert output==image;assert bytes(u.mem_read(destination+len(image),reservation-len(image)))==b'\xa5'*(reservation-len(image));result.update(output_matches_entire_image=True,untouched_reservation_tail=True,image_sha256=hashlib.sha256(output).hexdigest())
  else:
   assert rc!=0;assert bytes(u.mem_read(destination+capacity,reservation-capacity))==b'\xa5'*(reservation-capacity);result.update(expected_rejection=True,no_write_past_capacity=True)
  return result
 cases=[run(len(image)),run(64)]
 result={'scope':__doc__,'lk_sha256':hashlib.sha256(lk).hexdigest(),'hardware_tested':False,'whole_lk_emulated':False,'image_sha256':layout['image_sha256'],'image_bytes':len(image),'cases':cases}
 a.out.write_text(json.dumps(result,indent=2)+'\n');print('PASS pinned real LK gzip/inflate: complete',len(image),'byte Image matches; tiny-capacity control rejected; no hardware claim')
if __name__=='__main__':main()
