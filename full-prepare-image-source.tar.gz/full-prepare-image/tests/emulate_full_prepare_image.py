#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Boot complete raw Image at its real _head, emulate to prepare-only park.
CPU privileged effects modeled. No ERET/XNU execution or phone access.
"""
import argparse,hashlib,io,json,re,struct,sys
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE,UC_PROT_READ,UC_PROT_WRITE,UC_PROT_EXEC
import unicorn.arm64_const as A
from test_lk_fdt import fdt_fixture
from test_real_kernel_fixture import check_mapping

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 if a.out.exists():p.error('refusing existing report')
 layout=json.loads((a.build/'layout.json').read_text());raw=(a.build/'NOT-FLASHABLE-prepare-only.Image').read_bytes();offset=layout['symbols']['_payload_start']-layout['entry'];payload=raw[offset:offset+layout['payload_bytes']]
 assert hashlib.sha256(raw).hexdigest()==layout['image_sha256'];assert hashlib.sha256(payload).hexdigest()==layout['payload_sha256'];assert layout['prepare_only'] and not layout['hardware_tested']
 elf=ELFFile(io.BytesIO((a.build/'prepare-only.elf').read_bytes()));sym=layout['symbols'];head=sym['_head'];end=sym['_image_end'];base=sym['_kernel_window_start'];window=sym['_kernel_window_end']-base
 assert elf.header['e_entry']==head and len(raw)==end-head
 md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);audit=[];executable=[]
 for section in elf.iter_sections():
  if not section['sh_flags']&4:continue
  # The 64-byte ARM Image header contains data after its one entry instruction.
  data=section.data()[:4] if section.name=='.head' else section.data();md.skipdata=True;md.detail=True;instructions=list(md.disasm(data,section['sh_addr']));bad=[]
  for i in instructions:
   if i.id==0 or i.mnemonic in ['eret','br','blr'] or re.search(r'\b[vqdshb][0-9]+\b',i.op_str) or re.match(r'^(?:cas|swp|ldadd|stadd|ldapr|pac|aut|retaa|retab|sha|aes)',i.mnemonic):bad.append((hex(i.address),i.mnemonic,i.op_str))
  assert not bad,(section.name,len(bad),bad[:5]);assert sum(i.size for i in instructions)==len(data)
  executable.append((section['sh_addr'],section['sh_addr']+len(data)));audit.append({'section':section.name,'instructions':len(instructions),'disallowed':0})
 # Every direct control-flow target stays in loader executable sections.
 for section in elf.iter_sections():
  if not section['sh_flags']&4:continue
  data=section.data()[:4] if section.name=='.head' else section.data()
  for i in md.disasm(data,section['sh_addr']):
   if i.mnemonic in ['b','bl','cbz','cbnz','tbz','tbnz'] or i.mnemonic.startswith('b.'):
    target=i.operands[-1].imm;assert any(lo<=target<hi for lo,hi in executable),('branch leaves loader executable code',hex(i.address),hex(target))
 for name,target in [('.el2_vectors','image_exception_el2'),('.el1_vectors','image_exception_el1')]:
  sec=elf.get_section_by_name(name);assert sec['sh_size']==2048
  for slot in range(16):
   ins=next(md.disasm(sec.data()[slot*128:slot*128+4],sec['sh_addr']+slot*128));assert ins.mnemonic=='b' and int(ins.op_str[1:],16)==sym[target]
 baseline={'el':8,'sctlr':0x30c50830,'hcr':0,'mpidr':0x80000000,'cntfrq':13000000}
 cases=[]
 def run(name,overrides=None,*,early=False,load_offset=0):
  cpu=dict(baseline);cpu.update(overrides or {});start=head+load_offset
  u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(start,len(raw),UC_PROT_READ|UC_PROT_WRITE);initial=bytearray(raw)
  if name=='corrupt_payload':initial[sym['_payload_start']-head]^=1
  u.mem_write(start,bytes(initial));u.mem_protect(start,0x10000,UC_PROT_READ|UC_PROT_WRITE|UC_PROT_EXEC)
  # No executable mapping for source/arena or any instruction of XNU.
  if not early:
   source=sym['_payload_start'];source_size=sym['_payload_end']-source;u.mem_protect(source,(source_size+4095)&~4095,UC_PROT_READ)
   u.mem_protect(sym['image_el1_vectors'],4096,UC_PROT_READ|UC_PROT_EXEC)
   fd=fdt_fixture(include=name!='missing_mblock')
   if name=='bad_fdt_magic':fd[0]=0
   u.mem_map(0x47880000,0x80000,UC_PROT_READ|UC_PROT_WRITE);u.mem_write(0x47880000,bytes(fd));u.mem_protect(0x47880000,0x80000,UC_PROT_READ)
  fdt_pointer=0x47881000 if name=='wrong_dtb_pointer' else 0x47880000
  u.reg_write(A.UC_ARM64_REG_X0,fdt_pointer);u.reg_write(A.UC_ARM64_REG_SP,0xdeadbeef)
  control=[];stops=[];data_events=[];prefix_writes=[]
  def pc(n):return sym[n]+load_offset
  reads={pc('image_read_el'):('x19',cpu['el']),pc('image_read_sctlr'):('x20',cpu['sctlr']),pc('image_read_hcr'):('x21',cpu['hcr']),pc('image_read_mpidr'):('x9',cpu['mpidr']),pc('image_read_cntfrq'):('x22',cpu['cntfrq']),pc('stage0_gate_el'):('x3',cpu['el']),pc('stage0_gate_sctlr'):('x3',cpu['sctlr']),pc('stage0_gate_hcr'):('x3',cpu['hcr'])}
  def reg(n):return u.reg_read(getattr(A,'UC_ARM64_REG_'+n.upper()))
  def code(uc,address,size,user):
   if address==pc('image_wait'):stops.append('prepare_only_park');u.emu_stop();return
   if address in reads:
    r,v=reads[address];u.reg_write(getattr(A,'UC_ARM64_REG_'+r.upper()),v);u.reg_write(A.UC_ARM64_REG_PC,address+4);return
   ins=next(md.disasm(bytes(u.mem_read(address,4)),address))
   if ins.mnemonic=='msr':
    dest,src=[x.strip() for x in ins.op_str.split(',')];assert dest in ['daifset','spsel','vbar_el2'],(address,ins.op_str)
    value=int(src[1:],0) if src.startswith('#') else reg(src);control.append((dest,value));u.reg_write(A.UC_ARM64_REG_PC,address+4)
  u.hook_add(UC_HOOK_CODE,code,begin=pc('image_start'),end=pc('image_start_asm_end'))
  u.hook_add(UC_HOOK_CODE,code,begin=pc('dandelion_stage0_fdt_gate'),end=pc('stage0_gate_fail')+4)
  if early:u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,lambda uc,access,address,size,value,user:data_events.append((access,address,size)))
  else:
   def write_guard(uc,access,address,size,value,user):
    allowed=any(lo<=address and address+size<=hi for lo,hi in [(sym['_bss_start'],sym['_bss_end']),(sym['_el2_stack_bottom'],sym['_el2_stack_top'])]);assert allowed,('unexpected prefix write',hex(address),size)
    prefix_writes.append((address,size))
   u.hook_add(UC_HOOK_MEM_WRITE,write_guard,begin=head,end=sym['_loader_end']-1)
  u.emu_start(start,0,timeout=120000000,count=500000000)
  assert stops==['prepare_only_park'],('did not reach intended park',name,hex(u.reg_read(A.UC_ARM64_REG_PC)))
  if early:
   assert not data_events and not control,(name,'early rejection touched data/control',data_events[:3],control)
   assert bytes(u.mem_read(start,len(raw)))==bytes(initial)
   cases.append({'case':name,'early_rejected':True,'data_memory_events':0,'image_unchanged':True});return
  assert control==[('daifset',15),('spsel',1),('vbar_el2',sym['image_el2_vectors'])],control
  after=bytes(u.mem_read(head,len(raw)));record=struct.unpack('<18Q',u.mem_read(sym['image_record'],144));assert record[0:2]==(0x44414e44494d4731,1)
  status={'valid':0,'wrong_dtb_pointer':506,'bad_fdt_magic':601,'missing_mblock':604,'corrupt_payload':2}[name]
  assert record[3]==status,(name,record);assert record[2]==(4 if status==0 else 3)
  expected=bytearray(initial)
  if status==0:
   digest=check_mapping(bytes(u.mem_read(base,window)),payload,layout['payload_report'],(record[14],record[15],record[15]+4096),fill=0)
   expected[base-head:base-head+window]=u.mem_read(base,window)
   assert (record[16],record[17])==(sym['_el1_stack_top'],sym['image_el1_vectors'])
  else:
   digest=None;assert not any(u.mem_read(base,window)),'rejection wrote kernel destination'
  for lo,hi in [(sym['_bss_start'],sym['_bss_end']),(sym['_el2_stack_bottom'],sym['_el2_stack_top'])]:expected[lo-head:hi-head]=after[lo-head:hi-head]
  assert after==bytes(expected),'Image modified outside exact kernel/BSS/private EL2 stack'
  assert bytes(u.mem_read(0x47880000,len(fd)))==bytes(fd)
  cases.append({'case':name,'status':status,'phase':record[2],'kernel_window_sha256':digest,'source_and_image_guards_preserved':True,'prefix_writes':len(prefix_writes),'entry_pa_prepared':record[14],'xnu_executed':False})
 run('valid')
 run('wrong_el',{'el':4},early=True)
 for bit in [0,2,12,25]:run('sctlr_'+str(bit),{'sctlr':baseline['sctlr']|1<<bit},early=True)
 run('stage2',{'hcr':1},early=True);run('secondary_cpu',{'mpidr':0x80000001},early=True);run('wrong_frequency',{'cntfrq':24000000},early=True);run('wrong_loadbase',early=True,load_offset=0x100000)
 for name in ['wrong_dtb_pointer','bad_fdt_magic','missing_mblock','corrupt_payload']:run(name)
 result={'image_sha256':layout['image_sha256'],'kernel_sha256':layout['kernel_sha256'],'complete_raw_image_entry_tested':True,'hardware_tested':False,'loader_eret_present':False,'indirect_nonreturn_branches':False,'direct_branch_targets_confined_to_loader':True,'xnu_executed':False,'privileged_effects':'modeled','predictable_seed_prepare_only':True,'instruction_audit':audit,'cases':cases,'case_count':len(cases),'limitations':['No phone boot test, whole LK/ATF or watchdog model','Caller Image ownership requires exact LK/live FDT profile; early private-prefix setup is based on known LK loading contract','Kernel is copied only; no ERET or XNU code path exists','No storage/framebuffer/controller access or Android Boot packaging']}
 a.out.write_text(json.dumps(result,indent=2)+'\n');print('PASS complete raw Image entry:',len(cases),'cases; private stack/vectors, real kernel copy, no ERET/XNU execution')
if __name__=='__main__':main()
