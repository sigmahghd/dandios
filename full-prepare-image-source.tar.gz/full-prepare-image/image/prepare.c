/* SPDX-License-Identifier: MIT. No ERET/XNU jump path, storage or framebuffer IO. */
#include "prepare.h"
#include "../loader/stage0_fdt_gate.h"
extern uint8_t _head[],_image_end[],_loader_end[],_payload_start[],_payload_end[];
extern uint8_t _kernel_window_start[],_kernel_window_end[],_el1_stack_bottom[],_el1_stack_top[],image_el1_vectors[];
volatile struct image_record image_record;
void full_image_prepare(uint64_t fdt,uint64_t el,uint64_t sctlr,uint64_t hcr,uint64_t freq)
{
 struct policy p;struct handoff_storage s;struct stage0_fdt_context ctx;
 struct range image;struct handoff_args args;int rc;
 /* Volatile accesses to ordinary local objects prevent LLVM from replacing
  * fused constant-field stores with Q-register struct copies before FP setup. */
 volatile struct policy *vp=&p;volatile struct handoff_storage *vs=&s;
 volatile struct stage0_fdt_context *vc=&ctx;volatile struct range *vi=&image;
 image_record.magic=UINT64_C(0x44414e44494d4731);image_record.version=1;image_record.phase=1;
 image_record.status=UINT64_MAX;image_record.fdt=fdt;image_record.current_el=el;
 image_record.sctlr=sctlr;image_record.hcr=hcr;image_record.cntfrq=freq;
 vp->dram.base=0x40000000u;vp->dram.size=0x80000000u;
 vp->approved_window.base=(uintptr_t)_kernel_window_start;vp->approved_window.size=(uintptr_t)_kernel_window_end-(uintptr_t)_kernel_window_start;
 vp->source.base=(uintptr_t)_payload_start;vp->source.size=(uintptr_t)_payload_end-(uintptr_t)_payload_start;
 vp->forbidden=0;vp->forbidden_count=0;
 vs->loader.base=(uintptr_t)_head;vs->loader.size=(uintptr_t)_loader_end-(uintptr_t)_head;
 vs->input_fdt.base=fdt;vs->input_fdt.size=0; /* Only the live header supplies size. */
 vs->el1_stack.base=(uintptr_t)_el1_stack_bottom;vs->el1_stack.size=(uintptr_t)_el1_stack_top-(uintptr_t)_el1_stack_bottom;
 vs->el1_vectors.base=(uintptr_t)image_el1_vectors;vs->el1_vectors.size=2048;
 vi->base=(uintptr_t)_head;vi->size=(uintptr_t)_image_end-(uintptr_t)_head;
 vc->source=_payload_start;vc->source_size=(size_t)vp->source.size;vc->policy=&p;
 vc->mapping=_kernel_window_start;vc->mapping_size=(size_t)vp->approved_window.size;vc->storage=&s;vc->image=&image;
 image_record.source=vp->source.base;image_record.source_size=vp->source.size;
 image_record.window=vp->approved_window.base;image_record.window_size=vp->approved_window.size;image_record.image_end=(uintptr_t)_image_end;
 image_record.phase=2;
 rc=dandelion_stage0_fdt_gate((const uint8_t *)(uintptr_t)fdt,&ctx,&args);
 image_record.status=(uint64_t)(unsigned)rc;
 if(rc){image_record.phase=3;return;}
 image_record.entry=args.entry;image_record.bootargs=args.bootargs;image_record.stack_top=args.stack_top;image_record.vectors=args.vectors;
 /* Deliberately no handoff here. This Image can only prepare, record and park. */
 image_record.phase=4;
}
