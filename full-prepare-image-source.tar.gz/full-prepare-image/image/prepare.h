/* SPDX-License-Identifier: MIT -- diagnostic PREPARE ONLY, never execute XNU. */
#ifndef DANDELION_IMAGE_PREPARE_H
#define DANDELION_IMAGE_PREPARE_H
#include <stdint.h>
struct image_record {
 uint64_t magic,version,phase,status,fdt,current_el,sctlr,hcr,cntfrq;
 uint64_t source,source_size,window,window_size,image_end;
 uint64_t entry,bootargs,stack_top,vectors;
};
extern volatile struct image_record image_record;
void full_image_prepare(uint64_t fdt,uint64_t el,uint64_t sctlr,uint64_t hcr,uint64_t freq);
#endif
