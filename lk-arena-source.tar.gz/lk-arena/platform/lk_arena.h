/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_LK_ARENA_H
#define DANDELION_LK_ARENA_H
#include "handoff_contract.h"
#define LK_MBLOCK_V2_BYTES 22552u
struct lk_arena_result {struct range kernel_reservation,dtb_reservation,image;uint32_t free_count,reserved_count;};
enum lk_arena_error { LK_ARENA_ARGUMENT=500,LK_ARENA_FORMAT=501,LK_ARENA_RANGE=502,LK_ARENA_COLLISION=503,LK_ARENA_LABEL=504,LK_ARENA_IMAGE=505,LK_ARENA_FDT=506 };
/* Pure bounded reader of one exact MT6765 LK mblock v2 wire layout.
 * Checks a self-contained Image extent, not an arbitrary free-RAM allocation.
 * No trust/freshness/CPU/permission/cache proof. Caller MUST obtain Image bounds
 * from executing code and mblock bytes from the actual incoming live FDT.
 * Recovery snapshots are useful only as offline format evidence.
 * Does not authenticate LK, parse FDT, copy bytes, jump, or access MMIO.
 * All inputs readable/stable; out writable and not aliasing any inputs.
 * Success commits result; any failure leaves out unchanged.
 */
int dandelion_lk_arena(const uint8_t *mblock,size_t n,const struct policy *,
 const struct handoff_storage *,const struct range *image,struct lk_arena_result *out);
#endif
