/* SPDX-License-Identifier: MIT */
#include "lk_arena.h"
#define BANKS 8u
#define MAGIC 3080u
#define RESERVED_COUNT 3088u
#define RESERVED 3096u
#define RECORD 152u
static uint32_t u32(const uint8_t *b){return (uint32_t)b[0]|(uint32_t)b[1]<<8|(uint32_t)b[2]<<16|(uint32_t)b[3]<<24;}
static uint64_t u64(const uint8_t *b){return u32(b)|(uint64_t)u32(b+4)<<32;}
static struct range read_range(const uint8_t *b){struct range r;r.base=u64(b);r.size=u64(b+8);return r;}
static int valid(struct range r){return r.size&&r.base<=UINT64_MAX-r.size;}
static int inside(struct range a,struct range b){return valid(a)&&valid(b)&&b.base>=a.base&&b.size<=a.size&&b.base-a.base<=a.size-b.size;}
static int overlap(struct range a,struct range b){return a.size&&b.size&&a.base<b.base+b.size&&b.base<a.base+a.size;}
static int alias(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;return !a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y||(x<y+bn&&y<x+an);}
static int label(const uint8_t *b,const char *s){size_t i;for(i=0;i<128;i++){if(b[i]!=(uint8_t)s[i])return 0;if(!b[i])return 1;}return 0;}
static int terminated(const uint8_t *b){size_t i;for(i=0;i<128;i++)if(!b[i])return 1;return 0;}
int dandelion_lk_arena(const uint8_t *b,size_t n,const struct policy *p,
 const struct handoff_storage *s,const struct range *image,struct lk_arena_result *out)
{
 struct lk_arena_result result;struct range a,c,roles[5];uint32_t nf,nr,i,j,kernel=UINT32_MAX,dtb=UINT32_MAX;size_t z;
 if(!b||n!=LK_MBLOCK_V2_BYTES||!p||!s||!image||!out)return LK_ARENA_ARGUMENT;
 if(p->forbidden_count>128||(p->forbidden_count&&!p->forbidden))return LK_ARENA_ARGUMENT;
 if(alias(out,sizeof *out,b,n)||alias(out,sizeof *out,p,sizeof *p)||alias(out,sizeof *out,s,sizeof *s)||alias(out,sizeof *out,image,sizeof *image)||
    (p->forbidden_count&&alias(out,sizeof *out,p->forbidden,p->forbidden_count*sizeof *p->forbidden)))return LK_ARENA_ARGUMENT;
 if(u32(b+MAGIC)!=0x99999999u||u32(b+MAGIC+4)!=2)return LK_ARENA_FORMAT;
 nf=u32(b);nr=u32(b+RESERVED_COUNT);if(!nf||nf>128||!nr||nr>128)return LK_ARENA_FORMAT;
 /* This contract is deliberately limited to the observed 2 GiB dandelion profile. */
 if(p->dram.base!=0x40000000u||p->dram.size!=0x80000000u)return LK_ARENA_RANGE;
 for(i=0;i<nf;i++){
  a=read_range(b+BANKS+24*i);
  if(!a.size){if(a.base<p->dram.base||a.base>p->dram.base+p->dram.size)return LK_ARENA_RANGE;continue;}
  if(!inside(p->dram,a))return LK_ARENA_RANGE;
  for(j=0;j<i;j++){c=read_range(b+BANKS+24*j);if(overlap(a,c))return LK_ARENA_COLLISION;}
 }
 for(i=0;i<nr;i++){
  const uint8_t *record=b+RESERVED+RECORD*i;
  a=read_range(record);if(!inside(p->dram,a))return LK_ARENA_RANGE;
  if(u32(record+16)>1||!terminated(record+20))return LK_ARENA_FORMAT;
  for(j=0;j<i;j++){c=read_range(b+RESERVED+RECORD*j);if(overlap(a,c))return LK_ARENA_COLLISION;}
  for(j=0;j<nf;j++){c=read_range(b+BANKS+24*j);if(overlap(a,c))return LK_ARENA_COLLISION;}
  if(label(record+20,"kernel_addr_mb")){if(kernel!=UINT32_MAX)return LK_ARENA_LABEL;kernel=i;}
  if(label(record+20,"dtb_kernel_addr_mb")){if(dtb!=UINT32_MAX)return LK_ARENA_LABEL;dtb=i;}
 }
 if(kernel==UINT32_MAX||dtb==UINT32_MAX)return LK_ARENA_LABEL;
 a=read_range(b+RESERVED+RECORD*kernel);c=read_range(b+RESERVED+RECORD*dtb);
 if(a.base!=0x40080000u||a.size!=0x07800000u||u32(b+RESERVED+RECORD*kernel+16)!=0)return LK_ARENA_IMAGE;
 if(c.base!=0x47880000u||c.size!=0x80000u||u32(b+RESERVED+RECORD*dtb+16)!=1)return LK_ARENA_FDT;
 if(image->base!=a.base||(image->size&4095)||!inside(a,*image))return LK_ARENA_IMAGE;
 roles[0]=p->approved_window;roles[1]=p->source;roles[2]=s->loader;roles[3]=s->el1_stack;roles[4]=s->el1_vectors;
 for(i=0;i<5;i++)if(!inside(*image,roles[i]))return LK_ARENA_IMAGE;
 if(s->loader.base!=image->base||!inside(c,s->input_fdt))return LK_ARENA_FDT;
 for(i=0;i<5;i++)for(j=0;j<i;j++)if(overlap(roles[i],roles[j]))return LK_ARENA_COLLISION;
 for(i=0;i<p->forbidden_count;i++){
  if(!valid(p->forbidden[i]))return LK_ARENA_RANGE;
  if(overlap(*image,p->forbidden[i])||overlap(s->input_fdt,p->forbidden[i]))return LK_ARENA_COLLISION;
 }
 /* Byte accesses prevent implicit memcpy/FP in freestanding early startup. */
 {volatile uint8_t *d=(volatile uint8_t *)&result.kernel_reservation;const volatile uint8_t *v=(const volatile uint8_t *)&a;for(z=0;z<sizeof a;z++)d[z]=v[z];}
 {volatile uint8_t *d=(volatile uint8_t *)&result.dtb_reservation;const volatile uint8_t *v=(const volatile uint8_t *)&c;for(z=0;z<sizeof c;z++)d[z]=v[z];}
 {volatile uint8_t *d=(volatile uint8_t *)&result.image;const volatile uint8_t *v=(const volatile uint8_t *)image;for(z=0;z<sizeof *image;z++)d[z]=v[z];}
 result.free_count=nf;result.reserved_count=nr;
 {volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *v=(const volatile uint8_t *)&result;for(z=0;z<sizeof result;z++)d[z]=v[z];}
 return 0;
}
