#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Synthetic mblock v2 corruption tests, no phone or snapshot required."""
import ctypes as C,platform,struct,subprocess,unittest
from pathlib import Path
from test_handoff_contract import Range,Policy,Storage,Args
R=Path(__file__).resolve().parents[1]
class Arena(C.Structure):_fields_=[('kernel',Range),('dtb',Range),('image',Range),('free_count',C.c_uint32),('reserved_count',C.c_uint32)]
def fixture():
 b=bytearray(22552);struct.pack_into('<I',b,0,1);struct.pack_into('<QQII',b,8,0x80000000,0x40000000,0,0);struct.pack_into('<III',b,3080,0x99999999,2,3)
 for i,(base,size,mapv,name) in enumerate([(0x40080000,0x7800000,0,b'kernel_addr_mb'),(0x47880000,0x80000,1,b'dtb_kernel_addr_mb'),(0x70000000,0x2a00000,0,b'teei-reserved')]):
  p=3096+152*i;struct.pack_into('<QQI',b,p,base,size,mapv);b[p+20:p+20+len(name)]=name
 return b
def layout(source_size=0x1000000):
 p=Policy(Range(0x40000000,0x80000000),Range(0x41200000,0x2000000),Range(0x40090000,source_size),None,0)
 s=Storage(Range(0x40080000,0x10000),Range(0x47880000,0x20000),Range(0x43204000,0x4000),Range(0x43200000,0x800))
 image=Range(0x40080000,0x43210000-0x40080000)
 return p,s,image
so=R/'tests/lk-arena-test.so'
subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',str(R/'platform/lk_arena.c'),'-o',str(so)],check=True)
f=C.CDLL(str(so)).dandelion_lk_arena;f.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.POINTER(Storage),C.POINTER(Range),C.POINTER(Arena)];f.restype=C.c_int
class Tests(unittest.TestCase):
 def setUp(self):self.b=fixture();self.p,self.s,self.image=layout();self.out=Arena();C.memset(C.byref(self.out),0xa5,C.sizeof(self.out))
 def call(self):
  self.buf=C.create_string_buffer(bytes(self.b));return f(self.buf,len(self.b),C.byref(self.p),C.byref(self.s),C.byref(self.image),C.byref(self.out))
 def reject(self,rc):
  before=bytes(self.out);raw=bytes(self.b);self.assertEqual(self.call(),rc);self.assertEqual(bytes(self.out),before);self.assertEqual(bytes(self.b),raw)
 def w(self,offset,fmt,*v):struct.pack_into('<'+fmt,self.b,offset,*v)
 def test_valid(self):
  self.assertEqual(self.call(),0);self.assertEqual((self.out.kernel.base,self.out.kernel.size),(0x40080000,0x7800000));self.assertEqual((self.out.free_count,self.out.reserved_count),(1,3))
 def test_truncated(self):self.b.pop();self.reject(500)
 def test_extended(self):self.b.append(0);self.reject(500)
 def test_magic(self):self.w(3080,'I',0);self.reject(501)
 def test_version(self):self.w(3084,'I',3);self.reject(501)
 def test_no_banks(self):self.w(0,'I',0);self.reject(501)
 def test_many_banks(self):self.w(0,'I',129);self.reject(501)
 def test_many_reservations(self):self.w(3088,'I',129);self.reject(501)
 def test_empty_reservations(self):self.w(3088,'I',0);self.reject(501)
 def test_free_overflow(self):self.w(8,'QQ',(1<<64)-4096,8192);self.reject(502)
 def test_free_reserved_collision(self):self.w(8,'QQ',0x40080000,4096);self.reject(503)
 def test_free_free_collision(self):self.w(0,'I',2);self.w(32,'QQII',0x80000000,4096,0,0);self.reject(503)
 def test_zero_free_entry_allowed(self):self.w(0,'I',2);self.w(32,'QQII',0x47d80000,0,0,0);self.assertEqual(self.call(),0)
 def test_zero_reserved(self):self.w(3096+8,'Q',0);self.reject(502)
 def test_reserved_overflow(self):self.w(3096,'QQ',(1<<64)-4096,8192);self.reject(502)
 def test_reserved_reserved_collision(self):self.w(3096+152*2,'QQ',0x40090000,4096);self.reject(503)
 def test_unterminated_name(self):self.b[3096+20:3096+148]=b'x'*128;self.reject(501)
 def test_unknown_map(self):self.w(3096+16,'I',2);self.reject(501)
 def test_missing_kernel(self):self.b[3096+20]=ord('x');self.reject(504)
 def test_duplicate_kernel_label(self):start=3096+152*2+20;self.b[start:start+128]=b'kernel_addr_mb'.ljust(128,b'\0');self.reject(504)
 def test_missing_dtb(self):self.b[3096+152+20]=ord('x');self.reject(504)
 def test_kernel_size_changed(self):self.w(3096+8,'Q',0x7700000);self.reject(505)
 def test_kernel_mapping_changed(self):self.w(3096+16,'I',1);self.reject(505)
 def test_dtb_mapping_changed(self):self.w(3096+152+16,'I',0);self.reject(506)
 def test_wrong_dram(self):self.p.dram.size=0x100000000;self.reject(502)
 def test_image_start(self):self.image.base+=4096;self.reject(505)
 def test_image_not_page_sized(self):self.image.size-=1;self.reject(505)
 def test_image_too_large(self):self.image.size=0x7900000;self.reject(505)
 def test_old_arbitrary_window_denied(self):self.p.approved_window.base=0x90000000;self.reject(505)
 def test_source_outside_image(self):self.p.source.base=0x52000000;self.reject(505)
 def test_stack_outside_image(self):self.s.el1_stack.base=0x60000000;self.reject(505)
 def test_loader_not_image_start(self):self.s.loader.base+=4096;self.reject(506)
 def test_fdt_outside_own_reservation(self):self.s.input_fdt.base=0x47900000;self.reject(506)
 def test_role_collision(self):self.s.el1_vectors.base=self.s.el1_stack.base;self.reject(503)
 def test_forbidden_image(self):
  self.forbidden=(Range*1)(Range(0x42000000,4096));self.p.forbidden=self.forbidden;self.p.forbidden_count=1;self.reject(503)
 def test_forbidden_overflow(self):
  self.forbidden=(Range*1)(Range((1<<64)-1,4096));self.p.forbidden=self.forbidden;self.p.forbidden_count=1;self.reject(502)
 def test_out_alias_image(self):
  self.buf=C.create_string_buffer(bytes(self.b));old=bytes(self.image);rc=f(self.buf,len(self.b),C.byref(self.p),C.byref(self.s),C.byref(self.image),C.cast(C.byref(self.image),C.POINTER(Arena)));self.assertEqual(rc,500);self.assertEqual(bytes(self.image),old)
 def test_null(self):self.assertEqual(f(None,22552,C.byref(self.p),C.byref(self.s),C.byref(self.image),C.byref(self.out)),500)
if __name__=='__main__':unittest.main()
