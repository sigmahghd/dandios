"""Real LK placement function + real mblock allocator on SYNTHETIC free banks.
Not a snapshot of device mblock, not whole LK/ATF or hardware emulation.
"""
#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
from pathlib import Path
import argparse,ctypes as C
from test_lk_arena import f,layout,Arena
import struct,json,hashlib
from unicorn import *
from unicorn.arm_const import *
p=argparse.ArgumentParser(description='Isolated exact LK allocator differential. No MMIO, no firmware writing.');p.add_argument('--lk',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
if args.out.exists():p.error('refusing existing output')
B=args.lk.read_bytes()
assert hashlib.sha256(B).hexdigest()=='aea8abdf754b3e80b2b76a448e15767830eda23577645e28c3c2310f14342802'
def A(x):return 0x48000000+x-512

def run(banks):
 u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
 u.mem_map(0x48000000,0x200000);u.mem_write(0x48000000,B[512:512+0xcdb24]);u.mem_map(0x50000000,0x40000)
 def put(p,v):u.mem_write(p,struct.pack('<I',v))
 arg=0x50010000;info=arg+0x48;params=0x50002000
 put(0x48164658,arg);put(arg+0xc50,0x99999999);put(arg+0xc54,2)
 put(info,len(banks))
 for i,(start,length) in enumerate(banks):u.mem_write(info+8+24*i,struct.pack('<QQII',start,length,0,0))
 put(0x480dc1b8,1)
 for off,value in {0xc:0x40080000,0x14:0x51b00000,0x20:0x47880000}.items():put(params+off,value)
 u.reg_write(UC_ARM_REG_SP,0x5003f000);u.reg_write(UC_ARM_REG_LR,0x50003001);u.reg_write(UC_ARM_REG_R0,params)
 result={'synthetic_free_banks':[[hex(x),hex(y)] for x,y in banks]};logs=[]
 def hook(uc,pc,size,data):
  if pc==A(0x34328):
   p=u.reg_read(UC_ARM_REG_R0);logs.append(bytes(u.mem_read(p,180)).split(b'\0')[0].decode(errors='replace'));u.reg_write(UC_ARM_REG_R0,0);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
  elif pc==A(0x1edfc):u.reg_write(UC_ARM_REG_R0,0);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
  elif pc==A(0x3447c):
   ep=struct.unpack('<I',u.mem_read(u.reg_read(UC_ARM_REG_SP),4))[0]
   result.update(outcome='assert',expression=bytes(u.mem_read(ep,160)).split(b'\0')[0].decode(errors='replace'),line=u.reg_read(UC_ARM_REG_R3));u.emu_stop()
  elif pc==0x50003000:result['outcome']='returned';u.emu_stop()
 u.hook_add(UC_HOOK_CODE,hook);u.emu_start(A(0x21e14)|1,0,count=2000000)
 result.update(kernel=hex(struct.unpack('<I',u.mem_read(params+0xc,4))[0]),ramdisk=hex(struct.unpack('<I',u.mem_read(params+0x14,4))[0]),dtb=hex(struct.unpack('<I',u.mem_read(params+0x20,4))[0]),logs=logs)
 assert 'outcome' in result,'budget exhausted'
 result['_mblock']=bytes(u.mem_read(info,22552));return result

policy,storage,image=layout();cases=[]
for banks in [[(0x40000000,0x80000000)],[(0x40000000,0x7c80000),(0x47dd0000,0x22230000)]]:
 result=run(banks);blob=result.pop('_mblock');assert result['outcome']=='returned'
 buffer=C.create_string_buffer(blob);out=Arena()
 rc=f(buffer,len(blob),C.byref(policy),C.byref(storage),C.byref(image),C.byref(out));assert rc==0,rc
 cases.append({'synthetic_banks':[[hex(a),hex(b)] for a,b in banks],'c_parser_return':rc,'kernel':[hex(out.kernel.base),hex(out.kernel.size)],'dtb':[hex(out.dtb.base),hex(out.dtb.size)]})
report={'lk_sha256':hashlib.sha256(B).hexdigest(),'scope':__doc__,'whole_lk_emulated':False,'mmio_mapped':False,'mocked':'log printing and debug-level query only; synthetic input banks/boot args','cases':cases}
args.out.write_text(json.dumps(report,indent=2)+'\n');print('PASS exact LK allocator -> actual C mblock parser:',len(cases),'synthetic bank layouts; no hardware claim')
