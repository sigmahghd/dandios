#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Actual ARM64 mblock arena+copy+contract+handoff instructions, but privileged effects modeled.
ERET intercepted BEFORE execution. Kernel memory non-executable. No phone image.
"""
import argparse,hashlib,io,json,struct,sys
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE,UC_PROT_READ,UC_PROT_WRITE,UC_PROT_EXEC
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
import unicorn.arm64_const as A
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from pack_kernel_fixture import package_fixture,BASE,SOURCE,WINDOW,align
from test_real_kernel_fixture import check_mapping
from test_lk_arena import fixture
BASE=0x41200000;SOURCE=0x40090000
CODE=0x40080000;TEMP=0x41100000;RETURN=TEMP+0xf000

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 kernel=a.kernel.read_bytes();assert hashlib.sha256(kernel).hexdigest()==a.expect_sha256
 if a.out.exists():p.error('refusing existing output')
 payload,report=package_fixture(kernel,base=BASE,source=SOURCE,window=WINDOW)
 e=ELFFile(io.BytesIO((R/'tests/prepare-in-image-arm64.elf').read_bytes()));sym={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
 assert not [s.name for s in sym.values() if s.name and s['st_shndx']=='SHN_UNDEF']
 assert e.header['e_entry']==sym['dandelion_prepare_in_image']['st_value']
 codebytes=[(s['p_vaddr'],s['p_memsz'],s.data()) for s in e.iter_segments() if s['p_type']=='PT_LOAD' and s['p_filesz']]
 md=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
 def setup(negative=None):
  u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(CODE,0x10000);u.mem_map(TEMP,0x100000,UC_PROT_READ|UC_PROT_WRITE)
  u.mem_map(SOURCE,align(len(payload)),UC_PROT_READ|UC_PROT_WRITE);u.mem_write(SOURCE,payload);u.mem_protect(SOURCE,align(len(payload)),UC_PROT_READ)
  u.mem_map(BASE,WINDOW,UC_PROT_READ|UC_PROT_WRITE);u.mem_write(BASE,b'\xa5'*WINDOW)
  # Explicit private regions in THE MODEL, not claims about live LK ownership.
  u.mem_map(0x43200000,4096,UC_PROT_READ|UC_PROT_EXEC);u.mem_map(0x43204000,0x4000,UC_PROT_READ|UC_PROT_WRITE)
  u.mem_map(0x47880000,0x20000,UC_PROT_READ|UC_PROT_WRITE)
  mb=fixture()
  if negative=='bad_mblock_version':struct.pack_into('<I',mb,3084,1)
  if negative=='free_reserved_overlap':struct.pack_into('<QQ',mb,8,0x40080000,4096)
  u.mem_write(0x47881000,bytes(mb));u.mem_protect(0x47880000,0x20000,UC_PROT_READ)
  for va,ms,data in codebytes:
   assert va+ms<=0x10000;u.mem_write(CODE+va,data)
  u.mem_protect(CODE,0x10000,UC_PROT_READ|UC_PROT_EXEC)
  storage=[CODE,0x10000,0x47880000,0x20000,0x43204000,0x4000,0x43200000,0x800]
  if negative=='stack_in_kernel':storage[4]=BASE+4096
  if negative=='vectors_in_loader':storage[6]=CODE
  if negative=='short_stack':storage[5]=8192
  u.mem_write(TEMP+0x1000,struct.pack('<8Q',0x40000000,0x80000000,BASE,WINDOW,SOURCE,len(payload),0,0))
  u.mem_write(TEMP+0x2000,struct.pack('<8Q',*storage));u.mem_write(TEMP+0x3000,b'\xa5'*32)
  u.mem_write(TEMP+0x4000,struct.pack('<QQ',CODE,0x43210000-CODE))
  for i,v in enumerate([SOURCE,len(payload),TEMP+0x1000,BASE,WINDOW,TEMP+0x2000,TEMP+0x4000,0x47881000]):u.reg_write(getattr(A,'UC_ARM64_REG_X'+str(i)),v)
  u.mem_write(TEMP+0xff000,struct.pack('<QQ',22552,TEMP+0x3000))
  u.reg_write(A.UC_ARM64_REG_SP,TEMP+0xff000);u.reg_write(A.UC_ARM64_REG_X30,RETURN)
  u.emu_start(CODE+sym['dandelion_prepare_in_image']['st_value'],RETURN,timeout=120000000,count=350000000)
  assert u.reg_read(A.UC_ARM64_REG_PC)==RETURN,'prepare did not return within limits'
  rc=u.reg_read(A.UC_ARM64_REG_X0)
  if negative:
   assert rc=={'stack_in_kernel':503,'vectors_in_loader':503,'short_stack':402,'bad_mblock_version':501,'free_reserved_overlap':503}[negative]
   assert bytes(u.mem_read(BASE,WINDOW))==b'\xa5'*WINDOW and bytes(u.mem_read(TEMP+0x3000,32))==b'\xa5'*32
   return {'case':negative,'return_code':rc,'destination_unchanged':True,'output_unchanged':True}
  assert rc==0;args=struct.unpack('<4Q',u.mem_read(TEMP+0x3000,32));assert args[2:]==(0x43208000,0x43200000)
  digest=check_mapping(bytes(u.mem_read(BASE,WINDOW)),payload,report,(args[0],args[1],args[1]+4096))
  assert bytes(u.mem_read(SOURCE,len(payload)))==payload
  return u,args,digest
 u,args,digest=setup();cases=[]
 def handoff(name,override=None,locked=None):
  state={'currentel':8,'sctlr_el2':0x30c50830,'hcr_el2':0,'icc_sre_el2':0};state.update(override or {})
  trace=[];stop=[]
  for i,v in enumerate(args):u.reg_write(getattr(A,'UC_ARM64_REG_X'+str(i)),v)
  def regval(n):return 0 if n=='xzr' else u.reg_read(getattr(A,'UC_ARM64_REG_'+n.upper()))
  def hook(uc,pc,size,user):
   if pc==CODE+sym['handoff_park']['st_value']:stop.append('rejected');u.emu_stop();return
   ins=next(md.disasm(bytes(u.mem_read(pc,4)),pc));op=ins.mnemonic
   if op=='mrs':
    dst,src=ins.op_str.split(', ');value=locked if src=='icc_sre_el2' and locked is not None else state[src]
    u.reg_write(getattr(A,'UC_ARM64_REG_'+dst.upper()),value);trace.append(['read',src,value]);u.reg_write(A.UC_ARM64_REG_PC,pc+4)
   elif op=='msr':
    target,src=ins.op_str.split(', ');v=int(src[1:],0) if src.startswith('#') else regval(src);state[target]=v;trace.append(['write',target,v]);u.reg_write(A.UC_ARM64_REG_PC,pc+4)
   elif op in ('dsb','isb','ic','tlbi'):
    trace.append([op,ins.op_str]);u.reg_write(A.UC_ARM64_REG_PC,pc+4)
   elif op=='eret':stop.append('prepared_eret_not_executed');u.emu_stop()
  def no_memory(*unused):raise AssertionError('handoff must not dereference data memory')
  handles=[u.hook_add(UC_HOOK_CODE,hook,begin=CODE+sym['dandelion_enter_xnu_el2']['st_value'],end=CODE+sym['handoff_park']['st_value']+4),u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,no_memory)]
  u.emu_start(CODE+sym['dandelion_enter_xnu_el2']['st_value'],0,count=10000)
  for h in handles:u.hook_del(h)
  assert len(stop)==1
  if name=='valid':
   assert stop==['prepared_eret_not_executed']
   for k,v in {'elr_el2':args[0],'spsr_el2':0x3c5,'sp_el1':args[2],'vbar_el1':args[3],'hcr_el2':1<<31,'vttbr_el2':0,'cntvoff_el2':0,'cnthctl_el2':3,'cntv_ctl_el0':0,'cntp_ctl_el0':0,'icc_sre_el2':9}.items():assert state[k]==v,(k,state)
   assert [u.reg_read(getattr(A,'UC_ARM64_REG_X'+str(i))) for i in range(4)]==[args[1],0,0,0]
   # Kernel destination must still exactly match the validated copied image.
   assert hashlib.sha256(bytes(u.mem_read(BASE,WINDOW))).hexdigest()==digest
  else:assert stop==['rejected'] and u.reg_read(A.UC_ARM64_REG_X19)==0x4439414641494c31
  return {'case':name,'result':stop[0],'privileged_effects':'modeled','eret_executed':False,'kernel_executed':False,'trace':trace}
 cases.append(handoff('valid'))
 for bit in [0,2,12,25]:cases.append(handoff('unsafe_sctlr_'+str(bit),{'sctlr_el2':0x30c50830|(1<<bit)}))
 cases.append(handoff('stage2_active',{'hcr_el2':1}));cases.append(handoff('wrong_EL',{'currentel':4}))
 for v in [0,1]:cases.append(handoff('locked_sre_'+str(v),locked=v))
 rejected=[setup(name) for name in ['stack_in_kernel','vectors_in_loader','short_stack','bad_mblock_version','free_reserved_overlap']]
 out={'kernel_sha256':a.expect_sha256,'synthetic_only':True,'hardware_tested':False,'kernel_executed':False,'eret_executed':False,'actual_arm64_prepare_in_image_and_copy':True,'live_ownership_verified':False,'fdt_extraction_tested':False,'whole_ram_sha256':digest,'copied_kernel_entry_pa_in_model':args[0],'bootargs_pa_in_model':args[1],'el1_stack_top_in_model':args[2],'el1_vectors_in_model':args[3],'contract_rejections_before_copy':rejected,'handoff_cases':cases,'limitations':['mblock fixture and Image ownership asserted only in simulation; no live FDT extraction performed','Privileged registers/cache/TLBI effects modeled, not hardware verified','ERET stopped before execution; no instruction of XNU executed','Unsafe CPU state must be checked by hardware caller before any copy; this model checks handoff rejection only']}
 a.out.write_text(json.dumps(out,indent=2)+'\n');print('PASS actual ARM64 Image-arena mblock check + real-kernel copy +',len(cases),'handoff model cases +',len(rejected),'pre-copy memory rejections; NO XNU execution')
if __name__=='__main__':main()
