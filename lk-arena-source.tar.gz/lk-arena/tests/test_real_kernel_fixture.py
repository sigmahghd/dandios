#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Actual kernel bytes through C loader in synthetic host/ARM64 RAM. Never execute XNU."""
import argparse, ctypes as C, hashlib, io, json, struct, subprocess, sys, unittest, platform
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'tools'))
from pack_kernel_fixture import parse_kernel, package_fixture, BASE, SOURCE, WINDOW, align

class Range(C.Structure): _fields_=[('base',C.c_uint64),('size',C.c_uint64)]
class Policy(C.Structure): _fields_=[('dram',Range),('approved_window',Range),('source',Range),('forbidden',C.POINTER(Range)),('forbidden_count',C.c_size_t)]
class Loaded(C.Structure): _fields_=[('entry',C.c_uint64),('bootargs',C.c_uint64),('top',C.c_uint64)]

def commands(data):
    off=32
    for _ in range(struct.unpack_from('<I',data,16)[0]):
        cmd,size=struct.unpack_from('<II',data,off)
        yield off,cmd,size
        off+=size

def check_mapping(dst,payload,report,out):
    BASE=report['test_window']['base'];WINDOW=report['test_window']['size']
    # Every file byte + BSS + gap + metadata + unused tail, not only screenshots/hash headers.
    expected=bytearray(b'\xa5'*WINDOW)
    for i,s in enumerate(report['segments']):
        start=s['va']-report['virtual_base']; off,fs=struct.unpack_from('<QQ',payload,680+i*32+16)
        expected[start:start+fs]=payload[off:off+fs]
        expected[start+fs:start+s['size']]=b'\0'*(s['size']-fs)
    adt_off,adt_size=struct.unpack_from('<QQ',payload,32)
    adt_pa=report['adt_pa_in_model']; ba=align(adt_pa+adt_size); top=ba+4096
    expected[adt_pa-BASE:adt_pa-BASE+adt_size]=payload[adt_off:adt_off+adt_size]
    boot=dst[ba-BASE:ba-BASE+4096]
    assert boot[:4]==b'\x02\0\x02\0'
    assert struct.unpack_from('<4Q',boot,8)==(report['virtual_base'],BASE,WINDOW,top)
    assert struct.unpack_from('<QI',boot,96)==(report['virtual_base']+adt_pa-BASE,adt_size)
    assert struct.unpack_from('<Q',boot,728)[0]==WINDOW
    assert boot[736:]==bytes(4096-736)
    assert boot[108:108+len(b'-v dandelion-fbcon=1')]==b'-v dandelion-fbcon=1'
    expected[ba-BASE:top-BASE]=boot
    assert dst==expected,'segment/BSS/ADT/gap/tail differs'
    assert tuple(out)==(report['entry_pa_in_model'],ba,top)
    return hashlib.sha256(dst).hexdigest()

class ParseTests(unittest.TestCase):
    def reject(self,b):
        with self.assertRaises(ValueError):parse_kernel(bytes(b))
    def mutate(self,offset,fmt,*vals):
        b=bytearray(KERNEL);struct.pack_into(fmt,b,offset,*vals);return b
    def test_real_kernel(self):
        p=parse_kernel(KERNEL);self.assertEqual(p['virtual_slide'],0)
        self.assertGreater(p['validated_local_unsigned64_relocations'],0)
        self.assertTrue(any(s['name']=='__TEXT_EXEC' for s in p['segments']))
        self.assertTrue(any(s['name']=='__CTF' for s in p['skipped']))
    def test_truncated_header(self):self.reject(KERNEL[:31])
    def test_bad_magic(self):self.reject(self.mutate(0,'I',0xcafebabe))
    def test_arm64e_rejected(self):self.reject(self.mutate(8,'I',2))
    def test_wrong_filetype(self):self.reject(self.mutate(12,'I',12))
    def test_command_size(self):self.reject(self.mutate(36,'I',4))
    def test_unknown_command(self):self.reject(self.mutate(32,'I',0x80000034))
    def test_segment_out_of_file(self):self.reject(self.mutate(32+40,'Q',len(KERNEL)+4096))
    def test_bad_section_count(self):self.reject(self.mutate(32+64,'I',999))
    def test_duplicate_segment(self):
        o=next(o for o,c,n in commands(KERNEL) if c==0x19 and o!=32)
        b=bytearray(KERNEL);b[o+8:o+24]=KERNEL[40:56];self.reject(b)
    def test_data_entry(self):
        o=next(o for o,c,n in commands(KERNEL) if c==5)
        self.reject(self.mutate(o+272,'Q',parse_kernel(KERNEL)['virtual_base']))
    def test_unaligned_entry(self):
        o=next(o for o,c,n in commands(KERNEL) if c==5)
        self.reject(self.mutate(o+272,'Q',parse_kernel(KERNEL)['entry_va']+1))
    def reloc_offset(self):
        o=next(o for o,c,n in commands(KERNEL) if c==11)
        return struct.unpack_from('<I',KERNEL,o+72)[0]
    def test_external_relocation(self):
        o=self.reloc_offset();w=struct.unpack_from('<I',KERNEL,o+4)[0];self.reject(self.mutate(o+4,'I',w|(1<<27)))
    def test_wrong_relocation_type(self):
        o=self.reloc_offset();w=struct.unpack_from('<I',KERNEL,o+4)[0];self.reject(self.mutate(o+4,'I',w|(1<<28)))
    def test_wrong_relocation_section(self):
        o=self.reloc_offset();w=struct.unpack_from('<I',KERNEL,o+4)[0];self.reject(self.mutate(o+4,'I',w&0xff000000))
    def test_duplicate_relocation(self):
        o=self.reloc_offset();b=bytearray(KERNEL);b[o+8:o+16]=b[o:o+8];self.reject(b)
    def test_relocation_pointer_changed(self):
        o=self.reloc_offset();delta=struct.unpack_from('<i',KERNEL,o)[0];p=parse_kernel(KERNEL);va=p['virtual_base']+delta
        seg=next(s for s in p['segments'] if s['va']<=va<s['va']+s['file_size'])
        self.reject(self.mutate(seg['file_offset']+va-seg['va'],'Q',0))
    def test_command_nul(self):
        with self.assertRaises(ValueError):package_fixture(KERNEL,b'-v\0oops')
    def test_command_limit(self):
        with self.assertRaises(ValueError):package_fixture(KERNEL,b'A'*608)


def host_load(payload,report,outdir):
    so=outdir/'loader-host-test.so'
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC','-O2',*[str(R/'loader'/n) for n in ['payload.c','metadata.c','load.c']],'-o',str(so)],check=True)
    lib=C.CDLL(str(so));f=lib.dandelion_load
    f.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.c_void_p,C.c_size_t,C.POINTER(Loaded)];f.restype=C.c_int
    src=C.create_string_buffer(payload);dst=C.create_string_buffer(WINDOW);C.memset(dst,0xa5,WINDOW)
    pol=Policy(Range(0x40000000,0x80000000),Range(BASE,WINDOW),Range(SOURCE,len(payload)),None,0);out=Loaded(1,2,3)
    assert f(src,len(payload),C.byref(pol),dst,WINDOW,C.byref(out))==0
    digest=check_mapping(dst.raw,payload,report,(out.entry,out.bootargs,out.top))
    assert src.raw[:-1]==payload
    # Refusal must occur BEFORE changing any destination bytes or output.
    rejected=[]
    for case in ['denied_window','reserved_overlap','bad_adt']:
        C.memset(dst,0xa5,WINDOW);out=Loaded(1,2,3);copy=bytearray(payload)
        pol.approved_window=Range(BASE,WINDOW);pol.forbidden=None;pol.forbidden_count=0
        if case=='denied_window':pol.approved_window.base+=4096;expected=3
        if case=='reserved_overlap':
            forbidden=(Range*1)(Range(BASE+4096,4096));pol.forbidden=forbidden;pol.forbidden_count=1;expected=4
        if case=='bad_adt':
            ao=struct.unpack_from('<Q',copy,32)[0];copy[ao+8]=0;expected=104
        s=C.create_string_buffer(bytes(copy));rc=f(s,len(copy),C.byref(pol),dst,WINDOW,C.byref(out));assert rc==expected,(case,rc)
        assert dst.raw==b'\xa5'*WINDOW and (out.entry,out.bootargs,out.top)==(1,2,3)
        rejected.append({'case':case,'result':rc,'no_destination_write':True})
    return {'host_mapping_sha256':digest,'copied_runtime_segments':len(report['segments']),'rejection_cases':rejected,'kernel_executed':False}

def arm64_load(payload,report):
    from elftools.elf.elffile import ELFFile
    from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_PROT_READ,UC_PROT_WRITE,UC_PROT_EXEC
    import unicorn.arm64_const as A
    e=ELFFile(io.BytesIO((R/'tests/load-arm64.elf').read_bytes()))
    sym={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
    assert not [s.name for s in sym.values() if s.name and s['st_shndx']=='SHN_UNDEF']
    u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
    code=0x60000000;stack=0x61000000;sentinel=stack+0xf000
    u.mem_map(code,0x10000);u.mem_map(stack,0x100000,UC_PROT_READ|UC_PROT_WRITE)
    # Both source and actual kernel destination are non-executable by design.
    u.mem_map(SOURCE,align(len(payload)),UC_PROT_READ|UC_PROT_WRITE)
    u.mem_map(BASE,WINDOW,UC_PROT_READ|UC_PROT_WRITE)
    for s in e.iter_segments():
        if s['p_type']=='PT_LOAD' and s['p_filesz']:
            assert s['p_vaddr']+s['p_memsz']<=0x10000;u.mem_write(code+s['p_vaddr'],s.data())
    u.mem_protect(code,0x10000,UC_PROT_READ|UC_PROT_EXEC)
    u.mem_write(SOURCE,payload);u.mem_protect(SOURCE,align(len(payload)),UC_PROT_READ)
    u.mem_write(BASE,b'\xa5'*WINDOW);u.mem_write(stack+0x2000,b'\xa5'*24)
    u.mem_write(stack+0x1000,struct.pack('<8Q',0x40000000,0x80000000,BASE,WINDOW,SOURCE,len(payload),0,0))
    for i,v in enumerate([SOURCE,len(payload),stack+0x1000,BASE,WINDOW,stack+0x2000]):u.reg_write(getattr(A,'UC_ARM64_REG_X'+str(i)),v)
    u.reg_write(A.UC_ARM64_REG_SP,stack+0xff000);u.reg_write(A.UC_ARM64_REG_X30,sentinel)
    u.emu_start(code+sym['dandelion_load']['st_value'],sentinel,timeout=120000000,count=300000000)
    assert u.reg_read(A.UC_ARM64_REG_PC)==sentinel,'ARM64 loader did not return within limits'
    assert u.reg_read(A.UC_ARM64_REG_X0)==0
    out=struct.unpack('<3Q',u.mem_read(stack+0x2000,24));dst=bytes(u.mem_read(BASE,WINDOW))
    digest=check_mapping(dst,payload,report,out)
    assert bytes(u.mem_read(SOURCE,len(payload)))==payload
    return {'arm64_mapping_sha256':digest,'real_loader_instructions':True,'source_readonly':True,'kernel_memory_nonexecutable':True,'kernel_executed':False,'hardware_tested':False}

def main():
    global KERNEL
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--arm64',action='store_true');a=p.parse_args()
    KERNEL=a.kernel.read_bytes();assert hashlib.sha256(KERNEL).hexdigest()==a.expect_sha256
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ParseTests);res=unittest.TextTestRunner(verbosity=1).run(suite)
    if not res.wasSuccessful():raise SystemExit(1)
    if a.out.exists():p.error('refusing existing test output directory')
    a.out.mkdir(parents=True)
    payload,report=package_fixture(KERNEL);result={'kernel_sha256':a.expect_sha256,'parser_tests':res.testsRun,'synthetic_only':True,'flashable':False,'hardware_tested':False,'boot_verified':False,**host_load(payload,report,a.out)}
    if a.arm64:
        result.update(arm64_load(payload,report));assert result['host_mapping_sha256']==result['arm64_mapping_sha256']
    (a.out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
