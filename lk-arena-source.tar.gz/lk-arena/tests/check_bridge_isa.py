#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Audit complete early-loader .text, not XNU. Requires pyelftools and capstone."""
import argparse,json,re
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
R=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 if a.out.exists():p.error('refusing existing output')
 result={'cpu':'cortex_a53-neon-fp_armv8-crypto-aes-sha2','scope':'offline loader and handoff only; not XNU ISA audit','files':[]}
 for name in ['tests/load-arm64.elf','tests/prepare-boot-handoff-arm64.elf','tests/prepare-in-image-arm64.elf']:
  with (R/name).open('rb') as f:
   e=ELFFile(f);t=e.get_section_by_name('.text');md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.skipdata=True;ins=list(md.disasm(t.data(),t['sh_addr']))
   bad=[(i.address,i.mnemonic,i.op_str) for i in ins if i.id==0 or re.search(r'\b[vqdshb][0-9]+\b',i.op_str) or re.match(r'^(?:cas|swp|ldadd|stadd|ldapr|pac|aut|retaa|retab|sha|aes)',i.mnemonic)]
   syms=list(e.get_section_by_name('.symtab').iter_symbols());undef=[s.name for s in syms if s.name and s['st_shndx']=='SHN_UNDEF']
   assert not bad,(name,len(bad),bad[:4]);assert not undef,undef;assert sum(i.size for i in ins)==t['sh_size']
   assert all(s['p_vaddr']+s['p_memsz']<=0x10000 for s in e.iter_segments() if s['p_type']=='PT_LOAD')
   result['files'].append({'path':name,'elf_bytes':(R/name).stat().st_size,'text_bytes':t['sh_size'],'instructions':len(ins),'undefined_symbols':undef,'disallowed_instructions':len(bad)})
 a.out.write_text(json.dumps(result,indent=2)+'\n');print('PASS complete early-loader .text: no FP/SIMD, listed extension opcodes, or undefined symbols')
if __name__=='__main__':main()
