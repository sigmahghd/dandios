#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Actual XNU bytes + LK arena contract + actual C loader. Offline only."""
import argparse,ctypes as C,hashlib,json,platform,struct,subprocess,sys,unittest
from pathlib import Path
from test_lk_arena import fixture,layout
from test_handoff_contract import Range,Policy,Storage,Args
from test_real_kernel_fixture import check_mapping
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from pack_kernel_fixture import package_fixture,WINDOW
class Tests(unittest.TestCase):
 def setUp(self):
  self.p,self.s,self.image=layout(len(PAYLOAD));self.mb=fixture();self.src=C.create_string_buffer(PAYLOAD);self.dst=C.create_string_buffer(WINDOW);C.memset(self.dst,0xa5,WINDOW);self.out=Args(1,2,3,4)
 def call(self):
  self.mbuf=C.create_string_buffer(bytes(self.mb));return F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),self.mbuf,len(self.mb),C.byref(self.out))
 def reject(self,rc):
  old=bytes(self.out);self.assertEqual(self.call(),rc);self.assertEqual(bytes(self.out),old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW);self.assertEqual(self.src.raw[:-1],PAYLOAD)
 def test_real_kernel_valid(self):
  self.assertEqual(self.call(),0);self.assertEqual((self.out.stack_top,self.out.vectors),(0x43208000,0x43200000));RESULT['host_mapping_sha256']=check_mapping(self.dst.raw,PAYLOAD,REPORT,(self.out.entry,self.out.bootargs,self.out.bootargs+4096));self.assertEqual(self.src.raw[:-1],PAYLOAD)
 def test_unknown_mblock_version_no_write(self):struct.pack_into('<I',self.mb,3084,1);self.reject(501)
 def test_short_mblock_no_write(self):self.mb.pop();self.reject(500)
 def test_missing_reservation_no_write(self):self.mb[3096+20]=ord('x');self.reject(504)
 def test_old_window_no_write(self):self.p.approved_window.base=0x90000000;self.reject(505)
 def test_source_outside_image_no_write(self):self.p.source.base=0x52000000;self.reject(505)
 def test_oversized_image_no_write(self):self.image.size=0x7900000;self.reject(505)
 def test_free_collision_no_write(self):struct.pack_into('<QQ',self.mb,8,0x40080000,4096);self.reject(503)
 def test_bad_vectors_no_write(self):self.s.el1_vectors.base+=4;self.reject(402)
 def test_short_stack_no_write(self):self.s.el1_stack.size=8192;self.reject(402)
 def test_out_alias_mblock(self):
  self.mbuf=C.create_string_buffer(bytes(self.mb));old=self.mbuf.raw;rc=F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),self.mbuf,len(self.mb),C.cast(self.mbuf,C.POINTER(Args)));self.assertEqual(rc,301);self.assertEqual(self.mbuf.raw,old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
 def test_mapping_alias_mblock(self):
  old=self.dst.raw;rc=F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),self.dst,22552,C.byref(self.out));self.assertEqual(rc,301);self.assertEqual(self.dst.raw,old)
 def test_output_alias_image(self):
  self.mbuf=C.create_string_buffer(bytes(self.mb));old=bytes(self.image);rc=F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),self.mbuf,len(self.mb),C.cast(C.byref(self.image),C.POINTER(Args)));self.assertEqual(rc,301);self.assertEqual(bytes(self.image),old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
def main():
 global PAYLOAD,REPORT,F,RESULT
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();kernel=a.kernel.read_bytes();assert hashlib.sha256(kernel).hexdigest()==a.expect_sha256
 if a.out.exists():p.error('refusing existing output')
 a.out.mkdir(parents=True);PAYLOAD,REPORT=package_fixture(kernel,base=0x41200000,source=0x40090000,window=WINDOW)
 so=a.out.resolve()/'prepare-in-image.so';src=[R/'loader'/n for n in ['load.c','payload.c','metadata.c','prepare_boot.c','prepare_in_image.c']]+[R/'platform'/n for n in ['handoff_contract.c','lk_arena.c']]
 subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',*map(str,src),'-o',str(so)],check=True)
 lib=C.CDLL(str(so));F=lib.dandelion_prepare_in_image;F.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.c_void_p,C.c_size_t,C.POINTER(Storage),C.POINTER(Range),C.c_void_p,C.c_size_t,C.POINTER(Args)];F.restype=C.c_int
 RESULT={'kernel_sha256':a.expect_sha256,'synthetic_only':True,'hardware_tested':False,'kernel_executed':False,'live_ownership_verified':False,'entry_pa_in_model':REPORT['entry_pa_in_model'],'image_base':0x40080000,'image_end':0x43210000,'kernel_window_base':0x41200000,'kernel_window_size':WINDOW}
 res=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));RESULT.update(host_prepare_in_image_tests=res.testsRun,all_passed=res.wasSuccessful());(a.out/'results.json').write_text(json.dumps(RESULT,indent=2)+'\n');print(json.dumps(RESULT,indent=2));raise SystemExit(0 if res.wasSuccessful() else 1)
if __name__=='__main__':main()
