#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Strict fixed-VA Mach-O -> loader fixture. SYNTHETIC RAM ONLY; never a Boot image.
No relocation, signing, MMU setup, entropy provisioning or phone RAM ownership.
The 0x90000000 window is a test-model address, NOT permission to use phone RAM.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path
from mkadt_dandelion import build, serialize

PAGE = 4096
HEADER = 680
MAX_FILE = 64 * 1024 * 1024
MAX_SPAN = 128 * 1024 * 1024
MAX64 = (1 << 64) - 1
BASE = 0x90000000
SOURCE = 0x52000000
WINDOW = 32 * 1024 * 1024

def align(n):
    return (n + PAGE - 1) & -PAGE

def bounded(off, length, total, what):
    if off < 0 or length < 0 or off > total or length > total - off:
        raise ValueError(what + ' out of bounds')

def segname(raw):
    n = raw.split(b'\0', 1)[0]
    if not n or any(c < 32 or c > 126 for c in n):
        raise ValueError('invalid Mach-O segment name')
    return n.decode('ascii')

def parse_kernel(data):
    if not 32 <= len(data) <= MAX_FILE:
        raise ValueError('kernel file size')
    magic, cpu, subtype, typ, count, cmdslen, flags, reserved = struct.unpack_from('<8I', data)
    if (magic, cpu, subtype, typ) != (0xfeedfacf, 0x100000c, 0, 2) or reserved:
        raise ValueError('need thin little-endian plain ARM64 MH_EXECUTE')
    if not 1 <= count <= 128 or cmdslen > 65536:
        raise ValueError('load command limits')
    bounded(32, cmdslen, len(data), 'load commands')
    end = 32 + cmdslen
    pos = 32
    segments, skipped, names = [], [], set()
    sections, local_relocations = [], None
    entry = None
    seen = set()
    for _ in range(count):
        bounded(pos, 8, end, 'load command header')
        cmd, size = struct.unpack_from('<II', data, pos)
        if size < 8 or size % 8:
            raise ValueError('load command size/alignment')
        bounded(pos, size, end, 'load command')
        if cmd == 0x19:  # LC_SEGMENT_64
            if size < 72:
                raise ValueError('short segment command')
            _, _, raw, va, vs, off, fs, maxprot, prot, ns, sf = struct.unpack_from('<II16s4Q4I', data, pos)
            name = segname(raw)
            if name in names:
                raise ValueError('duplicate segment name')
            names.add(name)
            if ns > 256 or size != 72 + 80 * ns:
                raise ValueError('section table size')
            bounded(off, fs, len(data), 'segment file range')
            if va > MAX64 - vs or prot & ~7 or maxprot & ~7 or prot & ~maxprot:
                raise ValueError('segment address/protections')
            for si in range(ns):
                section = pos + 72 + 80 * si
                addr, length, sec_off, sec_align, reloc_off, reloc_n, secflags = struct.unpack_from('<QQ5I', data, section + 32)
                sections.append((addr, length))
                if reloc_n:
                    raise ValueError('section relocations unsupported')
                if vs and (addr < va or length > vs or addr - va > vs - length):
                    raise ValueError('section virtual range')
                if sec_align > 31:
                    raise ValueError('section alignment')
                if length and (secflags & 0xff) not in (1, 0xc, 0x12):
                    bounded(sec_off, length, len(data), 'section file range')
                    if sec_off < off or sec_off - off > fs or length > fs - (sec_off - off):
                        raise ValueError('section outside segment file range')
            if not vs:
                if fs and name != '__CTF':
                    raise ValueError('non-mapped file bytes outside known __CTF debug segment')
                skipped.append({'name': name, 'file_size': fs, 'reason': 'zero VM size; not runtime mapping'})
            else:
                if fs > vs or va % PAGE or vs % PAGE:
                    raise ValueError('segment size/alignment')
                if prot & 2 and prot & 4:
                    raise ValueError('writable executable segment unsupported')
                segments.append({'name': name, 'va': va, 'size': vs, 'file_offset': off, 'file_size': fs, 'initprot': prot})
        elif cmd == 5:  # LC_UNIXTHREAD, ARM_THREAD_STATE64
            if entry is not None or size != 288 or struct.unpack_from('<II', data, pos + 8) != (6, 68):
                raise ValueError('unexpected/duplicate ARM64 thread state')
            entry = struct.unpack_from('<Q', data, pos + 16 + 256)[0]
        elif cmd == 2:  # LC_SYMTAB
            if size != 24:
                raise ValueError('symtab size')
            symoff, nsyms, stroff, strsize = struct.unpack_from('<4I', data, pos + 8)
            bounded(symoff, nsyms * 16, len(data), 'symbol table')
            bounded(stroff, strsize, len(data), 'string table')
        elif cmd == 0xb:  # LC_DYSYMTAB
            if size != 80:
                raise ValueError('dysymtab size')
            fields = struct.unpack_from('<18I', data, pos + 8)
            if fields[5] or fields[15]:
                raise ValueError('undefined symbols or external relocations unsupported')
            bounded(fields[16], fields[17] * 8, len(data), 'local relocations')
            if fields[17] > 1000000:
                raise ValueError('local relocation count limit')
            local_relocations = (fields[16], fields[17])
        elif cmd in (0x1b, 0x32, 0x2a, 0x26):  # UUID, BUILD_VERSION, SOURCE_VERSION, FUNCTION_STARTS
            if cmd == 0x1b and size != 24 or cmd == 0x2a and size != 16:
                raise ValueError('informational command size')
            if cmd == 0x32:
                if size < 24 or size != 24 + 8 * struct.unpack_from('<I', data, pos + 20)[0]:
                    raise ValueError('build version tools size')
            if cmd == 0x26:
                if size != 16:
                    raise ValueError('function starts size')
                bounded(*struct.unpack_from('<II', data, pos + 8), len(data), 'function starts')
        else:
            # In particular reject dyld bindings, chained fixups, filesets and LC_MAIN.
            raise ValueError('unsupported load command ' + hex(cmd))
        if cmd != 0x19:
            if cmd in seen:
                raise ValueError('duplicate load command')
            seen.add(cmd)
        pos += size
    if pos != end or not 1 <= len(segments) <= 32 or entry is None:
        raise ValueError('incomplete load commands/segments/entry')
    segments.sort(key=lambda s: s['va'])
    if segments[0]['name'] != '__TEXT' or segments[0]['file_offset'] != 0 or segments[0]['file_size'] < end:
        raise ValueError('missing runtime Mach-O header at __TEXT base')
    base = segments[0]['va']
    high = max(s['va'] + s['size'] for s in segments)
    if high - base > MAX_SPAN:
        raise ValueError('kernel virtual span too large')
    for i, s in enumerate(segments):
        if i and segments[i-1]['va'] + segments[i-1]['size'] > s['va']:
            raise ValueError('overlapping virtual segments')
        for p in segments[:i]:
            if s['file_size'] and p['file_size'] and s['file_offset'] < p['file_offset'] + p['file_size'] and p['file_offset'] < s['file_offset'] + s['file_size']:
                raise ValueError('overlapping segment file ranges')
    if entry % 4 or not any(s['initprot'] & 4 and s['va'] <= entry < s['va'] + s['file_size'] for s in segments):
        raise ValueError('entry outside file-backed executable segment')
    # The container preserves every preferred VA; virtual slide is EXACTLY zero.
    # Validate all retained local pointer fixups instead of silently discarding them.
    # Changing virtual_base requires a different relocator and is NOT supported.
    targets = set()
    if local_relocations is None:
        raise ValueError('missing explicit relocation description')
    reloc_off, reloc_count = local_relocations
    for i in range(reloc_count):
        address, word = struct.unpack_from('<iI', data, reloc_off + i * 8)
        section_index = word & 0xffffff
        if word >> 24 != 6 or not 1 <= section_index <= len(sections) or address < 0:
            raise ValueError('need local non-PC-relative ARM64_RELOC_UNSIGNED 64-bit')
        target = base + address
        if target % 8 or target in targets:
            raise ValueError('misaligned/duplicate relocation target')
        targets.add(target)
        mapped = next((seg for seg in segments if seg['va'] <= target and target - seg['va'] + 8 <= seg['file_size']), None)
        if mapped is None:
            raise ValueError('relocation target not in file-backed runtime segment')
        pointer = struct.unpack_from('<Q', data, mapped['file_offset'] + target - mapped['va'])[0]
        section_va, section_size = sections[section_index - 1]
        if not section_va <= pointer <= section_va + section_size:
            raise ValueError('fixed-VA pointer does not match relocation section')
    return {'entry_va': entry, 'virtual_base': base, 'virtual_end': high, 'flags': flags,
            'segments': segments, 'skipped': skipped, 'virtual_slide': 0,
            'validated_local_unsigned64_relocations': reloc_count,
            'relocations_applied': False, 'relocation_policy': 'preferred virtual addresses only; zero slide'}

def package_fixture(data, command=b'-v dandelion-fbcon=1', *, base=BASE, source=SOURCE, window=WINDOW):
    # Parameterised model addresses never confer permission to use device RAM.
    if any(not isinstance(v,int) or isinstance(v,bool) for v in (base,source,window)):
        raise ValueError('synthetic addresses must be integers')
    if base % PAGE or source % PAGE or window % PAGE or window < 16384 or window > MAX_SPAN or base < 0x40000000 or base+window > 0xc0000000 or not 0x40000000 <= source < 0xc0000000:
        raise ValueError('invalid synthetic window/source')
    kernel = parse_kernel(data)
    if not isinstance(command, bytes) or b'\0' in command or len(command) > 607 or any(x > 126 or x < 32 for x in command):
        raise ValueError('command line must be bounded ASCII without NUL')
    # Predictable seed is deliberately allowed ONLY in this non-bootable test fixture.
    adt = serialize(build(base, window, bytes(range(64)), diagnostic_fbcon=True))
    ke = align(kernel['virtual_end'])
    if ke - kernel['virtual_base'] + align(len(adt)) + PAGE > window:
        raise ValueError('real kernel and metadata exceed synthetic test window')
    n = len(kernel['segments'])
    payload = bytearray(align(HEADER + n * 32))
    payload[:8] = b'SWEETXNU'
    payload[72:72+len(command)] = command
    for i, seg in enumerate(kernel['segments']):
        start = len(payload)
        payload += data[seg['file_offset']:seg['file_offset']+seg['file_size']]
        struct.pack_into('<4Q', payload, HEADER+i*32, seg['va'], seg['size'], start, seg['file_size'])
    ao = len(payload)
    payload += adt
    struct.pack_into('<II7Q', payload, 8, 1, n, kernel['virtual_base'], kernel['entry_va'], ao, len(adt), ke, base, window)
    if source+len(payload)>0xc0000000 or (source<base+window and base<source+len(payload)):
        raise ValueError('synthetic source/destination overlap or overflow')
    report = {'synthetic_only': True, 'flashable': False, 'hardware_tested': False,
              'boot_entropy': False, 'ram_ownership_verified': False,
              'kernel_sha256': hashlib.sha256(data).hexdigest(), 'kernel_bytes': len(data),
              'payload_sha256': hashlib.sha256(payload).hexdigest(), 'payload_bytes': len(payload),
              'test_window': {'base': base, 'size': window}, 'test_source': source,
              'entry_pa_in_model': base + kernel['entry_va']-kernel['virtual_base'],
              'adt_pa_in_model': base + ke-kernel['virtual_base'],
              'metadata_end_in_model': align(base+ke-kernel['virtual_base']+len(adt))+PAGE,
              **kernel}
    return bytes(payload), report

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kernel', type=Path, required=True)
    p.add_argument('--expect-sha256', required=True)
    p.add_argument('--synthetic-test', action='store_true', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.out.exists():
        p.error('refusing existing output directory')
    with a.kernel.open('rb') as f:
        data = f.read(MAX_FILE+1)
    if len(a.expect_sha256) != 64 or hashlib.sha256(data).hexdigest() != a.expect_sha256.lower():
        p.error('kernel SHA256 mismatch')
    payload, report = package_fixture(data)
    a.out.mkdir(parents=True)
    (a.out/'SYNTHETIC-ONLY-NOT-FOR-PHONE.dxnu').write_bytes(payload)
    (a.out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    (a.out/'DO-NOT-FLASH.txt').write_text('SYNTHETIC RAM TEST ONLY. NOT A BOOT IMAGE.\n0x90000000 is NOT an approved phone RAM address.\nPredictable seed, no verified entropy. No MMU/cache/handoff or RAM ownership validation.\nDo NOT flash or execute this fixture on a phone.\n')
    print('Created SYNTHETIC-ONLY loader fixture:', len(payload), 'bytes; NOT FOR PHONE')

if __name__ == '__main__':
    main()
