/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_PREPARE_IN_IMAGE_H
#define DANDELION_PREPARE_IN_IMAGE_H
#include "prepare_boot.h"
#include "../platform/lk_arena.h"
/* Same prerequisites as prepare_boot plus live-FDT-derived mblock and
 * executing-Image-derived extent. It is NOT a live-FDT extractor or a claim
 * that caller-provided bytes are current/authentic. No EL transition.
 * Range/format failures happen before any kernel destination write.
 */
int dandelion_prepare_in_image(const uint8_t *source,size_t source_size,const struct policy *,
 uint8_t *mapping,size_t mapping_size,const struct handoff_storage *,
 const struct range *image,const uint8_t *mblock,size_t mblock_size,struct handoff_args *out);
#endif
