/* SPDX-License-Identifier: MIT */
#include "prepare_in_image.h"
static int alias(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;return !a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y||(x<y+bn&&y<x+an);}
int dandelion_prepare_in_image(const uint8_t *b,size_t n,const struct policy *p,
 uint8_t *mapping,size_t mapping_size,const struct handoff_storage *s,
 const struct range *image,const uint8_t *mb,size_t mn,struct handoff_args *out)
{
 struct lk_arena_result proof;int rc;
 if(!b||!n||!p||!mapping||!mapping_size||!s||!image||!mb||!mn||!out)return 300;
 if(alias(out,sizeof *out,image,sizeof *image)||alias(out,sizeof *out,mb,mn)||alias(mapping,mapping_size,mb,mn)||alias(mapping,mapping_size,image,sizeof *image))return 301;
 rc=dandelion_lk_arena(mb,mn,p,s,image,&proof);if(rc)return rc;
 return dandelion_prepare_boot(b,n,p,mapping,mapping_size,s,out);
}
