# SPDX-License-Identifier: MIT
"""Bounded, shared-backing stage-1 aliases from XNU-generated 4K tables.
NOT a hardware MMU/TLB/cache/interrupt model. Never maps MMIO or foreign RAM.
"""
import ctypes,mmap,struct
from unicorn import UC_PROT_READ,UC_PROT_WRITE,UC_PROT_EXEC,UC_PROT_NONE
from check_bootstrap_tables import walk
PAGE=4096
class OwnedMemory:
 def __init__(self,base,data):
  if base%PAGE or not data or len(data)%PAGE:raise ValueError('page aligned nonempty backing required')
  self.base=base;self.size=len(data);self.data=mmap.mmap(-1,self.size);self.data[:]=data
  self.pointer=ctypes.addressof(ctypes.c_char.from_buffer(self.data))
 def ptr(self,pa,n=PAGE):
  if pa<self.base or n<0 or pa-self.base>self.size or n>self.size-(pa-self.base):raise ValueError('outside owned Image backing')
  return self.pointer+pa-self.base
 def read(self,pa,n):
  self.ptr(pa,n);return self.data[pa-self.base:pa-self.base+n]
 def map(self,u,address,pa,size,perms):
  if address%PAGE or pa%PAGE or size%PAGE or not size:raise ValueError('map alignment')
  u.mem_map_ptr(address,size,perms,self.ptr(pa,size))

def leaf_permissions(result):
 # EL1 permissions, with inherited APTable/PXNTable restrictions.
 ro=bool(result['descriptor']&(1<<7));pxn=bool(result['descriptor']&(1<<53))
 for _,table_desc in result['path'][:-1]:
  ro|=bool(table_desc&(1<<62));pxn|=bool(table_desc&(1<<59))
 return UC_PROT_READ|(0 if ro else UC_PROT_WRITE)|(0 if pxn else UC_PROT_EXEC)

def install(u,backing,*,head,end,base,size,vb,cpu,fdt=0x47880000,mutate=None):
 if base%PAGE or size%PAGE or vb%PAGE or base<backing.base or base+size>backing.base+backing.size:raise ValueError('arena bounds')
 allowed_tables=set();rows=[]
 def read(pa,n):
  if not base<=pa or pa+n>base+size:raise ValueError('table outside approved kernel arena')
  allowed_tables.add(pa&~4095);data=backing.read(pa,n)
  return mutate(pa,data) if mutate else data
 # Validate EVERYTHING before mapping, then remove all non-kernel Image/FDT.
 for offset in range(0,size,PAGE):
  pa=base+offset;va=vb+offset;pair=[]
  for address,high,key in [(pa,False,'ttbr0_el1'),(va,True,'ttbr1_el1')]:
   try:r=walk(read,cpu[key],address,high=high,tcr=cpu['tcr_el1'])
   except ValueError as e:
    if str(e)=='invalid descriptor':pair.append(None);continue
    raise
   if r['pa']!=pa:raise ValueError('translation disagrees with owned physical backing')
   pair.append({'va':address,'pa':pa,'perms':leaf_permissions(r)})
  if bool(pair[0])!=bool(pair[1]):raise ValueError('inconsistent identity/high mapping coverage')
  rows.append(pair)
 for lo,hi in [(head,base),(base+size,end)]:
  if hi>lo:u.mem_unmap(lo,hi-lo)
 u.mem_unmap(fdt,0x80000)
 aliases={};mapped=0;groups=[]
 for i,pair in enumerate(rows):
  if pair[0] is None:
   current={'low':base+i*PAGE,'high':None,'pa':base+i*PAGE,'size':PAGE,'perms':UC_PROT_NONE}
  else:
   low,high=pair;aliases[high['va']]=high;aliases[low['va']]=low;mapped+=1
   current={'low':low['va'],'high':high['va'],'pa':low['pa'],'size':PAGE,'perms':low['perms']}
   if high['perms']!=low['perms']:raise ValueError('identity/high permissions differ')
  if groups and groups[-1]['low']+groups[-1]['size']==current['low'] and groups[-1]['pa']+groups[-1]['size']==current['pa'] and groups[-1]['perms']==current['perms'] and ((groups[-1]['high'] is None and current['high'] is None) or (groups[-1]['high'] is not None and current['high']==groups[-1]['high']+groups[-1]['size'])):
   groups[-1]['size']+=PAGE
  else:groups.append(current)
 for g in groups:
  u.mem_protect(g['low'],g['size'],g['perms'])
  if g['high'] is not None:backing.map(u,g['high'],g['pa'],g['size'],g['perms'])
 return {'aliases':aliases,'table_pages':allowed_tables,'mapped_physical_bytes':mapped*PAGE,'mapped_virtual_bytes':mapped*PAGE,'ram_window_bytes':size,'pages':mapped,'mmio_mapped':False,'coherent_shared_backing':True}
