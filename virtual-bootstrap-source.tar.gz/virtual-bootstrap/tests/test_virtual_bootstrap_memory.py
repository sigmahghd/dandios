#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
import struct,unittest
from unicorn import *
import unicorn.arm64_const as A
from virtual_bootstrap_memory import OwnedMemory,install,leaf_permissions
BASE=0x41200000;SIZE=0x8000;VB=0xfffffff007000000;TCR=25|(25<<16)|(2<<30)
class AliasTests(unittest.TestCase):
 def setup_memory(self,*,leaf=0,table=0,high_delta=0,invalid=False,outside=False):
  b=bytearray(SIZE)
  def q(offset,value):struct.pack_into('<Q',b,offset,value)
  low_index=(BASE>>30)&511;high_index=(VB>>30)&511
  q(0x1000+low_index*8,(BASE+0x2000)|3|table);q(0x1000+high_index*8,(0x49999000 if outside else BASE+0x3000)|3|table)
  q(0x2000+((BASE>>21)&511)*8,0 if invalid else BASE|0x401|leaf)
  q(0x3000+((VB>>21)&511)*8,0 if invalid else (BASE+high_delta)|0x401|leaf)
  backing=OwnedMemory(BASE,bytes(b));u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);backing.map(u,BASE,BASE,SIZE,UC_PROT_READ|UC_PROT_WRITE|UC_PROT_EXEC);u.mem_map(0x47880000,0x80000)
  cpu={'ttbr0_el1':BASE+0x1000,'ttbr1_el1':BASE+0x1000,'tcr_el1':TCR}
  self.keep=(u,backing)
  return u,backing,cpu
 def install(self,u,b,cpu):return install(u,b,head=BASE,end=BASE+SIZE,base=BASE,size=SIZE,vb=VB,cpu=cpu)
 def test_pointer_lower_bound(self):
  b=OwnedMemory(BASE,bytes(SIZE))
  with self.assertRaises(ValueError):b.ptr(BASE-1)
 def test_pointer_upper_bound(self):
  b=OwnedMemory(BASE,bytes(SIZE))
  with self.assertRaises(ValueError):b.ptr(BASE+SIZE-1,2)
 def test_zero_map_rejected(self):
  u,b,c=self.setup_memory()
  with self.assertRaises(ValueError):b.map(u,VB,BASE,0,7)
 def test_unaligned_map_rejected(self):
  u,b,c=self.setup_memory()
  with self.assertRaises(ValueError):b.map(u,VB+1,BASE,4096,7)
 def test_valid_coverage(self):
  u,b,c=self.setup_memory();r=self.install(u,b,c);self.assertEqual(r['pages'],8);self.assertFalse(r['mmio_mapped'])
 def test_alias_write_coherent(self):
  u,b,c=self.setup_memory();self.install(u,b,c);u.mem_write(VB+0x6000,b'coherent');self.assertEqual(u.mem_read(BASE+0x6000,8),b'coherent');self.assertEqual(b.read(BASE+0x6000,8),b'coherent')
 def test_physical_write_coherent(self):
  u,b,c=self.setup_memory();self.install(u,b,c);u.mem_write(BASE+0x6000,b'physical');self.assertEqual(u.mem_read(VB+0x6000,8),b'physical')
 def test_actual_instruction_alias_store(self):
  u,b,c=self.setup_memory();self.install(u,b,c);u.mem_write(BASE,struct.pack('<I',0xb9000020));u.reg_write(A.UC_ARM64_REG_X0,0x12345678);u.reg_write(A.UC_ARM64_REG_X1,VB+0x6000);u.emu_start(VB,VB+4,count=1);self.assertEqual(b.read(BASE+0x6000,4),struct.pack('<I',0x12345678))
 def test_store_respects_readonly_leaf(self):
  u,b,c=self.setup_memory(leaf=1<<7);self.install(u,b,c);u.mem_write(BASE,struct.pack('<I',0xb9000020));u.reg_write(A.UC_ARM64_REG_X1,VB+0x6000)
  with self.assertRaises(UcError):u.emu_start(VB,VB+4,count=1)
  self.assertEqual(b.read(BASE+0x6000,4),bytes(4))
 def test_store_respects_parent_ap_table(self):
  u,b,c=self.setup_memory(table=1<<62);self.install(u,b,c);u.mem_write(BASE,struct.pack('<I',0xb9000020));u.reg_write(A.UC_ARM64_REG_X1,VB+0x6000)
  with self.assertRaises(UcError):u.emu_start(VB,VB+4,count=1)
 def test_leaf_pxn_prevents_fetch(self):
  u,b,c=self.setup_memory(leaf=1<<53);self.install(u,b,c);u.mem_write(BASE,struct.pack('<I',0xd503201f))
  with self.assertRaises(UcError):u.emu_start(VB,VB+4,count=1)
 def test_parent_pxn_prevents_fetch(self):
  u,b,c=self.setup_memory(table=1<<59);self.install(u,b,c)
  with self.assertRaises(UcError):u.emu_start(VB,VB+4,count=1)
 def test_foreign_output_rejected_before_mapping(self):
  u,b,c=self.setup_memory(high_delta=0x200000)
  with self.assertRaisesRegex(ValueError,'disagrees'):self.install(u,b,c)
  self.assertEqual(len(u.mem_read(0x47880000,4)),4)
 def test_foreign_table_rejected(self):
  u,b,c=self.setup_memory(outside=True)
  with self.assertRaisesRegex(ValueError,'table outside'):self.install(u,b,c)
 def test_missing_pages_not_invented(self):
  u,b,c=self.setup_memory(invalid=True);r=self.install(u,b,c);self.assertEqual(r['pages'],0)
  with self.assertRaises(UcError):u.emu_start(VB,VB+4,count=1)
  with self.assertRaises(UcError):u.emu_start(BASE,BASE+4,count=1)
 def test_fdt_is_removed(self):
  u,b,c=self.setup_memory();self.install(u,b,c)
  with self.assertRaises(UcError):u.mem_read(0x47880000,4)
 def test_mmio_not_mapped(self):
  u,b,c=self.setup_memory();self.install(u,b,c)
  for pa in [0xc000000,0xc100000,0x10007000]:
   with self.assertRaises(UcError):u.mem_read(pa,4)
 def test_bad_granule_rejected(self):
  u,b,c=self.setup_memory();c['tcr_el1']|=1<<14
  with self.assertRaisesRegex(ValueError,'4K'):self.install(u,b,c)
if __name__=='__main__':unittest.main()
