/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_PREPARE_BOOT_H
#define DANDELION_PREPARE_BOOT_H
#include "../platform/handoff_contract.h"
/* Connect metadata preflight -> range contract -> load/copy -> handoff args.
 * Never changes EL/registers/MMU/cache, never jumps. All preflight failures leave
 * destination/output unchanged. Requires caller-owned accurate mapping, stable
 * inputs, source authentication, and verified live CPU/cache state BEFORE call.
 * It cannot infer ownership or CPU state from numbers in policy/storage.
 * Returns existing metadata/load/contract errors, 300 bad pointer/mapping,
 * 301 output alias. out must not alias source, mapping, policy, storage or
 * forbidden array. After success only a caller can invoke the EL2 helper.
 */
int dandelion_prepare_boot(const uint8_t *,size_t,const struct policy *,
 uint8_t *mapping,size_t,const struct handoff_storage *,struct handoff_args *out);
#endif
