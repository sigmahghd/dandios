/* SPDX-License-Identifier: MIT */
#include "prepare_boot.h"
static int pointers_overlap(const void *a,size_t an,const void *b,size_t bn){
 uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
 if(!a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y)return 1;
 return x<y+bn&&y<x+an;
}
int dandelion_prepare_boot(const uint8_t *b,size_t n,const struct policy *p,
 uint8_t *mapping,size_t mapping_size,const struct handoff_storage *s,struct handoff_args *out)
{
 struct metadata_plan meta;struct handoff_args result;struct loaded_image preview,loaded;
 struct policy policy;struct handoff_storage storage;int rc;size_t i;
 if(!b||!n||!p||!mapping||!mapping_size||!s||!out)return 300;
 if(p->forbidden_count>128||(p->forbidden_count&&!p->forbidden))return HANDOFF_LAYOUT_ARGUMENT;
 if(pointers_overlap(out,sizeof *out,b,n)||pointers_overlap(out,sizeof *out,mapping,mapping_size)||
    pointers_overlap(out,sizeof *out,p,sizeof *p)||pointers_overlap(out,sizeof *out,s,sizeof *s)||
    (p->forbidden_count&&pointers_overlap(out,sizeof *out,p->forbidden,p->forbidden_count*sizeof *p->forbidden)))return 301;
 /* Volatile byte copies avoid implicit memcpy and FP/SIMD before CPU setup. */
 {volatile uint8_t *d=(volatile uint8_t *)&policy;const volatile uint8_t *v=(const volatile uint8_t *)p;
 for(i=0;i<sizeof policy;i++)d[i]=v[i];}
 {volatile uint8_t *d=(volatile uint8_t *)&storage;const volatile uint8_t *v=(const volatile uint8_t *)s;
 for(i=0;i<sizeof storage;i++)d[i]=v[i];}
 if(policy.approved_window.size!=(uint64_t)mapping_size)return 300;
 /* Both calls below are read-only. In particular stack/vector overlap is
  * rejected BEFORE copying a kernel segment, not only before the final jump. */
 rc=metadata_prepare(b,n,&policy,&meta);if(rc)return rc;
 /* Force scalar accesses: LLVM 18 can lower a fused 16-byte struct copy
  * to Q-register loads even with -mgeneral-regs-only. ISA audit guards this. */
 *(volatile uint64_t *)&preview.entry=*(const volatile uint64_t *)&meta.load.entry;
 *(volatile uint64_t *)&preview.bootargs=*(const volatile uint64_t *)&meta.load.bootargs;
 *(volatile uint64_t *)&preview.top=*(const volatile uint64_t *)&meta.load.top;
 rc=dandelion_handoff_contract(&policy,&preview,&storage,&result);if(rc)return rc;
 rc=dandelion_load(b,n,&policy,mapping,mapping_size,&loaded);if(rc)return rc;
 /* Stable source and policy guarantee this result matches the pure preview.
  * No fallible checks after the successful destination commit. */
 {volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *v=(const volatile uint8_t *)&result;
 for(i=0;i<sizeof result;i++)d[i]=v[i];}
 return 0;
}
