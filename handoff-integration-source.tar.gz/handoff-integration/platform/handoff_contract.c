/* SPDX-License-Identifier: MIT */
#include "handoff_contract.h"
static int valid(struct range r){return r.size && r.base<=UINT64_MAX-r.size;}
static int contains(struct range a,struct range b){return valid(a)&&valid(b)&&b.base>=a.base&&b.size<=a.size&&b.base-a.base<=a.size-b.size;}
static int overlaps(struct range a,struct range b){return a.base<b.base+b.size&&b.base<a.base+a.size;}
static int alias(const void *a,size_t an,const void *b,size_t bn){
 uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
 if(!a||!b||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y)return 1;
 return x<y+bn&&y<x+an;
}
int dandelion_handoff_contract(const struct policy *p,const struct loaded_image *l,
 const struct handoff_storage *s,struct handoff_args *out)
{
 struct range ranges[6];struct handoff_args result;size_t i,j;
 if(!p||!l||!s||!out||p->forbidden_count>128||(p->forbidden_count&&!p->forbidden))return HANDOFF_LAYOUT_ARGUMENT;
 if(alias(out,sizeof *out,p,sizeof *p)||alias(out,sizeof *out,l,sizeof *l)||alias(out,sizeof *out,s,sizeof *s)||
    (p->forbidden_count&&alias(out,sizeof *out,p->forbidden,p->forbidden_count*sizeof *p->forbidden)))return HANDOFF_LAYOUT_ARGUMENT;
 ranges[0]=p->approved_window;ranges[1]=p->source;ranges[2]=s->loader;
 ranges[3]=s->input_fdt;ranges[4]=s->el1_stack;ranges[5]=s->el1_vectors;
 if(!valid(p->dram))return HANDOFF_LAYOUT_RANGE;
 for(i=0;i<6;i++)if(!contains(p->dram,ranges[i]))return HANDOFF_LAYOUT_RANGE;
 if((ranges[0].base&4095)||(ranges[0].size&4095)||(s->loader.base&3)||
    (s->input_fdt.base&7)||s->input_fdt.size<40||(s->el1_stack.base&15)||
    (s->el1_stack.size&15)||s->el1_stack.size<16384||
    (s->el1_vectors.base&2047)||s->el1_vectors.size<2048)return HANDOFF_LAYOUT_ALIGNMENT;
 for(i=0;i<6;i++)for(j=0;j<i;j++)if(overlaps(ranges[i],ranges[j]))return HANDOFF_LAYOUT_OVERLAP;
 for(i=0;i<p->forbidden_count;i++){
  if(!valid(p->forbidden[i]))return HANDOFF_LAYOUT_RANGE;
  for(j=0;j<6;j++)if(overlaps(ranges[j],p->forbidden[i]))return HANDOFF_LAYOUT_FORBIDDEN;
 }
 if((l->entry&3)||(l->bootargs&4095)||l->bootargs>UINT64_MAX-4096||
    l->top!=l->bootargs+4096||!contains(ranges[0],(struct range){l->entry,4})||
    !contains(ranges[0],(struct range){l->bootargs,4096})||l->entry>=l->bootargs)return HANDOFF_LAYOUT_LOADED;
 result.entry=l->entry;result.bootargs=l->bootargs;
 result.stack_top=s->el1_stack.base+s->el1_stack.size;result.vectors=s->el1_vectors.base;
 /* Inputs have all been checked; no destination writes precede this commit. */
 {volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *v=(const volatile uint8_t *)&result;
 for(i=0;i<sizeof result;i++)d[i]=v[i];}
 return HANDOFF_LAYOUT_OK;
}
