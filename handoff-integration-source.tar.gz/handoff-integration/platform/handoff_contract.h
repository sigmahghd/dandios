/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_HANDOFF_CONTRACT_H
#define DANDELION_HANDOFF_CONTRACT_H
#include "../loader/load.h"
/* These are descriptions of caller-owned ranges, NOT ownership certificates.
 * The caller must establish live LK reservations/mappings and actual CPU state.
 * All five roles must be disjoint from one another and from the load window.
 * Image source is policy.source; active loader excludes an embedded payload.
 */
struct handoff_storage { struct range loader, input_fdt, el1_stack, el1_vectors; };
struct handoff_args { uint64_t entry, bootargs, stack_top, vectors; };
enum handoff_contract_result {
 HANDOFF_LAYOUT_OK=0, HANDOFF_LAYOUT_ARGUMENT=400, HANDOFF_LAYOUT_RANGE=401,
 HANDOFF_LAYOUT_ALIGNMENT=402, HANDOFF_LAYOUT_OVERLAP=403,
 HANDOFF_LAYOUT_FORBIDDEN=404, HANDOFF_LAYOUT_LOADED=405
};
/* Pure range/ABI validation. No MMIO, RAM allocation, copy, register change or
 * jump. Does not authenticate kernel, verify permissions/cache coherence,
 * parse FDT, collect entropy, or prove the truth of a caller's ownership claim.
 * out must be writable and not alias any input structure/forbidden array;
 * alias rejected before first write. All referenced inputs must be accessible.
 * On any error out is unchanged. Thread/concurrent mutation is caller's duty.
 */
int dandelion_handoff_contract(const struct policy *,const struct loaded_image *,
 const struct handoff_storage *,struct handoff_args *out);
#endif
