#!/bin/sh
# SPDX-License-Identifier: MIT. Offline linked ELF, NOT an Android Boot image.
set -eu
cd "$(dirname "$0")/.."
: "${ZIG:=/data/dandelion-toolchain/ziglang/zig}"
# Zig appends CPU features after Clang flags: disable FP/NEON explicitly in -mcpu too.
for name in load payload metadata prepare_boot; do
 "$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -std=c11 -mgeneral-regs-only -mstrict-align -ffreestanding -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror -c "loader/$name.c" -o "tests/bridge-$name-arm64.o"
done
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -std=c11 -mgeneral-regs-only -mstrict-align -ffreestanding -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror -c platform/handoff_contract.c -o tests/bridge-contract-arm64.o
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -c platform/handoff_el2.S -o tests/bridge-handoff-arm64.o
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -nostdlib -Wl,-T,loader/module.ld -Wl,-e,dandelion_prepare_boot tests/bridge-load-arm64.o tests/bridge-payload-arm64.o tests/bridge-metadata-arm64.o tests/bridge-prepare_boot-arm64.o tests/bridge-contract-arm64.o tests/bridge-handoff-arm64.o -o tests/prepare-boot-handoff-arm64.elf
