#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Host test of actual prepare_boot C, actual kernel bytes, synthetic RAM only."""
import argparse,ctypes as C,hashlib,json,platform,subprocess,sys,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from pack_kernel_fixture import package_fixture,BASE,SOURCE,WINDOW
from test_real_kernel_fixture import check_mapping
from test_handoff_contract import Range,Policy,Loaded,Storage,Args
class Tests(unittest.TestCase):
 def setUp(self):
  self.p=Policy(Range(0x40000000,0x80000000),Range(BASE,WINDOW),Range(SOURCE,len(PAYLOAD)),None,0)
  self.s=Storage(Range(0x60000000,0x10000),Range(0x47880000,0x20000),Range(0x62004000,0x4000),Range(0x62000000,0x800))
  self.src=C.create_string_buffer(PAYLOAD);self.dst=C.create_string_buffer(WINDOW);C.memset(self.dst,0xa5,WINDOW);self.out=Args(1,2,3,4)
 def call(self):return F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.out))
 def reject(self,rc):
  self.assertEqual(self.call(),rc);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW);self.assertEqual(bytes(self.out),bytes(Args(1,2,3,4)));self.assertEqual(self.src.raw[:-1],PAYLOAD)
 def test_real_kernel_valid(self):
  self.assertEqual(self.call(),0)
  self.assertEqual((self.out.stack_top,self.out.vectors),(0x62008000,0x62000000))
  digest=check_mapping(self.dst.raw,PAYLOAD,REPORT,(self.out.entry,self.out.bootargs,self.out.bootargs+4096))
  self.assertEqual(self.out.entry,REPORT['entry_pa_in_model']);RESULT['host_mapping_sha256']=digest
 def test_stack_inside_kernel_before_any_write(self):self.s.el1_stack.base=BASE+4096;self.reject(403)
 def test_vector_overlaps_loader_before_any_write(self):self.s.el1_vectors.base=0x60000000;self.reject(403)
 def test_fdt_overlaps_source_before_any_write(self):self.s.input_fdt.base=SOURCE;self.reject(403)
 def test_short_stack_before_any_write(self):self.s.el1_stack.size=8192;self.reject(402)
 def test_source_destination_alias(self):self.p.source.base=BASE;self.reject(4)
 def test_forbidden_stack_before_any_write(self):
  self.forbidden=(Range*1)(Range(0x62004000,0x4000));self.p.forbidden=self.forbidden;self.p.forbidden_count=1;self.reject(404)
 def test_mapping_length_mismatch_before_any_write(self):self.p.approved_window.size-=4096;self.reject(300)
 def test_output_alias_storage(self):
  old=bytes(self.s);rc=F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.cast(C.byref(self.s),C.POINTER(Args)))
  self.assertEqual(rc,301);self.assertEqual(bytes(self.s),old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
 def test_output_alias_destination(self):
  rc=F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.cast(self.dst,C.POINTER(Args)))
  self.assertEqual(rc,301);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
 def test_null_storage(self):self.assertEqual(F(self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,None,C.byref(self.out)),300)

def main():
 global PAYLOAD,REPORT,F,RESULT
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 b=a.kernel.read_bytes();assert hashlib.sha256(b).hexdigest()==a.expect_sha256;PAYLOAD,REPORT=package_fixture(b)
 if a.out.exists():p.error('refusing existing output directory')
 a.out.mkdir(parents=True);so=a.out.resolve()/'prepare-boot-test.so'
 sources=[R/'loader'/n for n in ['load.c','payload.c','metadata.c','prepare_boot.c']]+[R/'platform/handoff_contract.c']
 subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',*map(str,sources),'-o',str(so)],check=True)
 lib=C.CDLL(str(so));F=lib.dandelion_prepare_boot;F.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.c_void_p,C.c_size_t,C.POINTER(Storage),C.POINTER(Args)];F.restype=C.c_int
 RESULT={'kernel_sha256':a.expect_sha256,'synthetic_only':True,'hardware_tested':False,'kernel_executed':False,'eret_executed':False}
 res=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));RESULT['host_prepare_tests']=res.testsRun;RESULT['all_passed']=res.wasSuccessful()
 (a.out/'results.json').write_text(json.dumps(RESULT,indent=2)+'\n');print(json.dumps(RESULT,indent=2));raise SystemExit(0 if res.wasSuccessful() else 1)
if __name__=='__main__':main()
