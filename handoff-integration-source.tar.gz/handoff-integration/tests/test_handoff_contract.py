#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
import ctypes as C,platform,subprocess,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class Range(C.Structure):_fields_=[('base',C.c_uint64),('size',C.c_uint64)]
class Policy(C.Structure):_fields_=[('dram',Range),('approved_window',Range),('source',Range),('forbidden',C.POINTER(Range)),('forbidden_count',C.c_size_t)]
class Loaded(C.Structure):_fields_=[('entry',C.c_uint64),('bootargs',C.c_uint64),('top',C.c_uint64)]
class Storage(C.Structure):_fields_=[('loader',Range),('input_fdt',Range),('el1_stack',Range),('el1_vectors',Range)]
class Args(C.Structure):_fields_=[('entry',C.c_uint64),('bootargs',C.c_uint64),('stack_top',C.c_uint64),('vectors',C.c_uint64)]
so=R/'tests/handoff-contract-test.so'
subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-O2',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',str(R/'platform/handoff_contract.c'),'-o',str(so)],check=True)
f=C.CDLL(str(so)).dandelion_handoff_contract;f.argtypes=[C.POINTER(Policy),C.POINTER(Loaded),C.POINTER(Storage),C.POINTER(Args)];f.restype=C.c_int
class Tests(unittest.TestCase):
 def setUp(self):
  self.p=Policy(Range(0x40000000,0x80000000),Range(0x90000000,0x2000000),Range(0x52000000,0x1000000),None,0)
  self.l=Loaded(0x90416488,0x91074000,0x91075000)
  self.s=Storage(Range(0x60000000,0x10000),Range(0x47880000,0x20000),Range(0x62004000,0x4000),Range(0x62000000,0x800))
  self.out=Args(1,2,3,4)
 def call(self):return f(C.byref(self.p),C.byref(self.l),C.byref(self.s),C.byref(self.out))
 def reject(self,rc):
  self.assertEqual(self.call(),rc);self.assertEqual(bytes(self.out),bytes(Args(1,2,3,4)))
 def test_valid(self):self.assertEqual(self.call(),0);self.assertEqual(bytes(self.out),bytes(Args(self.l.entry,self.l.bootargs,0x62008000,0x62000000)))
 def test_stack_in_kernel(self):self.s.el1_stack.base=0x91000000;self.reject(403)
 def test_vectors_in_loader(self):self.s.el1_vectors.base=0x60000000;self.reject(403)
 def test_fdt_in_source(self):self.s.input_fdt.base=0x52000000;self.reject(403)
 def test_source_in_window(self):self.p.source.base=0x90000000;self.reject(403)
 def test_stack_outside_dram(self):self.s.el1_stack.base=0xc0000000;self.reject(401)
 def test_stack_overflow(self):self.s.el1_stack.base=(1<<64)-16;self.reject(401)
 def test_stack_misaligned(self):self.s.el1_stack.base+=1;self.reject(402)
 def test_stack_too_small(self):self.s.el1_stack.size=8192;self.reject(402)
 def test_vectors_misaligned(self):self.s.el1_vectors.base+=4;self.reject(402)
 def test_vectors_too_short(self):self.s.el1_vectors.size=1024;self.reject(402)
 def test_bad_entry(self):self.l.entry=self.l.bootargs;self.reject(405)
 def test_bad_top(self):self.l.top+=4096;self.reject(405)
 def test_bootargs_outside_window(self):self.l.bootargs=0x92000000;self.l.top=self.l.bootargs+4096;self.reject(405)
 def test_reserved(self):
  self.forbidden=(Range*1)(Range(0x62000000,4096));self.p.forbidden=self.forbidden;self.p.forbidden_count=1;self.reject(404)
 def test_forbidden_overflow(self):
  self.forbidden=(Range*1)(Range((1<<64)-1,4096));self.p.forbidden=self.forbidden;self.p.forbidden_count=1;self.reject(401)
 def test_output_alias(self):
  before=bytes(self.s);rc=f(C.byref(self.p),C.byref(self.l),C.byref(self.s),C.cast(C.byref(self.s),C.POINTER(Args)));self.assertEqual(rc,400);self.assertEqual(bytes(self.s),before)
 def test_null(self):self.assertEqual(f(None,C.byref(self.l),C.byref(self.s),C.byref(self.out)),400)
if __name__=='__main__':unittest.main()
