#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Explicit local XNU build attempt on a prepared Mac. No installs/downloads/flash.
Default --check only. Requires existing licensed SDK/KDK and a prepared dxb fakeroot.
This does not provide those dependencies or assert that the platform port is complete.
"""
import argparse,hashlib,json,os,platform,re,shutil,struct,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def verify_tree(source,manifest):
 errors=[]
 for rel,expected in manifest.items():
  p=source/rel
  if p.is_symlink() or not p.is_file() or digest(p)!=expected:errors.append('source mismatch: '+rel)
 return errors

def inspect_kernel(path):
 # Plain 64-bit ARM Mach-O only. NOT proof of working XNU, RAM ownership, 4K,
 # relocatability or a safe flash image. Full semantic loader audit remains.
 with path.open('rb') as f:b=f.read(32)
 if len(b)!=32:raise ValueError('truncated Mach-O header')
 magic,cpu,subtype,kind,ncmd,size,flags,reserved=struct.unpack('<8I',b)
 if magic!=0xfeedfacf or cpu!=0x100000c or subtype!=0 or kind!=2:raise ValueError('expected plain ARM64 executable Mach-O, not arm64e/fat/data')
 if not ncmd or ncmd>65536 or size>16*1024*1024 or size>path.stat().st_size-32:raise ValueError('invalid Mach-O load-command region')
 return {'path':str(path),'sha256':digest(path),'bytes':path.stat().st_size,'cpu':'plain ARM64','format_check_only':True,'boot_verified':False}

def command(argv,env):
 p=subprocess.run(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=45)
 if p.returncode:raise ValueError('command failed: '+argv[0]+'; '+p.stderr[-1500:])
 return p.stdout.strip()

def inspect_environment(source,fakeroot,kdk,env):
 errors=[];data={'platform':platform.system(),'source':str(source),'fakeroot':str(fakeroot),'kdk':str(kdk)}
 if platform.system()!='Darwin':
  return data,['macOS required: no Xcode/SDK/KDK build was attempted on this host']
 for label,p in [('source',source),('fakeroot',fakeroot),('kdk',kdk)]:
  if not p.is_dir():errors.append(label+' directory missing')
  if any(c.isspace() for c in str(p)):errors.append(label+' path contains whitespace unsupported by this recipe')
 if errors:return data,errors
 try:
  version=command(['/usr/bin/xcodebuild','-version'],env);data['xcode_version']=version
  if not re.search(r'^Xcode 15\.',version,re.M):errors.append('this recipe is scoped to Xcode 15.x; other versions require separate validation')
  sdk=Path(command(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],env));data['sdk']=str(sdk)
  if not (sdk/'usr/include/TargetConditionals.h').is_file():errors.append('real SDK TargetConditionals.h missing')
  for tool in ['clang','ld','iig']:
   found=Path(command(['/usr/bin/xcrun','--sdk','macosx','--find',tool],env))
   if not found.is_file() or not os.access(found,os.X_OK):errors.append('unusable Xcode tool '+tool)
   data[tool]=str(found)
 except (OSError,ValueError,subprocess.TimeoutExpired) as e:errors.append(str(e))
 for tool in ['mig','migcom','ctfconvert','ctfmerge','ctfdump']:
  paths=sorted(p for p in fakeroot.rglob(tool) if p.is_file() and os.access(p,os.X_OK))
  if len(paths)!=1:errors.append('need exactly one executable '+tool+' in prepared fakeroot')
  else:data[tool]=str(paths[0])
 for rel in ['usr/local/lib/kernel/libfirehose_kernel.a','usr/local/include/kernel/os/firehose_buffer_private.h']:
  if not (fakeroot/rel).is_file():errors.append('fakeroot missing '+rel)
 availability=list(fakeroot.rglob('availability.pl'))
 if not availability:errors.append('fakeroot missing AvailabilityVersions availability.pl')
 if not list(kdk.rglob('Kernel.framework')):errors.append('KDK does not contain Kernel.framework')
 return data,errors

def make_arguments(source,fakeroot,kdk,out,data,jobs):
 args=['SDKROOT=macosx','TARGET_CONFIGS=DEVELOPMENT ARM64 DANDELION','ARCH_CONFIGS=ARM64','CONCISE=0','LOGCOLORS=n','BUILD_WERROR=0','BUILD_LTO=0','SRCROOT='+str(source),'OBJROOT='+str(out/'xnu.obj'),'SYMROOT='+str(out/'xnu.sym'),'DSTROOT='+str(fakeroot),'FAKEROOT_DIR='+str(fakeroot),'KDKROOT='+str(kdk),'TIGHTBEAMC=tightbeamc-not-supported','RC_DARWIN_KERNEL_VERSION=22.6.0','KERNEL_BUILDS_IN_PARALLEL=1']
 for tool,variable in [('mig','MIG'),('migcom','MIGCOM'),('ctfconvert','CTFCONVERT'),('ctfmerge','CTFMERGE'),('ctfdump','CTFDUMP')]:args.append(variable+'='+data[tool])
 # Mirrors dxb host-resource overrides; these are BUILD HOST sizing, not phone RAM.
 for key,name in [('hw.memsize','MEMORY_SIZE'),('hw.physicalcpu','SYSCTL_HW_PHYSICALCPU'),('hw.logicalcpu','SYSCTL_HW_LOGICALCPU')]:
  value=command(['/usr/sbin/sysctl','-n',key],os.environ.copy())
  if not value.isdigit() or int(value)<=0:raise ValueError('invalid build host '+key)
  args.append(name+'='+value)
 return ['/usr/bin/make','-j'+str(jobs)],args

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=ROOT/'work/xnu');p.add_argument('--fakeroot',type=Path,required=True);p.add_argument('--kdk',type=Path,required=True);p.add_argument('--out',type=Path,default=ROOT/'build/macos-dandelion');p.add_argument('--jobs',type=int,default=4);p.add_argument('--build',action='store_true');p.add_argument('--check',action='store_true');a=p.parse_args()
 if not 1<=a.jobs<=32:p.error('jobs must be 1..32')
 if a.build and a.check:p.error('choose --check or --build')
 source=a.source.resolve();fake=a.fakeroot.resolve();kdk=a.kdk.resolve();out=a.out.resolve();env=os.environ.copy()
 info,errors=inspect_environment(source,fake,kdk,env)
 manifest_path=ROOT/'SOURCE_TREE_SHA256.json'
 if not manifest_path.is_file():errors.append('source snapshot manifest missing')
 else:errors+=verify_tree(source,json.loads(manifest_path.read_text()))
 info.update({'errors':errors,'environment_ready':not errors,'full_build_attempted':False,'hardware_tested':False})
 if errors or not a.build:print(json.dumps(info,indent=2));return 2 if errors else 0
 if out.exists() and any(out.iterdir()):raise ValueError('output directory must be new/empty; refusing stale build artifacts')
 if any(c.isspace() for c in str(out)):raise ValueError('output path cannot contain whitespace')
 # Do not let SDK staging overwrite an existing different local header.
 sdk_header=Path(info['sdk'])/'usr/include/TargetConditionals.h'
 for rel in ['bsd/pthread/sweet_libpthread/TargetConditionals.h','bsd/sweet_hfs/TargetConditionals.h']:
  dest=source/rel
  if dest.exists() and dest.read_bytes()!=sdk_header.read_bytes():raise ValueError('refusing to replace existing SDK header '+rel)
 out.mkdir(parents=True,exist_ok=True)
 for rel in ['bsd/pthread/sweet_libpthread/TargetConditionals.h','bsd/sweet_hfs/TargetConditionals.h']:shutil.copy2(sdk_header,source/rel)
 base,args=make_arguments(source,fake,kdk,out,info,a.jobs)
 env.update({'MACOS_VERSION':'13.5','MACHINE_CONFIG':'DANDELION','KERNEL_CONFIG':'DEVELOPMENT','ARCH_CONFIG':'ARM64','KERNEL_BUILD_DATE':'Sun Oct 25 00:00:00 UTC 2026','KERNEL_BUILD_OBJROOT':'xnu-8796.141.3-dandelion-experimental'})
 info['full_build_attempted']=True
 try:
  with (out/'build.log').open('w') as log:
   for target in ['installhdrs','install']:
    argv=base+[target]+args;log.write('COMMAND '+repr(argv)+'\n');log.flush()
    subprocess.run(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  artifact=out/'xnu.obj/kernel.development.dandelion';info['artifact']=inspect_kernel(artifact);info['build_completed']=True
 except (OSError,ValueError,subprocess.CalledProcessError) as e:
  info['build_completed']=False;info['errors'].append(str(e))
 (out/'build-result.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2));return 0 if info.get('build_completed') else 1
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,subprocess.TimeoutExpired) as e:print('STOP: '+str(e),file=sys.stderr);sys.exit(2)
