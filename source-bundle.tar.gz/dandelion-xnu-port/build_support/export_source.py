#!/usr/bin/env python3
# SPDX-License-Identifier: MIT. Public source only; never package phone captures or SDKs.
from pathlib import Path
import gzip,hashlib,json,tarfile,sys
R=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R.parent/'dandelion-xnu-source-complete-r6.tar.gz'
if out.exists():raise SystemExit('Refusing existing output')
files=set()
for directory in ['work/xnu','platform','loader','build_support','ci','.github']:
 for p in (R/directory).rglob('*'):
  if p.is_symlink():raise SystemExit('Source export refuses symlinks: '+str(p))
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':files.add(p)
for name in ['GITHUB_ACTIONS_RU.md','.gitignore','tools/mkadt_dandelion.py','CHECK_LOCAL.sh','SOURCE_TREE_SHA256.json','SOURCE_LOCK.json','BEARSSL_LOCK.json','PUBLIC_DEPENDENCIES.json','PATCH_APPLICATION.json','DEPENDENCY_PATCH_RECHECK.json','PROVIDER_FILES.json','STATUS_RU.md','TOPAZ_REVIEW_RU.md']:files.add(R/name)
files.update(R.glob('030[0-6]-*.patch'))
for p in (R/'tests').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and not any(c.endswith('-baseline') for c in p.parts) and p.suffix in ['.c','.cpp','.h','.s','.S','.ld','.py','.json','.txt'] and p.name!='SOURCE_BUNDLE.json':files.add(p)
# SDK headers are never redistributed, even if someone later stages them locally.
if any(p.name=='TargetConditionals.h' for p in files):raise SystemExit('Refusing to export proprietary SDK header')
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with out.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as tf:
 for p in sorted(files):
  info=tf.gettarinfo(str(p),arcname='dandelion-xnu-port/'+str(p.relative_to(R)));info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
  with p.open('rb') as f:tf.addfile(info,f)
 import io
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('dandelion-xnu-port/BUNDLE_FILES_SHA256.json');info.size=len(data);info.mtime=0;tf.addfile(info,io.BytesIO(data))
# Independently read every source entry from the finished compressed bundle.
checked=0
with tarfile.open(out,'r:gz') as tf:
 for entry in tf:
  rel=entry.name.removeprefix('dandelion-xnu-port/')
  if rel in manifest:
   assert hashlib.sha256(tf.extractfile(entry).read()).hexdigest()==manifest[rel],rel;checked+=1
assert checked==len(manifest)
report={'filename':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'public_source_files_verified':checked,'full_xnu_build_attempted':False,'phone_writes':False,'contains_sdk_or_phone_capture':False}
(R/'tests/SOURCE_BUNDLE.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
