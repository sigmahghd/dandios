/* SPDX-License-Identifier: MIT */
#include "metadata.h"
static uint32_t rd32(const uint8_t *p){uint32_t v=0;unsigned i;for(i=0;i<4;i++)v|=(uint32_t)p[i]<<(8*i);return v;}
static uint64_t rd64(const uint8_t *p){uint64_t v=0;unsigned i;for(i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);return v;}
static void wr64(uint8_t *p,uint64_t v){unsigned i;for(i=0;i<8;i++)p[i]=(uint8_t)(v>>(8*i));}
static void wr32(uint8_t *p,uint32_t v){unsigned i;for(i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
int adt_check(const uint8_t *b,size_t n,struct adt_stats *out)
{
 uint32_t pending[64],depth=0,nodes=0,props=0,maxdepth=0;size_t pos=0;
 if(!b||!out)return ADT_ARGUMENT;
 if(n>1048576)return ADT_LIMIT;
 pending[0]=1;
 for(;;){
  uint32_t np,nc,i;
  if(!pending[depth]){if(!depth)break;depth--;continue;}
  pending[depth]--;
  if(n-pos<8)return ADT_TRUNCATED;
  np=rd32(b+pos);nc=rd32(b+pos+4);pos+=8;
  if(nodes==4096||np>16384-props||nc>4096)return ADT_LIMIT;
  nodes++;props+=np;if(depth+1>maxdepth)maxdepth=depth+1;
  for(i=0;i<np;i++){
   uint32_t raw,len,j;size_t padded;int nul=0;
   if(n-pos<36)return ADT_TRUNCATED;
   if(!b[pos])return ADT_NAME;
   for(j=1;j<32;j++)if(!b[pos+j]){nul=1;break;}
   if(!nul)return ADT_NAME;
   raw=rd32(b+pos+32);if(raw&0x80000000u)return ADT_PLACEHOLDER;
   len=raw;padded=((size_t)len+3)&~(size_t)3;pos+=36;
   if(padded>n-pos)return ADT_TRUNCATED;
   pos+=padded;
  }
  if(nc){if(depth==63)return ADT_LIMIT;pending[++depth]=nc;}
 }
 if(pos!=n)return ADT_TRAILING;
 /* Bytewise output also permits a misaligned output storage region. */
 {struct adt_stats s;volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *p=(const volatile uint8_t *)&s;size_t i;s.nodes=nodes;s.properties=props;s.max_depth=maxdepth;for(i=0;i<sizeof s;i++)d[i]=p[i];}
 return ADT_OK;
}
int metadata_prepare(const uint8_t *b,size_t n,const struct policy *policy,struct metadata_plan *out)
{
 struct metadata_plan p;uint64_t vb,pb,ms,dtva,delta;size_t i;int rc;
 volatile uint8_t *zero=(volatile uint8_t *)&p;
 if(!out)return BAD_ARGUMENT;
 for(i=0;i<sizeof p;i++)zero[i]=0;
 rc=payload_plan(b,n,policy,&p.load);if(rc)return rc;
 rc=adt_check(b+p.load.adt_offset,(size_t)p.load.adt_size,&p.tree);if(rc)return 100+rc;
 vb=rd64(b+16);pb=rd64(b+56);ms=rd64(b+64);
 delta=p.load.adt_destination-pb;
 if(vb>UINT64_MAX-ms||delta>UINT64_MAX-vb)return 200;
 dtva=vb+delta;
 p.bootargs[0]=2;p.bootargs[2]=2;
 wr64(p.bootargs+8,vb);wr64(p.bootargs+16,pb);wr64(p.bootargs+24,ms);
 wr64(p.bootargs+32,p.load.top);
 wr64(p.bootargs+96,dtva);wr32(p.bootargs+104,(uint32_t)p.load.adt_size);
 for(i=0;i<608&&b[72+i];i++)p.bootargs[108+i]=b[72+i];
 wr64(p.bootargs+728,ms);
 {volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *s=(const volatile uint8_t *)&p;for(i=0;i<sizeof p;i++)d[i]=s[i];}
 return OK;
}
