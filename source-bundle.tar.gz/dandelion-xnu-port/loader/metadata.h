/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_METADATA_H
#define DANDELION_METADATA_H
#include "payload.h"
#define XNU_BOOTARGS_SIZE 736u
struct adt_stats { uint32_t nodes, properties, max_depth; };
enum adt_result { ADT_OK=0, ADT_ARGUMENT=1, ADT_TRUNCATED=2,
 ADT_LIMIT=3, ADT_NAME=4, ADT_PLACEHOLDER=5, ADT_TRAILING=6 };
/* Structural validation only. Does NOT establish board/platform compatibility.
 * Conservative subset: property names 1..31 bytes and NUL; no placeholders.
 * Root depth=1; max depth=64, nodes=4096, properties=16384, size=1 MiB.
 * No output writes on failure; no allocation, recursion, MMIO or physical writes. */
int adt_check(const uint8_t *,size_t,struct adt_stats *);
struct metadata_plan {
 struct load_plan load;
 struct adt_stats tree;
 uint8_t bootargs[XNU_BOOTARGS_SIZE];
};
/* Return payload errors unchanged, 100+ADT error, or 200=VA overflow.
 * Serializes ARM64 XNU8796 boot_args Revision2/Version2, not ARM32 ABI.
 * Video intentionally all zero: no claim of a working XNU display driver.
 * Caller pointers must reference accessible memory. Input unchanged, output
 * unchanged on failure. No copying to physical segment destinations or jump. */
int metadata_prepare(const uint8_t *,size_t,const struct policy *,struct metadata_plan *);
#endif
