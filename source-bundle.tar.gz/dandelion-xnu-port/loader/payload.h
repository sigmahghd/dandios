/* SPDX-License-Identifier: MIT. Pure preflight: does NOT copy/jump/map MMIO. */
#ifndef DANDELION_PAYLOAD_H
#define DANDELION_PAYLOAD_H
#include <stdint.h>
#include <stddef.h>
struct range { uint64_t base, size; };
struct segment_plan { uint64_t destination, memory_size, source_offset, file_size; };
struct policy {
 struct range dram, approved_window, source;
 const struct range *forbidden;
 size_t forbidden_count;
};
struct load_plan {
 uint64_t entry, adt_destination, adt_offset, adt_size, bootargs, top;
 uint32_t segment_count;
 struct segment_plan segments[32];
};
enum result { OK=0, BAD_ARGUMENT=1, BAD_HEADER=2, BAD_WINDOW=3,
 OVERLAP=4, BAD_SEGMENT=5, BAD_ENTRY=6, NO_METADATA_SPACE=7 };
/* approved_window MUST be explicitly vetted by caller, not guessed from total RAM.
 * Success validates a plan only, not kernel identity, ADT, relocations or EL handoff.
 * On failure out is unchanged. Inputs are read bytewise (unaligned sources allowed). */
int payload_plan(const uint8_t *data,size_t size,const struct policy *policy,struct load_plan *out);
#endif
