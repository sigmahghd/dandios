/* SPDX-License-Identifier: MIT */
#include "payload.h"
#define HEADER 680u
#define PAGE 4096u
static uint32_t le32(const uint8_t *p){uint32_t n=0;unsigned i;for(i=0;i<4;i++)n|=(uint32_t)p[i]<<(i*8);return n;}
static uint64_t le64(const uint8_t *p){uint64_t n=0;unsigned i;for(i=0;i<8;i++)n|=(uint64_t)p[i]<<(i*8);return n;}
static int valid(struct range r){return r.size&&r.base<=UINT64_MAX-r.size;}
static int contains(struct range a,struct range b){return valid(a)&&valid(b)&&b.base>=a.base&&b.base+b.size<=a.base+a.size;}
static int overlap(struct range a,struct range b){return a.base<b.base+b.size&&b.base<a.base+a.size;}
static int align_page(uint64_t x,uint64_t *out){if(x>UINT64_MAX-(PAGE-1))return 0;*out=(x+PAGE-1)&~(uint64_t)(PAGE-1);return 1;}
int payload_plan(const uint8_t *b,size_t size,const struct policy *p,struct load_plan *out)
{
 struct load_plan plan;uint32_t n,i,j;uint64_t vb,entry,ao,as,ke,pb,ms,highest=0,rounded,adt_end;
 struct range win,source;int nul=0;const char magic[]="SWEETXNU";
 volatile uint8_t *zero=(volatile uint8_t *)&plan;size_t zi;
 for(zi=0;zi<sizeof(plan);zi++)zero[zi]=0;
 if(!b||!p||!out||p->forbidden_count>128||(p->forbidden_count&&!p->forbidden))return BAD_ARGUMENT;
 if(size<HEADER)return BAD_HEADER;
 for(i=0;i<8;i++)if(b[i]!=(uint8_t)magic[i])return BAD_HEADER;
 n=le32(b+12);if(le32(b+8)!=1||!n||n>32||size<HEADER+n*32)return BAD_HEADER;
 for(i=0;i<608;i++){if(!b[72+i]){nul=1;break;}}
 if(!nul)return BAD_HEADER;
 vb=le64(b+16);entry=le64(b+24);ao=le64(b+32);as=le64(b+40);ke=le64(b+48);pb=le64(b+56);ms=le64(b+64);
 if(!as||as>1048576||ao<HEADER+n*32||ao>size||as>size-ao)return BAD_HEADER;
 win=(struct range){pb,ms};source=p->source;
 if(!valid(win)||(pb&(PAGE-1))||(ms&(PAGE-1))||(vb&(PAGE-1))||
    !contains(p->dram,win)||!contains(p->approved_window,win)||
    !valid(source)||source.size!=(uint64_t)size||!contains(p->dram,source))return BAD_WINDOW;
 if(overlap(win,source))return OVERLAP;
 for(i=0;i<p->forbidden_count;i++){
  if(!valid(p->forbidden[i]))return BAD_ARGUMENT;
  if(overlap(win,p->forbidden[i]))return OVERLAP;
 }
 if(ke<vb||ke-vb>=ms||(ke&(PAGE-1))||entry<vb||entry-vb>=ms)return BAD_ENTRY;
 for(i=0;i<n;i++){
  const uint8_t *s=b+HEADER+i*32;uint64_t va=le64(s),sz=le64(s+8),off=le64(s+16),fs=le64(s+24),delta;
  if(va<vb||!sz||fs>sz||va>UINT64_MAX-sz||off>size||fs>size-off||(fs&&off<HEADER+n*32))return BAD_SEGMENT;
  delta=va-vb;if(sz>ms||delta>ms-sz||va+sz>ke)return BAD_SEGMENT;
  if(fs&&overlap((struct range){off,fs},(struct range){ao,as}))return OVERLAP;
  plan.segments[i]=(struct segment_plan){pb+delta,sz,off,fs};
  for(j=0;j<i;j++){
   if(overlap((struct range){plan.segments[j].destination,plan.segments[j].memory_size},(struct range){pb+delta,sz}))return OVERLAP;
   if(fs&&plan.segments[j].file_size&&overlap((struct range){off,fs},(struct range){plan.segments[j].source_offset,plan.segments[j].file_size}))return OVERLAP;
  }
  if(va+sz>highest)highest=va+sz;
  if(entry>=va&&entry-va<fs)plan.entry=pb+(entry-vb);
 }
 if(!plan.entry)return BAD_ENTRY;
 if(!align_page(highest,&rounded)||rounded>ke)return BAD_SEGMENT;
 plan.adt_destination=pb+(ke-vb);plan.adt_offset=ao;plan.adt_size=as;
 if(as>pb+ms-plan.adt_destination)return NO_METADATA_SPACE;
 adt_end=plan.adt_destination+as;
 if(!align_page(adt_end,&plan.bootargs)||plan.bootargs>pb+ms||PAGE>pb+ms-plan.bootargs)return NO_METADATA_SPACE;
 plan.top=plan.bootargs+PAGE;plan.segment_count=n;
 {volatile uint8_t *dst=(volatile uint8_t *)out;const volatile uint8_t *src=(const volatile uint8_t *)&plan;for(zi=0;zi<sizeof(plan);zi++)dst[zi]=src[zi];}
 return OK;
}
