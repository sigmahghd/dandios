/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_LOAD_H
#define DANDELION_LOAD_H
#include "metadata.h"
struct loaded_image { uint64_t entry, bootargs, top; };
/* ACTUALLY WRITES destination memory, but never jumps, maps or accesses MMIO.
 * mapped_window must be ordinary writable RAM representing approved_window;
 * caller must establish physical ownership, source identity and mapping accuracy.
 * An address falling inside DRAM is NOT sufficient authorization.
 * No cryptographic kernel authentication, relocations, MMU or cache maintenance.
 * No source/output/destination aliases are allowed. On error nothing is written.
 * Caller must prevent concurrent mutation of input and mapping during this call.
 * Returns metadata_prepare errors, 300=bad mapping/arguments, 301=pointer alias.
 */
int dandelion_load(const uint8_t *source, size_t length,
 const struct policy *, uint8_t *mapped_window, size_t mapped_length,
 struct loaded_image *out);
#endif
