#!/bin/sh
# SPDX-License-Identifier: MIT. Linux compile-only/test ELF, NOT a phone image.
set -eu
cd "$(dirname "$0")/.."
: "${ZIG:=/data/dandelion-toolchain/ziglang/zig}"
for name in load payload metadata; do
 "$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53 -std=c11 -ffreestanding -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror -c "loader/$name.c" -o "tests/$name-arm64.o"
done
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53 -nostdlib -Wl,-T,loader/module.ld -Wl,-e,dandelion_load tests/load-arm64.o tests/payload-arm64.o tests/metadata-arm64.o -o tests/load-arm64.elf
python tests/test_load.py
