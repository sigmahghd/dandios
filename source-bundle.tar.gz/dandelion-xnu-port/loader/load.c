/* SPDX-License-Identifier: MIT */
#include "load.h"
static int ptr_range(const void *p, size_t n, uintptr_t *begin, uintptr_t *end)
{
 uintptr_t v=(uintptr_t)p;
 if(!p || !n || n>UINTPTR_MAX-v)return 0;
 *begin=v;*end=v+n;return 1;
}
static int intersects(uintptr_t a,uintptr_t ae,uintptr_t b,uintptr_t be)
{return a<be && b<ae;}
/* Volatile byte loops: exact lengths, no speculative wide tail reads/writes,
 * and no implicit libc dependency in the freestanding build. */
static void copy(uint8_t *d,const uint8_t *s,size_t n)
{volatile uint8_t *v=d;const volatile uint8_t *r=s;size_t i;for(i=0;i<n;i++)v[i]=r[i];}
static void clear(uint8_t *d,size_t n)
{volatile uint8_t *v=d;size_t i;for(i=0;i<n;i++)v[i]=0;}
int dandelion_load(const uint8_t *b,size_t n,const struct policy *p,
 uint8_t *mapping,size_t mapping_size,struct loaded_image *out)
{
 struct metadata_plan m;struct policy policy;uint64_t base;uint32_t i;int rc;
 uintptr_t sb,se,db,de,ob,oe;
 if(!p||!out||!ptr_range(b,n,&sb,&se)||
    !ptr_range(mapping,mapping_size,&db,&de)||
    !ptr_range(out,sizeof *out,&ob,&oe))return 300;
 policy=*p;
 if(policy.approved_window.size!=(uint64_t)mapping_size)return 300;
 if(intersects(sb,se,db,de)||intersects(ob,oe,db,de)||intersects(ob,oe,sb,se))return 301;
 rc=metadata_prepare(b,n,&policy,&m);if(rc)return rc;
 /* All destination offsets are proven within approved_window by payload_plan.
  * The source and every derived destination remain immutable until validation
  * completes. No callbacks can fail midway through the following commit. */
 base=policy.approved_window.base;
 for(i=0;i<m.load.segment_count;i++){
  const struct segment_plan *s=&m.load.segments[i];
  uint8_t *d=mapping+(size_t)(s->destination-base);
  copy(d,b+(size_t)s->source_offset,(size_t)s->file_size);
  clear(d+(size_t)s->file_size,(size_t)(s->memory_size-s->file_size));
 }
 copy(mapping+(size_t)(m.load.adt_destination-base),b+(size_t)m.load.adt_offset,(size_t)m.load.adt_size);
 clear(mapping+(size_t)(m.load.bootargs-base),4096);
 copy(mapping+(size_t)(m.load.bootargs-base),m.bootargs,XNU_BOOTARGS_SIZE);
 out->entry=m.load.entry;out->bootargs=m.load.bootargs;out->top=m.load.top;
 return 0;
}
