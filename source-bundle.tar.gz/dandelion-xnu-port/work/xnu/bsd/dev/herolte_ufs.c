/*
 * HEROLTE (Galaxy S7, Exynos 8890) internal UFS root device.
 *
 * Derived from the SWEET driver (bsd/dev/sweet_ufs.c). S-Boot leaves the
 * UFSHCI host enabled with the link up after loading BOOT from it; this
 * driver reuses that state with polled SCSI commands on LUN 0, slot 0.
 * Exynos host quirks, from the Samsung kernel (ufs-exynos.c, ufshcd.c):
 *  - UTRD response UPIU and PRDT offsets/lengths are in bytes, not DWORDs
 *    (UFSHCI_QUIRK_BROKEN_DWORD_UTRD);
 *  - UTRLCLR takes a 1 to clear a slot (UFSHCI_QUIRK_BROKEN_REQ_LIST_CLR);
 *  - the vendor HCI_UTRL_NEXUS_TYPE bit of the slot marks a SCSI command;
 *  - PRDT entries describe at most 4 KiB (PRDT_SET_SIZE(12)).
 *
 * Boot-arg ufsprobe=1 only reads: it prints host registers and the GPT of
 * LUN 0. rd=ufsroot0 exposes the GPT partition ufsroot= (default
 * "USERDATA") as ufsroot0; writes need ufsrw=1 and stay inside it.
 */
#if defined(ARM64_BOARD_CONFIG_HEROLTE)
#include <sys/param.h>
#include <sys/systm.h>
#include <sys/buf.h>
#include <sys/conf.h>
#include <sys/disk.h>
#include <sys/errno.h>
#include <sys/proc.h>
#include <sys/uio.h>
#include <miscfs/devfs/devfs.h>
#include <kern/locks.h>
#include <kern/clock.h>
#include <kern/sched_prim.h>
#include <machine/machine_routines.h>
#include <arm/caches_internal.h>
#include <vm/pmap.h>
#include <vm/vm_kern.h>
#include <pexpert/pexpert.h>
#include <pexpert/device_tree.h>
#include <libkern/libkern.h>
#include <machine/atomic.h>

extern ppnum_t pmap_find_phys(pmap_t pmap, addr64_t va);
/* osfmk/arm/machine_routines.h, not exported to the BSD layer */
extern vm_offset_t ml_io_map(vm_offset_t phys_addr, vm_size_t size);
/* osfmk/arm/cpu_data.h, not exported to the BSD layer */
extern int get_preemption_level(void);
extern kern_return_t kernel_thread_start(thread_continue_t, void *, thread_t *);
extern void thread_deallocate(thread_t);
extern int hz;

#define REG_CAP         0x00
#define REG_IS          0x20
#define REG_IE          0x24
#define REG_HCS         0x30
#define REG_HCE         0x34
#define REG_UTRLBA      0x50
#define REG_UTRLBAU     0x54
#define REG_UTRLDBR     0x58
#define REG_UTRLCLR     0x5c
#define REG_UTRLRSR     0x60
#define REG_VER         0x08
/* Exynos vendor HCI registers, 0x100 above the standard block. */
#define VS_TXPRDT_ENTRY_SIZE    0x100
#define VS_RXPRDT_ENTRY_SIZE    0x104
#define VS_UTRL_NEXUS_TYPE      0x140
#define HEROLTE_UFS_MAP         0x300

#define HCS_DP          (1u << 0)
#define HCS_UTRLRDY     (1u << 1)
#define CAP_64AS        (1u << 24)              /* 64-bit DMA addressing */

#define UFS_BLOCK       4096u
#define BOUNCE_SIZE     (1u << 20)
#define PRDT_CHUNK      4096u                   /* Exynos PRDT_SET_SIZE(12) */
#define PRDT_MAX        (BOUNCE_SIZE / PRDT_CHUNK)
#define CMD_TIMEOUT_NS  (5ull * NSEC_PER_SEC)
#define CMD_SPIN_NS     (50ull * NSEC_PER_USEC)
#define CMD_SLEEP_NS    (200ull * NSEC_PER_USEC)

struct utrd {
	uint32_t dw0, dw1, dw2, dw3;
	uint32_t ucdba, ucdbau;
	uint32_t resp;          /* [31:16] response UPIU offset, [15:0] length, BYTES */
	uint32_t prdt;          /* [31:16] PRDT offset, [15:0] PRDT length, BYTES */
};

struct ucd {
	uint8_t cmd[512];
	uint8_t resp[512];
	struct {
		uint32_t addr_lo, addr_hi, rsvd, dbc;
	} prdt[PRDT_MAX];
};

/* Layout of the contiguous DMA allocation. */
#define DMA_UTRL        0x0000                  /* 1 KiB aligned */
#define DMA_UCD         0x1000                  /* 128 byte aligned, 5 KiB */
#define DMA_BOUNCE      0x4000
#define DMA_SIZE        (DMA_BOUNCE + BOUNCE_SIZE)

static struct {
	vm_offset_t regs;
	vm_offset_t dma;                        /* kernel VA of the DMA allocation */
	uint64_t dma_pa;
	uint8_t lun;
	uint8_t sense_key, asc, ascq;     /* last CHECK CONDITION */
	uint8_t tag;
	uint64_t first_block, nblocks;          /* partition, in 4 KiB device blocks */
	uint32_t secsize;                       /* logical sector size for the BSD layer */
	bool writable;                          /* boot-arg ufsrw=1 */
	bool cache;                             /* boot-arg ufscache=1 */
	bool wait;                              /* boot-arg ufswait=1 */
	int bmajor, cmajor;
	dev_t bdev;
	bool ready;
} su;

static LCK_GRP_DECLARE(herolte_ufs_grp, "herolte_ufs");
static LCK_MTX_DECLARE(herolte_ufs_lock, &herolte_ufs_grp);

static inline uint32_t
ufs_rd(uint32_t off)
{
	return *(volatile uint32_t *)(su.regs + off);
}

static inline void
ufs_wr(uint32_t off, uint32_t v)
{
	*(volatile uint32_t *)(su.regs + off) = v;
}

static void
dma_sync(uint32_t off, uint32_t len)
{
	flush_dcache64((addr64_t)(su.dma_pa + off), len, TRUE);
}

static void
dma_clean(uint32_t off, uint32_t len)
{
	clean_dcache64((addr64_t)(su.dma_pa + off), len, TRUE);
}

/*
 * One SCSI command in slot 0, data (if any) to/from the bounce buffer
 * (to the device when write is set). Returns 0 or an errno.
 */
static int
ufs_scsi(const uint8_t *cdb, unsigned cdb_len, uint32_t len, bool write)
{
	struct utrd *utrd = (struct utrd *)(su.dma + DMA_UTRL);
	struct ucd *ucd = (struct ucd *)(su.dma + DMA_UCD);
	uint64_t ucd_pa = su.dma_pa + DMA_UCD, bounce_pa = su.dma_pa + DMA_BOUNCE;

	assert(len <= BOUNCE_SIZE);
	bzero(utrd, sizeof(*utrd));
	bzero(ucd, sizeof(*ucd));

	ucd->cmd[0] = 0x01;                     /* COMMAND UPIU */
	ucd->cmd[1] = len ? (write ? 0x20 : 0x40) : 0x00;      /* W: data out, R: data in */
	ucd->cmd[2] = su.lun;
	ucd->cmd[3] = ++su.tag;
	ucd->cmd[12] = (uint8_t)(len >> 24);
	ucd->cmd[13] = (uint8_t)(len >> 16);
	ucd->cmd[14] = (uint8_t)(len >> 8);
	ucd->cmd[15] = (uint8_t)len;
	memcpy(&ucd->cmd[16], cdb, cdb_len);

	/* DD: 1 = memory to device, 2 = device to memory. */
	utrd->dw0 = (1u << 28) | ((len ? (write ? 1u : 2u) : 0u) << 25) | (1u << 24);
	utrd->dw2 = 0x0f;                       /* OCS invalid until updated */
	utrd->ucdba = (uint32_t)ucd_pa;
	utrd->ucdbau = (uint32_t)(ucd_pa >> 32);
	utrd->resp = 512u << 16 | 512u;
	if (len) {
		uint32_t n = 0;
		for (uint32_t done = 0; done < len; done += PRDT_CHUNK, n++) {
			uint32_t chunk = MIN(PRDT_CHUNK, len - done);
			ucd->prdt[n].addr_lo = (uint32_t)(bounce_pa + done);
			ucd->prdt[n].addr_hi = (uint32_t)((bounce_pa + done) >> 32);
			ucd->prdt[n].dbc = chunk - 1;
		}
		utrd->prdt = 1024u << 16 | (n * (uint32_t)sizeof(ucd->prdt[0]));
	}

	if (su.cache) {
		dma_clean(DMA_UTRL, sizeof(*utrd));
		dma_clean(DMA_UCD, 16 + cdb_len);
		dma_sync(DMA_UCD + offsetof(struct ucd, resp), sizeof(ucd->resp));
		if (len) {
			dma_clean(DMA_UCD + offsetof(struct ucd, prdt),
			    utrd->prdt & 0xffff);
		}
	} else {
		dma_sync(DMA_UTRL, sizeof(*utrd));
		dma_sync(DMA_UCD, sizeof(*ucd));
	}
	if (len) {
		if (su.cache && write) {
			dma_clean(DMA_BOUNCE, len);
		} else {
			dma_sync(DMA_BOUNCE, len);
		}
	}
	__builtin_arm_dsb(0xf);

	ufs_wr(VS_UTRL_NEXUS_TYPE, ufs_rd(VS_UTRL_NEXUS_TYPE) | 1u);   /* slot 0: SCSI */
	ufs_wr(REG_UTRLDBR, 1);
	uint64_t deadline;
	nanoseconds_to_absolutetime(CMD_TIMEOUT_NS, &deadline);
	deadline += mach_absolute_time();
	bool sleepable = su.wait && su.ready && ml_get_interrupts_enabled() &&
	    !ml_at_interrupt_context() && get_preemption_level() == 0;
	uint64_t spin_until = 0, sleep_interval = 0;
	if (sleepable) {
		nanoseconds_to_absolutetime(CMD_SPIN_NS, &spin_until);
		spin_until += mach_absolute_time();
		nanoseconds_to_absolutetime(CMD_SLEEP_NS, &sleep_interval);
	}
	while (ufs_rd(REG_UTRLDBR) & 1) {
		uint64_t now = mach_absolute_time();
		if (now > deadline) {
			ufs_wr(REG_UTRLCLR, 1u);   /* BROKEN_REQ_LIST_CLR */
			printf("HEROLTE UFS: command 0x%02x timed out\n", cdb[0]);
			return ETIMEDOUT;
		}
		if (sleepable && now >= spin_until) {
			uint64_t wake = now + MIN(sleep_interval, deadline - now);
			/* Keep the mutex: slot 0 and the bounce buffer are still owned. */
			if (assert_wait_deadline_with_leeway((event_t)&su.wait, THREAD_UNINT,
			    TIMEOUT_URGENCY_SYS_CRITICAL, wake, 0) == THREAD_WAITING) {
				thread_block(THREAD_CONTINUE_NULL);
			}
		} else {
			delay(1);
		}
	}
	__builtin_arm_dsb(0xf);
	ufs_wr(REG_IS, ufs_rd(REG_IS));         /* acknowledge completion status */

	dma_sync(DMA_UTRL, sizeof(*utrd));
	if (su.cache) {
		dma_sync(DMA_UCD + offsetof(struct ucd, resp), sizeof(ucd->resp));
	} else {
		dma_sync(DMA_UCD, sizeof(*ucd));
	}
	if (len && !(su.cache && write)) {
		dma_sync(DMA_BOUNCE, len);
	}

	uint32_t ocs = utrd->dw2 & 0xff;
	if (ocs || ucd->resp[0] != 0x21 || ucd->resp[6] || ucd->resp[7]) {
		const uint8_t *s = &ucd->resp[34];
		unsigned slen = (unsigned)ucd->resp[32] << 8 | ucd->resp[33];
		su.sense_key = slen >= 3 ? s[2] & 0xf : 0xff;
		su.asc = slen >= 13 ? s[12] : 0xff;
		su.ascq = slen >= 14 ? s[13] : 0xff;
		printf("HEROLTE UFS: lun %u cmd 0x%02x failed: ocs 0x%x upiu 0x%x resp 0x%x status 0x%x"
		    " sense len %u key 0x%x asc 0x%x ascq 0x%x\n",
		    su.lun, cdb[0], ocs, ucd->resp[0], ucd->resp[6], ucd->resp[7],
		    slen, su.sense_key, su.asc, su.ascq);
		return EIO;
	}
	return 0;
}

/* READ(10) of count device blocks at lba into the bounce buffer. */
static int
ufs_read_blocks(uint64_t lba, uint32_t count)
{
	if (lba > UINT32_MAX || count > BOUNCE_SIZE / UFS_BLOCK) {
		return EINVAL;
	}
	uint8_t cdb[10] = {
		0x28, 0,
		(uint8_t)(lba >> 24), (uint8_t)(lba >> 16), (uint8_t)(lba >> 8), (uint8_t)lba,
		0, (uint8_t)(count >> 8), (uint8_t)count, 0
	};
	return ufs_scsi(cdb, sizeof(cdb), count * UFS_BLOCK, false);
}

/*
 * WRITE(10) of count device blocks from the bounce buffer to lba. The range
 * must lie inside the partition: this is the only place data goes out.
 */
static int
ufs_write_blocks(uint64_t lba, uint32_t count)
{
	if (!su.writable || !su.nblocks || count == 0 || count > BOUNCE_SIZE / UFS_BLOCK ||
	    lba < su.first_block || lba - su.first_block >= su.nblocks ||
	    count > su.nblocks - (lba - su.first_block) || lba + count - 1 > UINT32_MAX) {
		printf("HEROLTE UFS: refusing write of %u blocks at 0x%llx\n", count, lba);
		return EPERM;
	}
	uint8_t cdb[10] = {
		0x2a, 0,
		(uint8_t)(lba >> 24), (uint8_t)(lba >> 16), (uint8_t)(lba >> 8), (uint8_t)lba,
		0, (uint8_t)(count >> 8), (uint8_t)count, 0
	};
	return ufs_scsi(cdb, sizeof(cdb), count * UFS_BLOCK, true);
}

static int
ufs_sync_cache(void)
{
	static const uint8_t cdb[10] = { 0x35 };       /* SYNCHRONIZE CACHE(10), whole LUN */
	return ufs_scsi(cdb, sizeof(cdb), 0, false);
}

static int
ufs_find_partition(const char *want)
{
	const uint8_t *b = (const uint8_t *)(su.dma + DMA_BOUNCE);
	int error = ufs_read_blocks(1, 1);
	if (error) {
		return error;
	}
	if (memcmp(b, "EFI PART", 8) != 0) {
		printf("HEROLTE UFS: LUN %u has no GPT\n", su.lun);
		return ENXIO;
	}
	uint64_t entry_lba;
	uint32_t nent, esz;
	memcpy(&entry_lba, b + 72, 8);
	memcpy(&nent, b + 80, 4);
	memcpy(&esz, b + 84, 4);
	if (esz != 128 || nent == 0 || nent * esz > BOUNCE_SIZE) {
		printf("HEROLTE UFS: unsupported GPT entries %u x %u\n", nent, esz);
		return ENXIO;
	}
	error = ufs_read_blocks(entry_lba, (nent * esz + UFS_BLOCK - 1) / UFS_BLOCK);
	if (error) {
		return error;
	}
	for (uint32_t i = 0; i < nent; i++) {
		const uint8_t *e = b + i * esz;
		char name[37];
		unsigned c;
		for (c = 0; c < 36; c++) {
			uint16_t ch = (uint16_t)(e[56 + 2 * c] | e[57 + 2 * c] << 8);
			if (ch == 0 || ch > 0x7f) {
				break;
			}
			name[c] = (char)ch;
		}
		name[c] = 0;
		if (strcmp(name, want) != 0) {
			continue;
		}
		uint64_t first, last;
		memcpy(&first, e + 32, 8);
		memcpy(&last, e + 40, 8);
		if (last < first) {
			return ENXIO;
		}
		su.first_block = first;
		su.nblocks = last - first + 1;
		return 0;
	}
	printf("HEROLTE UFS: no GPT partition named \"%s\"\n", want);
	return ENOENT;
}

/*
 * Bring the device to the Active power mode: clear the unit attention of the
 * UFS Device well-known LUN, then START STOP UNIT with power condition 1
 * (ACTIVE), as ufshcd_set_dev_pwr_mode() does. Leaves su.lun at 0.
 */
static int
ufs_wake_device(void)
{
	static const uint8_t tur[6] = { 0x00 };
	static const uint8_t ssu[6] = { 0x1b, 0, 0, 0, 0x10, 0 };
	int error = 0;

	su.lun = 0xd0;                          /* UFS Device W-LUN */
	for (int i = 0; i < 3 && (error = ufs_scsi(tur, sizeof(tur), 0, false)); i++) {
	}
	printf("HEROLTE UFS: device W-LUN TEST UNIT READY %d\n", error);
	for (int i = 0; i < 3 && (error = ufs_scsi(ssu, sizeof(ssu), 0, false)); i++) {
	}
	printf("HEROLTE UFS: START STOP UNIT (ACTIVE) %d\n", error);
	su.lun = 0;
	return error;
}

static int
ufs_take_over_host(void)
{
	uint32_t hce = ufs_rd(REG_HCE), hcs = ufs_rd(REG_HCS);
	if (!(hce & 1) || !(hcs & HCS_DP) || !(hcs & HCS_UTRLRDY)) {
		printf("HEROLTE UFS: host not ready (hce 0x%x hcs 0x%x)\n", hce, hcs);
		return ENXIO;
	}
	if (ufs_rd(REG_UTRLDBR)) {
		printf("HEROLTE UFS: requests outstanding from the bootloader\n");
		return EBUSY;
	}
	/* With RAM above 4 GiB (mkadt.py --highmem) the DMA memory can be there too. */
	if (((su.dma_pa + DMA_SIZE - 1) >> 32) && !(ufs_rd(REG_CAP) & CAP_64AS)) {
		printf("HEROLTE UFS: DMA memory at 0x%llx but the host has no 64-bit addressing\n",
		    su.dma_pa);
		return ENXIO;
	}
	ufs_wr(REG_IE, 0);                      /* polled operation */
	ufs_wr(REG_IS, ufs_rd(REG_IS));
	ufs_wr(REG_UTRLRSR, 0);
	uint64_t list = su.dma_pa + DMA_UTRL;
	ufs_wr(REG_UTRLBA, (uint32_t)list);
	ufs_wr(REG_UTRLBAU, (uint32_t)(list >> 32));
	ufs_wr(REG_UTRLRSR, 1);
	/* Never ring a doorbell unless the host uses our list. */
	if (ufs_rd(REG_UTRLBA) != (uint32_t)list || ufs_rd(REG_UTRLBAU) != (uint32_t)(list >> 32) ||
	    !(ufs_rd(REG_UTRLRSR) & 1)) {
		printf("HEROLTE UFS: host did not take our request list\n");
		return EIO;
	}
	return 0;
}

static int
herolte_ufs_open(__unused dev_t dev, int flags, __unused int devtype, __unused struct proc *p)
{
	if (!su.ready) {
		return ENXIO;
	}
	return ((flags & FWRITE) && !su.writable) ? EROFS : 0;
}

static int
herolte_ufs_close(__unused dev_t dev, __unused int flags, __unused int devtype, __unused struct proc *p)
{
	return 0;
}

static void
herolte_ufs_strategy(buf_t bp)
{
	int error = 0;
	caddr_t vaddr = NULL;
	uint64_t off = (uint64_t)buf_blkno(bp) * su.secsize;
	uint32_t count = buf_count(bp);
	uint64_t part_bytes = su.nblocks * UFS_BLOCK;

	bool rd = buf_flags(bp) & B_READ;

	buf_setresid(bp, count);
	if (!rd && !su.writable) {
		error = EROFS;
		goto done;
	}
	if (off > part_bytes || count > part_bytes - off) {
		error = EINVAL;
		goto done;
	}
	if (count == 0) {
		goto done;
	}
	if (buf_map(bp, &vaddr)) {
		error = EIO;
		goto done;
	}

	lck_mtx_lock(&herolte_ufs_lock);
	for (uint32_t done = 0; done < count;) {
		uint64_t pos = off + done;
		uint64_t lba = pos / UFS_BLOCK;
		uint32_t skip = (uint32_t)(pos % UFS_BLOCK);
		uint32_t want = MIN(count - done, BOUNCE_SIZE - skip);
		uint32_t blocks = (skip + want + UFS_BLOCK - 1) / UFS_BLOCK;
		void *bounce = (void *)(su.dma + DMA_BOUNCE);
		if (rd) {
			error = ufs_read_blocks(su.first_block + lba, blocks);
			if (!error) {
				memcpy(vaddr + done, (const char *)bounce + skip, want);
			}
		} else {
			/* Partial device blocks at either end: read, merge, write back. */
			if (skip || (want % UFS_BLOCK)) {
				error = ufs_read_blocks(su.first_block + lba, blocks);
			}
			if (!error) {
				memcpy((char *)bounce + skip, vaddr + done, want);
				error = ufs_write_blocks(su.first_block + lba, blocks);
			}
		}
		if (error) {
			break;
		}
		done += want;
		buf_setresid(bp, count - done);
	}
	lck_mtx_unlock(&herolte_ufs_lock);
	buf_unmap(bp);

done:
	if (error) {
		buf_seterror(bp, error);
	}
	buf_biodone(bp);
}

static int
herolte_ufs_ioctl(__unused dev_t dev, u_long cmd, caddr_t data, __unused int flag,
    __unused struct proc *p, int is_char)
{
	uint32_t *f = (uint32_t *)data;
	uint64_t *o = (uint64_t *)data;

	switch (cmd) {
	case DKIOCGETBLOCKSIZE:
		*f = su.secsize;
		return 0;
	case DKIOCSETBLOCKSIZE:
		if (is_char) {
			return ENODEV;
		}
		if (*f < DEV_BSIZE || *f > UFS_BLOCK || (*f & (*f - 1))) {
			return EINVAL;
		}
		su.secsize = *f;
		return 0;
	case DKIOCGETPHYSICALBLOCKSIZE:
		*f = UFS_BLOCK;
		return 0;
	case DKIOCGETBLOCKCOUNT:
		*o = su.nblocks * UFS_BLOCK / su.secsize;
		return 0;
	case DKIOCISWRITABLE:
		*f = su.writable;
		return 0;
	case DKIOCSYNCHRONIZE:
	case DKIOCSYNCHRONIZECACHE: {
		if (!su.writable) {
			return 0;
		}
		lck_mtx_lock(&herolte_ufs_lock);
		int error = ufs_sync_cache();
		lck_mtx_unlock(&herolte_ufs_lock);
		return error;
	}
	case DKIOCGETMAXBLOCKCOUNTREAD:
		*o = BOUNCE_SIZE / su.secsize;
		return 0;
	case DKIOCGETMAXBLOCKCOUNTWRITE:
		*o = su.writable ? BOUNCE_SIZE / su.secsize : 0;
		return 0;
	case DKIOCGETMAXSEGMENTCOUNTREAD:
	case DKIOCGETMAXSEGMENTCOUNTWRITE:
		*o = 1;
		return 0;
	default:
		return ENOTTY;
	}
}

static int
herolte_ufs_bioctl(dev_t dev, u_long cmd, caddr_t data, int flag, struct proc *p)
{
	return herolte_ufs_ioctl(dev, cmd, data, flag, p, 0);
}

static int
herolte_ufs_cioctl(dev_t dev, u_long cmd, caddr_t data, int flag, struct proc *p)
{
	return herolte_ufs_ioctl(dev, cmd, data, flag, p, 1);
}

static int
herolte_ufs_psize(__unused dev_t dev)
{
	return su.ready ? (int)MIN(su.nblocks * UFS_BLOCK / su.secsize, INT_MAX) : -1;
}

static int
herolte_ufs_read(dev_t dev, struct uio *uio, __unused int ioflag)
{
	return physio(herolte_ufs_strategy, NULL, dev, B_READ, minphys, uio, (int)su.secsize);
}

static int
herolte_ufs_write(dev_t dev, struct uio *uio, __unused int ioflag)
{
	if (!su.writable) {
		return EROFS;
	}
	return physio(herolte_ufs_strategy, NULL, dev, B_WRITE, minphys, uio, (int)su.secsize);
}

static const struct bdevsw herolte_ufs_bdevsw = {
	.d_open     = herolte_ufs_open,
	.d_close    = herolte_ufs_close,
	.d_strategy = herolte_ufs_strategy,
	.d_ioctl    = herolte_ufs_bioctl,
	.d_dump     = eno_dump,
	.d_psize    = herolte_ufs_psize,
	.d_type     = D_DISK,
};

static const struct cdevsw herolte_ufs_cdevsw = {
	.d_open       = herolte_ufs_open,
	.d_close      = herolte_ufs_close,
	.d_read       = herolte_ufs_read,
	.d_write      = herolte_ufs_write,
	.d_ioctl      = herolte_ufs_cioctl,
	.d_stop       = eno_stop,
	.d_reset      = eno_reset,
	.d_ttys       = NULL,
	.d_select     = eno_select,
	.d_mmap       = eno_mmap,
	.d_strategy   = eno_strat,
	.d_reserved_1 = eno_getc,
	.d_reserved_2 = eno_putc,
	.d_type       = D_DISK,
};

/*
 * Persistent console log ("herolog"): the console ring (a5xelte_emmc.c) is
 * copied every 10 s to the last 4 MiB + 4 KiB of the root partition, beyond
 * the HFSX volume, and the device cache is flushed. Block 0 of that area:
 *   "HEROLOG1" | u32 version 1 | u32 ring size | u64 total bytes | u64 seq
 * ring offset of byte n = n % ring size. Read it from TWRP with
 * tools/herolte-log-pull.py. Needs ufsrw=1; boot-arg herolog=0 disables it.
 */
extern void a5xelte_log_snapshot(const char **ring, uint32_t *size, uint64_t *total);
extern kern_return_t kernel_thread_start(thread_continue_t, void *, thread_t *);
extern void thread_deallocate(thread_t);
extern int hz;
extern void sweet_sample_start(void);

struct herolte_log_header {
	char magic[8];
	uint32_t version, size;
	uint64_t total, seq;
};

static int herolte_log_chan;

static void
herolte_log_thread(__unused void *arg, __unused wait_result_t wr)
{
	const char *ring;
	uint32_t rsize;
	uint64_t total, flushed = 0, seq = 0;
	uint32_t ticks = 0;
	a5xelte_log_snapshot(&ring, &rsize, &total);
	uint64_t first = su.first_block + su.nblocks - (1 + rsize / UFS_BLOCK);
	uint8_t *bounce = (uint8_t *)(su.dma + DMA_BOUNCE);
	printf("HEROLTE LOG: %u KiB ring at partition block %llu\n",
	    rsize >> 10, first - su.first_block);
	for (;;) {
		(void)tsleep(&herolte_log_chan, PZERO, "herolog", hz * 10);
		/* Heartbeat: gaps between these lines show CPU starvation. */
		if (++ticks % 6 == 0) {
			printf("HEROLTE LOG: alive %u s\n", ticks * 10);
		}
		a5xelte_log_snapshot(&ring, &rsize, &total);
		if (total == flushed) {
			continue;
		}
		uint64_t pos = total - flushed >= rsize ? total - rsize : flushed;
		uint64_t left = total - pos;
		int error = 0;
		lck_mtx_lock(&herolte_ufs_lock);
		while (left && !error) {
			uint32_t blk = (uint32_t)((pos % rsize) / UFS_BLOCK);
			uint32_t skip = (uint32_t)(pos % UFS_BLOCK);
			uint32_t n = (uint32_t)MIN((uint64_t)(BOUNCE_SIZE / UFS_BLOCK),
			    MIN((uint64_t)(rsize / UFS_BLOCK - blk), (left + skip + UFS_BLOCK - 1) / UFS_BLOCK));
			memcpy(bounce, ring + (size_t)blk * UFS_BLOCK, (size_t)n * UFS_BLOCK);
			error = ufs_write_blocks(first + 1 + blk, n);
			uint64_t adv = (uint64_t)n * UFS_BLOCK - skip;
			pos += adv;
			left -= MIN(adv, left);
		}
		if (!error) {
			struct herolte_log_header h = {
				.magic = { 'H', 'E', 'R', 'O', 'L', 'O', 'G', '1' },
				.version = 1, .size = rsize, .total = total, .seq = ++seq,
			};
			bzero(bounce, UFS_BLOCK);
			memcpy(bounce, &h, sizeof(h));
			error = ufs_write_blocks(first, 1);
		}
		if (!error) {
			error = ufs_sync_cache();
		}
		lck_mtx_unlock(&herolte_ufs_lock);
		if (error) {
			printf("HEROLTE LOG: write failed (%d), stopping\n", error);
			return;
		}
		flushed = total;
	}
}

static void
herolte_log_start(void)
{
	uint32_t on = 1;
	thread_t thread;
	PE_parse_boot_argn("herolog", &on, sizeof(on));
	if (!on || !su.writable || su.nblocks < 2 * (1 + (4u << 20) / UFS_BLOCK)) {
		return;
	}
	if (kernel_thread_start(herolte_log_thread, NULL, &thread) == KERN_SUCCESS) {
		thread_deallocate(thread);
	}
	/* Thread backtraces of SpringBoard/backboardd (bsd/dev/sweet_sample.c). */
	sweet_sample_start();
}

static int
herolte_ufs_init(void)
{
	DTEntry node;
	uintptr_t const *reg = NULL;
	unsigned int size = 0;
	char want[64] = "USERDATA";
	int error;

	if (SecureDTLookupEntry(NULL, "/herolte-ufs", &node) != kSuccess ||
	    SecureDTGetProperty(node, "reg", (void const **)&reg, &size) != kSuccess ||
	    size < 2 * sizeof(uintptr_t)) {
		printf("HEROLTE UFS: no /herolte-ufs node in the device tree\n");
		return ENXIO;
	}
	PE_parse_boot_argn("ufsroot", want, sizeof(want));
	uint32_t rw = 0;
	PE_parse_boot_argn("ufsrw", &rw, sizeof(rw));
	uint32_t cache = 0, wait = 0;
	PE_parse_boot_argn("ufscache", &cache, sizeof(cache));
	PE_parse_boot_argn("ufswait", &wait, sizeof(wait));
	su.cache = (cache == 1);
	su.wait = (wait == 1);

	su.regs = ml_io_map(reg[0], MAX(reg[1], (uintptr_t)HEROLTE_UFS_MAP));
	if (kmem_alloc_contig(kernel_map, &su.dma, DMA_SIZE, PAGE_MASK, 0, 0,
	    KMA_DATA | KMA_ZERO | KMA_PERMANENT, VM_KERN_MEMORY_IOKIT) != KERN_SUCCESS) {
		printf("HEROLTE UFS: no contiguous DMA memory\n");
		return ENOMEM;
	}
	ppnum_t pn = pmap_find_phys(kernel_pmap, (addr64_t)su.dma);
	if (!pn) {
		return ENOMEM;
	}
	su.dma_pa = ptoa_64(pn);
	su.lun = 0;
	su.secsize = DEV_BSIZE;

	lck_mtx_lock(&herolte_ufs_lock);
	error = ufs_take_over_host();
	if (!error) {
		(void)ufs_wake_device();
	}
	if (!error) {
		static const uint8_t tur[6] = { 0x00 };
		/* The first command after the bootloader may report a unit attention. */
		for (int i = 0; i < 3 && (error = ufs_scsi(tur, sizeof(tur), 0, false)); i++) {
		}
	}
	if (!error) {
		error = ufs_find_partition(want);
	}
	lck_mtx_unlock(&herolte_ufs_lock);
	if (error) {
		return error;
	}

	su.bmajor = bdevsw_add(-1, &herolte_ufs_bdevsw);
	if (su.bmajor < 0) {
		return ENXIO;
	}
	su.cmajor = cdevsw_add_with_bdev(-1, &herolte_ufs_cdevsw, su.bmajor);
	if (su.cmajor < 0) {
		return ENXIO;
	}
	su.bdev = makedev(su.bmajor, 0);
	devfs_make_node(su.bdev, DEVFS_BLOCK, UID_ROOT, GID_OPERATOR, 0640, "ufsroot0");
	devfs_make_node(makedev(su.cmajor, 0), DEVFS_CHAR, UID_ROOT, GID_OPERATOR, 0640, "rufsroot0");
	/* Only now, with the partition bounds known, can writes be allowed. */
	su.writable = (rw != 0);
	su.ready = true;
	printf("HEROLTE UFS: \"%s\" on LUN %u: first block 0x%llx, %llu MiB, %s, DMA at 0x%llx\n",
	    want, su.lun, su.first_block, su.nblocks * UFS_BLOCK >> 20,
	    su.writable ? "read-write" : "read-only", su.dma_pa);
	herolte_log_start();
	return 0;
}

/* Boot-arg ufsprobe=1: print the host state and the LUN 0 GPT. Read only. */
void herolte_ufs_probe(void);

void
herolte_ufs_probe(void)
{
	DTEntry node;
	uintptr_t const *reg = NULL;
	unsigned int size = 0;

	if (SecureDTLookupEntry(NULL, "/herolte-ufs", &node) != kSuccess ||
	    SecureDTGetProperty(node, "reg", (void const **)&reg, &size) != kSuccess ||
	    size < 2 * sizeof(uintptr_t)) {
		printf("HEROLTE UFS: probe: no /herolte-ufs node\n");
		return;
	}
	if (!su.regs) {
		su.regs = ml_io_map(reg[0], MAX(reg[1], (uintptr_t)HEROLTE_UFS_MAP));
	}
	printf("HEROLTE UFS: probe: cap 0x%x ver 0x%x hcs 0x%x hce 0x%x is 0x%x utrlba 0x%x:%x dbr 0x%x rsr 0x%x\n",
	    ufs_rd(REG_CAP), ufs_rd(REG_VER), ufs_rd(REG_HCS), ufs_rd(REG_HCE), ufs_rd(REG_IS),
	    ufs_rd(REG_UTRLBAU), ufs_rd(REG_UTRLBA), ufs_rd(REG_UTRLDBR), ufs_rd(REG_UTRLRSR));
	printf("HEROLTE UFS: probe: txprdt 0x%x rxprdt 0x%x nexus 0x%x\n",
	    ufs_rd(VS_TXPRDT_ENTRY_SIZE), ufs_rd(VS_RXPRDT_ENTRY_SIZE), ufs_rd(VS_UTRL_NEXUS_TYPE));
	if (!su.dma && kmem_alloc_contig(kernel_map, &su.dma, DMA_SIZE, PAGE_MASK, 0, 0,
	    KMA_DATA | KMA_ZERO | KMA_PERMANENT, VM_KERN_MEMORY_IOKIT) != KERN_SUCCESS) {
		printf("HEROLTE UFS: probe: no contiguous DMA memory\n");
		return;
	}
	su.dma_pa = ptoa_64(pmap_find_phys(kernel_pmap, (addr64_t)su.dma));
	su.lun = 0;

	lck_mtx_lock(&herolte_ufs_lock);
	int error = ufs_take_over_host();
	if (!error) {
		(void)ufs_wake_device();
	}
	if (!error) {
		static const uint8_t tur[6] = { 0x00 };
		for (unsigned lun = 0; lun < 4; lun++) {
			int e = 0;
			su.lun = (uint8_t)lun;
			for (int i = 0; i < 3 && (e = ufs_scsi(tur, sizeof(tur), 0, false)); i++) {
			}
			printf("HEROLTE UFS: probe: lun %u TEST UNIT READY %d\n", lun, e);
		}
		su.lun = 0;
	}
	const uint8_t *b = (const uint8_t *)(su.dma + DMA_BOUNCE);
	if (!error) {
		error = ufs_read_blocks(1, 1);
		printf("HEROLTE UFS: probe: READ(10) LBA1 %d, signature %.8s\n", error,
		    error ? "-" : (const char *)b);
	}
	if (!error && memcmp(b, "EFI PART", 8) == 0) {
		uint64_t entry_lba;
		uint32_t nent, esz;
		memcpy(&entry_lba, b + 72, 8);
		memcpy(&nent, b + 80, 4);
		memcpy(&esz, b + 84, 4);
		printf("HEROLTE UFS: probe: GPT entries %u x %u at LBA %llu\n", nent, esz, entry_lba);
		if (esz == 128 && nent && nent * esz <= BOUNCE_SIZE &&
		    !ufs_read_blocks(entry_lba, (nent * esz + UFS_BLOCK - 1) / UFS_BLOCK)) {
			for (uint32_t i = 0; i < nent; i++) {
				const uint8_t *e = b + i * esz;
				uint64_t first, last;
				char name[37];
				unsigned c;
				memcpy(&first, e + 32, 8);
				memcpy(&last, e + 40, 8);
				if (!first && !last) {
					continue;
				}
				for (c = 0; c < 36; c++) {
					uint16_t ch = (uint16_t)(e[56 + 2 * c] | e[57 + 2 * c] << 8);
					if (ch == 0 || ch > 0x7f) {
						break;
					}
					name[c] = (char)ch;
				}
				name[c] = 0;
				printf("HEROLTE UFS: p%u %s %llu+%llu (%llu MiB)\n", i + 1, name,
				    first, last - first + 1, (last - first + 1) * UFS_BLOCK >> 20);
			}
		}
	}
	lck_mtx_unlock(&herolte_ufs_lock);
	printf("HEROLTE UFS: probe done (%d)\n", error);
}

/* Root device for rd=ufsroot0 (IOFindBSDRoot). */
int herolte_ufs_rootdev(dev_t *dev);

int
herolte_ufs_rootdev(dev_t *dev)
{
	if (!su.ready) {
		int error = herolte_ufs_init();
		if (error) {
			return error;
		}
	}
	*dev = su.bdev;
	return 0;
}
#endif /* ARM64_BOARD_CONFIG_HEROLTE */
