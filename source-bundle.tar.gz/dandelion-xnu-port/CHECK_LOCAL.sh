#!/bin/sh
# SPDX-License-Identifier: MIT. LOCAL partial build/model checks, not XNU build.
set -eu
cd "$(dirname "$0")"
: "${ZIG:=/data/dandelion-toolchain/ziglang/zig}"
export ZIG
export PYTHONPATH="/data/dandelion-emulator:/data/dandelion-disasm${PYTHONPATH:+:$PYTHONPATH}"
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53 -D__arm64__ -DASSEMBLER -DARM64_BOARD_CONFIG_DANDELION -Iwork/xnu/osfmk -Iwork/xnu/pexpert -c tests/board_probe.S -o tests/board_probe-arm64.o
sh loader/BUILD.sh
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53 -nostdlib -Wl,-T,loader/module.ld -Wl,-e,CleanPoU_DcacheRegion tests/cache-extracted.S -o tests/cache-arm64.elf
python tests/emulate_cache.py
python tests/emulate_load.py
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53 -nostdlib -Wl,-T,platform/handoff.ld platform/handoff_el2.S -o tests/handoff-el2-arm64.elf
python tests/emulate_handoff.py
gcc -std=c11 -O2 -Itests/gic-mocks tests/test_gic_kernel.c -o tests/test-gic-kernel
for n in 0 1 2 3 4 5 6 7 8 9; do ./tests/test-gic-kernel "$n"; done
g++ -std=c++17 -O2 -Itests/cpu-mocks tests/test_cpu_kernel.cpp -o tests/test-cpu-kernel
for n in 0 1 2 3 4 5 6 7; do ./tests/test-cpu-kernel "$n"; done
gcc -std=c11 -Wall -Wextra -Werror -O2 tests/test_fbcon.c -o tests/test-fbcon
for c in success disabled absent_arg wrong_arg missing_node short_reg bad_pa bad_size bad_width bad_height bad_pitch map1_failure map2_failure; do ./tests/test-fbcon "$c"; done
python tests/test_dandelion_adt.py
python tests/run_provider_tests.py
python tests/test_macos_build.py
python tests/check_patch_stack.py
echo 'PASS local partial/model checks only; NO full XNU build or phone write.'
