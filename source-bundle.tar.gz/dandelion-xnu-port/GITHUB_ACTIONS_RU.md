# GitHub Actions: экспериментальная сборка Dandelion XNU

## Что уже подготовлено

`.github/workflows/dandelion-xnu.yml` — ручной workflow. Запускает macOS14/Xcode15.4, проверяет исходники, скачивает закреплённый KDK13.5/22G74 с SHA256, проверяет Apple-подпись пакета и устанавливает его только на временный GitHub-hosted runner. Затем собирает закреплённые открытые зависимости и пытается собрать DEVELOPMENT ARM64 DANDELION. Это ещё не проверенный CI run: конфигурация подготовлена и протестирована локально, а не исполнена на GitHub.

Все Actions закреплены commit SHA; permissions=contents:read, checkout не сохраняет credentials. Нет pull_request/push/schedule-триггеров, только ручной запуск. Timeout180мин, artifacts7дней. Никаких fastboot/ADB/изменений телефона.

KDK берётся из публичного зеркала Dortania; URL, SHA256 и размер закреплены в ci/kdk-lock.json. Это не загрузка с неизвестного случайного сайта и не пропуск Apple-подписи. Если подпись не распознана, установка останавливается — не отключайте проверку ради зелёной галочки.

Шесть исходных зависимостей Apple закреплены commit SHA (ci/dependencies-lock.json). Из точного dxb-рецепта берётся только whitelist build-функций. Его install_deps/choose_xnu/get_xnu/patches/main не копируются и не исполняются; source tree не заменяется новым клоном. Firehose собирается plainARM64, не arm64e-only.

## Первый запуск с Windows

1. Создать репозиторий, например `dandelion-xnu`. Если выбран Public, содержимое станет общедоступным — загружать только этот исходный комплект, никогда не папку с личными дампами телефона. Учитывайте условия GitHub Actions и лицензии зависимостей.
2. Распаковать полученный комплект. В корне репозитория должны лежать `.github`, `ci`, `work`, `build_support`, `SOURCE_TREE_SHA256.json` и остальные файлы, а не дополнительная внешняя папка `dandelion-xnu-port`.
3. Предпочтительно загрузить через git: исходников больше5000, веб-загрузка неудобна. Из корня исходников выполнить в PowerShell (заменить OWNER/REPO своей ссылкой):

```powershell
git init
git add .
git status --short
git commit -m "Prepare experimental Dandelion XNU build"
git branch -M main
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
```

Перед `git commit` проверить список. Не должно быть boot/recovery/LK/expdb/FDT captures, SDK/KDK или секретов. Git авторизацию выполняйте через Git Credential Manager/свой браузер; пароль/токен в чат не отправлять.

4. Открыть вкладку Actions → Dandelion XNU (experimental) → Run workflow. Для короткой проверки сначала выбрать `environment`, затем полноценный `build`. Workflow должен лежать в default branch.
5. При ошибке скачать artifact `dandelion-logs-...` со страницы запуска. Первая ошибка инструментов/компилятора — ожидаемое основание следующей правки, а не повод прошивать телефон.
6. Только при реально успешной сборке появится `dandelion-kernel-NOT-FLASHABLE-...`. Это Mach-O ядро, НЕ boot.img и НЕ разрешение прошивать.

## Важное ограничение runner

Образ macos14 с Xcode15 объявлен к отключению 2026-11-02. Текущий workflow намеренно не переключается молча на macos-latest. После отключения нужен отдельно проверенный перенос рецепта на новый Xcode/runner; установка одной YAML-строки не гарантирует совместимость старого XNU. Если runner уже недоступен, нужен другой macOS runner и адаптация toolchain.

## Стоимость и секреты

Workflow не использует GitHub/Apple токены или платный larger runner. Стандартные hosted runners для публичных repositories по текущим условиям GitHub бесплатны; приватные repositories расходуют квоты и могут тарифицироваться. Хранение artifacts/другие лимиты проверяются в вашем аккаунте. Никаких платных ресурсов автоматически не заказывается.

SDK/KDK и fakeroot не загружаются как artifacts и не коммитятся. Сохраняются только перечисленные журналы и, при успехе, ядро. Не добавляйте в этот workflow сырые captures телефона.

## Чего workflow не исправляет

Полный XNU/IOKit ещё не скомпилирован и не проверен на Redmi9A. Есть незавершённые PRNG/entropy, platform integration, RAM ownership, MMU/cache handoff, watchdog, storage/display/userland. Workflow нужен, чтобы получить реальные build errors и двигаться дальше, а не как доказательство готовой iOS.
