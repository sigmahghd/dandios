#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Minimal diagnostic ADT builder, NOT an iOS/userland device tree or memory allocator.
CLI writes SYNTHETIC-ONLY fixture exclusively. No hardware-ready mode yet.
"""
import argparse,struct,json
from pathlib import Path

def u32(*v):return struct.pack('<'+'I'*len(v),*v)
def u64(*v):return struct.pack('<'+'Q'*len(v),*v)
def cstr(v):return v.encode('ascii')+b'\0'
def node(name,props=(),children=()):return {'name':name,'props':[('name',cstr(name)),*props],'children':list(children)}
def serialize(n):
 names=[k for k,v in n['props']]
 if len(names)!=len(set(names)):raise ValueError('duplicate property')
 out=bytearray(u32(len(n['props']),len(n['children'])))
 for key,value in n['props']:
  raw=key.encode('ascii')
  if not 1<=len(raw)<=31 or b'\0' in raw:raise ValueError('property name')
  out+=raw.ljust(32,b'\0')+u32(len(value))+value+b'\0'*(-len(value)%4)
 for child in n['children']:out+=serialize(child)
 return bytes(out)
def build(ram_base,ram_size,seed,*,diagnostic_fbcon=False):
 # API does NOT approve this window; payload policy must independently validate it.
 if ram_base%4096 or ram_size%4096 or ram_size<16384 or ram_base<0x40000000 or ram_base+ram_size>0xc0000000:raise ValueError('invalid XNU window')
 if not isinstance(seed,bytes) or len(seed)!=64:raise ValueError('64-byte seed required; fixed test seed is not boot entropy')
 chosen=node('chosen',[('dram-base',u64(ram_base)),('dram-size',u64(ram_size)),('random-seed',seed),('firmware-version',cstr('dandelion-diagnostic')),('system-firmware-version',cstr('dandelion-diagnostic'))],[node('memory-map')])
 cpu=node('cpu0',[('device_type',cstr('cpu')),('compatible',cstr('arm,cortex-a53')+cstr('ARM,v8')),('reg',u32(0)),('cpu-id',u32(0)),('cluster-id',u32(0)),('cluster-type',u32(0)),('die-cluster-id',u32(0)),('cluster-core-id',u32(0)),('l2-cache-id',u32(0)),('l3-cache-id',u32(0)),('state',cstr('running')),('timebase-frequency',u32(13000000)),('peripheral-frequency',u32(13000000)),('fixed-frequency',u32(13000000))])
 cpus=node('cpus',[('#address-cells',u32(1)),('#size-cells',u32(0))],[cpu])
 gic=node('gic',[('compatible',cstr('arm,gic-v3')),('interrupt-controller',b''),('virtual-timer-intid',u32(27)),('reg',u64(0,0x40000,0x100000,0x200000))])
 armio=node('arm-io',[('device_type',cstr('dandelion-io')),('compatible',cstr('mediatek,mt6765-io')+cstr('arm-io')),('#address-cells',u32(2)),('#size-cells',u32(2)),('ranges',u64(0,0x0c000000,0x00400000))],[gic])
 extra=[]
 if diagnostic_fbcon:
  # Descriptive only. Boot arg dandelion-fbcon=1 independently opts in.
  extra=[node('dandelion-fbcon',[('reg',u64(0x7ec50000,2944*1600,0x7f0ce000,2880*1600)),('width',u32(720)),('height',u32(1600)),('stride',u32(2944,2880))])]
 return node('device-tree',[('compatible',cstr('xiaomi,dandelion')+cstr('mediatek,mt6765')+cstr('ARM,v8')),('model',cstr('Redmi 9A diagnostic')),('manufacturer',cstr('Xiaomi')),('#address-cells',u32(2)),('#size-cells',u32(2))],[chosen,node('defaults'),cpus,armio,*extra])
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--synthetic-test',action='store_true',required=True);p.add_argument('--out',type=Path,default=Path('SYNTHETIC-ONLY-dandelion.adt'));a=p.parse_args()
 b=serialize(build(0x90000000,0x1000000,bytes(range(64))))
 with a.out.open('xb') as f:f.write(b)
 print('SYNTHETIC TEST ONLY, NOT FOR PHONE:',a.out,len(b))
