#!/usr/bin/env python3
# SPDX-License-Identifier: MIT. Runs ONLY on disposable GitHub-hosted macOS VM.
# Downloads pinned public KDK mirror, verifies digest and Apple package signature.
import hashlib,json,os,platform,subprocess,sys,urllib.request,plistlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def signature_is_apple(text):
 # An Apple-rooted Developer ID chain alone does NOT identify Apple as publisher.
 # Require trusted pkgutil validation (exit status checked by caller) AND an
 # Apple Software Update/Apple Inc installer leaf, never arbitrary Developer ID.
 leaf=next((s.strip() for s in text.splitlines() if s.strip().startswith('1. ')),'')
 return ('Software Update' in leaf or 'Developer ID Installer: Apple Inc.' in leaf or 'Apple Software' in leaf) and 'Apple Root' in text

def main():
 if platform.system()!='Darwin' or os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('RUNNER_ENVIRONMENT')!='github-hosted':raise ValueError('KDK installation allowed only on disposable GitHub-hosted macOS runner')
 lock=json.loads((R/'ci/kdk-lock.json').read_text());tmp=Path(os.environ['RUNNER_TEMP'])/'dandelion-kdk';tmp.mkdir(exist_ok=True)
 dmg=tmp/'KDK.dmg';h=hashlib.sha256();n=0
 with urllib.request.urlopen(lock['url'],timeout=120) as response,dmg.open('xb') as f:
  while b:=response.read(1048576):
   n+=len(b)
   if n>lock['bytes']:raise ValueError('KDK exceeds pinned size')
   h.update(b);f.write(b)
 if n!=lock['bytes'] or h.hexdigest()!=lock['sha256']:raise ValueError('KDK size/SHA256 mismatch')
 print('Verified pinned KDK size and SHA256',flush=True)
 mount=tmp/'mounted';mount.mkdir()
 subprocess.run(['/usr/bin/hdiutil','attach','-readonly','-nobrowse','-mountpoint',str(mount),str(dmg)],check=True)
 try:
  candidates=list(mount.glob('*.pkg'))
  if len(candidates)!=1:raise ValueError('expected one top-level KDK installer')
  pkg=candidates[0];p=subprocess.run(['/usr/sbin/pkgutil','--check-signature',str(pkg)],capture_output=True,text=True,check=True);print(p.stdout,flush=True)
  if not signature_is_apple(p.stdout):raise ValueError('installer publisher not recognized as Apple; STOP, do not bypass signature check')
  subprocess.run(['/usr/bin/sudo','/usr/sbin/installer','-pkg',str(pkg),'-target','/'],check=True)
 finally:subprocess.run(['/usr/bin/hdiutil','detach',str(mount)],check=True)
 expected=Path('/Library/Developer/KDKs/KDK_13.5_22G74.kdk')
 if not expected.is_dir():raise ValueError('expected KDK path missing after installer')
 with Path(os.environ['GITHUB_ENV']).open('a') as f:f.write('KDKROOT='+str(expected)+'\n')
 print('Installed exact KDK13.5/22G74; no phone access',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:print('STOP: '+str(e),file=sys.stderr);sys.exit(1)
