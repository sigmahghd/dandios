#!/usr/bin/env python3
# SPDX-License-Identifier: MIT. Build public source dependencies in a temporary CI workspace.
import hashlib,json,os,platform,re,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
WANTED=['running','info','error','warning','setup_xcode_toolchain','build_bootstrap_cmds','build_dtrace','build_availabilityversions','xnu_headers','libsystem_headers','libsyscall_headers','build_libplatform','build_libdispatch','ensure_hw_env_overrides']
def generate_recipe(text):
 blocks=[]
 for name in WANTED:
  m=re.search(r'^(?:function )?'+re.escape(name)+r'\(\) \{\n.*?^\}',text,re.M|re.S)
  if not m:raise ValueError('missing reviewed recipe function '+name)
  blocks.append(m.group(0))
 result='\n\n'.join(blocks)
 old='make installhdrs SDKROOT=macosx ARCH_CONFIGS="X86_64 ARM64"';new='make installhdrs SDKROOT=macosx TARGET_CONFIGS="$KERNEL_CONFIG $ARCH_CONFIG $MACHINE_CONFIG" ARCH_CONFIGS="ARM64"'
 if result.count(old)!=1:raise ValueError('unexpected XNU headers recipe')
 result=result.replace(old,new)
 # Plain ARM64 Dandelion cannot link an arm64e-only firehose archive.
 old='ARCHS="x86_64 arm64e" VALID_ARCHS="x86_64 arm64e"'
 if result.count(old)!=1:raise ValueError('unexpected firehose recipe')
 result=result.replace(old,'ARCHS="x86_64 arm64" VALID_ARCHS="x86_64 arm64"')
 return '#!/bin/bash\nset -euo pipefail\n'+result+'\n'
def main():
 if platform.system()!='Darwin' or os.environ.get('GITHUB_ACTIONS')!='true':raise ValueError('macOS CI required')
 text=(R/'ci/vendor/dxb-build.sh').read_text();expected=json.loads((R/'SOURCE_LOCK.json').read_text())['files']['dxb-build.sh']
 if hashlib.sha256(text.encode()).hexdigest()!=expected:raise ValueError('pinned dxb recipe mismatch')
 work=Path(os.environ['RUNNER_TEMP'])/'dandelion-deps'
 if work.exists():raise ValueError('refusing existing dependency workspace')
 work.mkdir();(work/'fakeroot').mkdir();(work/'build').mkdir();(work/'xnu').symlink_to(R/'work/xnu',target_is_directory=True)
 records=json.loads((R/'ci/dependencies-lock.json').read_text())
 for item in records:
  dest=work/item['project'];subprocess.run(['git','init','-q',str(dest)],check=True)
  subprocess.run(['git','-C',str(dest),'fetch','--depth=1',item['repository'],item['commit']],check=True)
  subprocess.run(['git','-C',str(dest),'checkout','-q','--detach','FETCH_HEAD'],check=True)
  head=subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD'],text=True).strip()
  if head!=item['commit']:raise ValueError('dependency commit mismatch')
  print('Pinned',item['project'],head,flush=True)
 script=work/'dependencies.sh';body=generate_recipe(text)
 # The original source/get_xnu/patches/install_deps/choose_xnu/main functions
 # are deliberately NOT copied or called; no blanket patch replay or Homebrew.
 preamble='''
COL_RESET='' COL_RED='' COL_GREEN='' COL_BLUE='' COL_MAGENTA='' COL_YELLOW=''
KERNEL_CONFIG=DEVELOPMENT ARCH_CONFIG=ARM64 MACHINE_CONFIG=DANDELION MACOS_VERSION=13.5
WORK_DIR="$PWD"; BUILD_DIR="$WORK_DIR/build"; FAKEROOT_DIR="$WORK_DIR/fakeroot"; DSTROOT="$FAKEROOT_DIR"
HAVE_WE_INSTALLED_HEADERS_YET="$FAKEROOT_DIR/.xnu_headers_installed"
TIGHTBEAMC=tightbeamc-not-supported RC_DARWIN_KERNEL_VERSION=22.6.0
MEMORY_SIZE_OVERRIDE='' PHYS_CPU_OVERRIDE='' LOGICAL_CPU_OVERRIDE='' KERNEL_PARALLELISM_OVERRIDE=''
'''
 body+='\n'+preamble+'\nRELEASE_URL='+repr((R/'ci/vendor/macos-135-release.json').as_uri())+'\n'
 body+='''
setup_xcode_toolchain
build_bootstrap_cmds
build_dtrace
build_availabilityversions
xnu_headers
libsystem_headers
libsyscall_headers
build_libplatform
build_libdispatch
'''
 script.write_text(body);subprocess.run(['/bin/bash','-n',str(script)],check=True);subprocess.run(['/bin/bash',str(script)],cwd=work,check=True)
 with Path(os.environ['GITHUB_ENV']).open('a') as f:f.write('FAKEROOT_DIR='+str(work/'fakeroot')+'\n')
if __name__=='__main__':
 try:main()
 except Exception as e:print('STOP: '+str(e),file=sys.stderr);sys.exit(1)
