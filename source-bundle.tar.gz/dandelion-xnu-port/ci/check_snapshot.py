#!/usr/bin/env python3
# SPDX-License-Identifier: MIT. Verify source tree before any privileged CI action.
from pathlib import Path
import sys,json,hashlib,shutil
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'build_support'))
from build_kernel_macos import verify_tree
m=json.loads((R/'SOURCE_TREE_SHA256.json').read_text());errors=verify_tree(R/'work/xnu',m)
lock=json.loads((R/'SOURCE_LOCK.json').read_text())['files']
for name in ['dxb-build.sh','macos-135-release.json']:
 if hashlib.sha256((R/'ci/vendor'/name).read_bytes()).hexdigest()!=lock[name]:errors.append('vendor snapshot mismatch: '+name)
if errors:raise SystemExit('\n'.join(errors[:30]))
free=shutil.disk_usage(R).free
if free<8*1024**3:raise SystemExit('STOP: less than 8GiB available; no dependency download started')
print('PASS public source snapshot:',len(m),'files; pinned recipe/release verified. Free GiB:',round(free/1024**3,1))
