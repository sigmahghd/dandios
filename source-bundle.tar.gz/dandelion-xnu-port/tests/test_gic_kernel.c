/* Test actual pe_fiq.c with mocked XNU APIs and RAM-backed GIC registers.
 * NOT real GIC semantics, CPU system registers, MMIO or kernel execution. */
#include "gic-mocks/mock_kernel.h"
static uint8_t *dist,*redist,properties[33];
static uint32_t timer=27;
static uint64_t sre=0,group1=0,bpr1=~0ULL,pmr=0;
static int scenario,maps;
static jmp_buf fail_env;
static char failure[256];
uint64_t mock_rsr(const char *s){
 if(!strcmp(s,"MPIDR_EL1"))return 0x80000000;
 if(!strcmp(s,"ICC_SRE_EL1"))return scenario==5?0:sre;
 return 0;
}
void mock_wsr(const char *s,uint64_t v){
 if(!strcmp(s,"ICC_SRE_EL1"))sre=v;
 if(!strcmp(s,"ICC_IGRPEN1_EL1"))group1=v;
 if(!strcmp(s,"ICC_BPR1_EL1"))bpr1=v;
 if(!strcmp(s,"ICC_PMR_EL1"))pmr=v;
}
_Noreturn void panic(const char *fmt,...){va_list ap;va_start(ap,fmt);vsnprintf(failure,sizeof failure,fmt,ap);va_end(ap);longjmp(fail_env,1);}
int SecureDTLookupEntry(void *unused,const char *path,DTEntry *e){(void)unused;if(strcmp(path,"/arm-io/gic"))return -1;*e=1;return 0;}
int SecureDTGetProperty(DTEntry e,const char *name,const void **p,unsigned *n){(void)e;
 if(!strcmp(name,"reg")){*p=properties+1;*n=32;return 0;}
 if(!strcmp(name,"virtual-timer-intid")){*p=&timer;*n=4;return 0;}
 return -1;
}
vm_offset_t pe_arm_get_soc_base_phys(void){return 0x0c000000;}
vm_offset_t ml_io_map(uint64_t base,uint64_t size){maps++;
 if(base==0x0c000000&&size==0x40000)return (uintptr_t)dist;
 if(base==0x0c100000&&size==0x200000)return (uintptr_t)redist;
 return 0;
}
unsigned ml_get_cpu_number(unsigned id){(void)id;return 0;}
unsigned ml_get_cpu_number_local(void){return 0;}
void nanoseconds_to_deadline(uint64_t n,uint64_t *d){*d=n;}
uint64_t mach_absolute_time(void){return 0;}
#include "../work/xnu/pexpert/arm/pe_fiq.c"
static void put64(uint8_t *p,uint64_t v){for(unsigned i=0;i<8;i++)p[i]=(uint8_t)(v>>(8*i));}
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(int argc,char **argv){
 if(argc!=2)return 2;scenario=atoi(argv[1]);dist=calloc(1,0x40000);redist=calloc(1,0x200000);REQUIRE(dist&&redist);
 put64(properties+1,0);put64(properties+9,0x40000);put64(properties+17,0x100000);put64(properties+25,0x200000);
 *(uint32_t *)dist=0x10;
 uint64_t off=scenario==1?0x20000:0;
 if(scenario==1)put64(redist+8,1ULL<<32);
 put64(redist+off+8,0x10);*(uint32_t *)(redist+off+0x10080)=1U<<20;
 memset(redist+off+0x10400,0x55,32);
 if(scenario==2)put64(properties+9,0x1000); /* reject prior to mapping */
 if(scenario==3)timer=19;
 if(scenario==4)put64(redist+8,(1ULL<<32)|0x10);
 if(scenario==6)*(uint32_t *)(redist+0x14)=6; /* stuck wake; fake time frozen */
 if(scenario==7)*(uint32_t *)dist=0x80000010; /* RWP never clears */
 if(scenario==8)*(uint32_t *)dist=0; /* no unsafe ARE transition */
 if(scenario==9)*(uint32_t *)(redist+0x14)=2; /* PS=1 but CA=0 */
 int panicked=setjmp(fail_env);
 if(!panicked)pe_init_fiq();
 if(scenario>=2&&scenario<=8){
  REQUIRE(panicked);
  if(scenario==2||scenario==3)REQUIRE(maps==0);
  printf("PASS case%d rejected: %s\n",scenario,failure);
 }else{
  REQUIRE(!panicked);REQUIRE(group1==1&&bpr1==0&&pmr==0xff);
  REQUIRE(*(uint32_t *)(redist+off+0x10080)==((1U<<20)|(1U<<27)|2));
  REQUIRE(*(uint32_t *)(redist+off+0x10100)==((1U<<27)|2));
  for(unsigned i=0;i<32;i++)REQUIRE(redist[off+0x10400+i]==((i==1||i==27)?0xa0:0x55));
  if(scenario==9)REQUIRE(*(uint32_t *)(redist+0x14)==0);
  printf("PASS case%d initialized RAM model; unrelated priority/group bits preserved\n",scenario);
 }
 free(dist);free(redist);return 0;
}
