/* SPDX-License-Identifier: MIT. Tests actual staged portable sources; no fake crypto. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "bearssl_block.h"
#include "bearssl_hash.h"
static unsigned nib(char c){return c<='9'?(unsigned)(c-'0'):(unsigned)(c-'a'+10);}
static size_t unhex(const char *s,void *v){uint8_t *p=v;size_t n=strlen(s)/2;for(size_t i=0;i<n;i++)p[i]=(uint8_t)((nib(s[2*i])<<4)|nib(s[2*i+1]));return n;}
static void equals(const void *data,const char *s){uint8_t expected[128];size_t n=unhex(s,expected);assert(!memcmp(data,expected,n));}
static void aes(const char *key,const char *expected){
 uint8_t k[32],iv[16],buf[32];size_t n=unhex(key,k);br_aes_ct_cbcenc_keys en;br_aes_ct_cbcdec_keys de;
 const char *plain="6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e51";
 unhex(plain,buf);unhex("000102030405060708090a0b0c0d0e0f",iv);br_aes_ct_cbcenc_init(&en,k,n);br_aes_ct_cbcenc_run(&en,iv,buf,32);equals(buf,expected);
 unhex("000102030405060708090a0b0c0d0e0f",iv);br_aes_ct_cbcdec_init(&de,k,n);br_aes_ct_cbcdec_run(&de,iv,buf,32);equals(buf,plain);
 /* Incremental CBC must chain to the same ciphertext, not restart each block. */
 unhex(plain,buf);unhex("000102030405060708090a0b0c0d0e0f",iv);br_aes_ct_cbcenc_run(&en,iv,buf,16);br_aes_ct_cbcenc_run(&en,iv,buf+16,16);equals(buf,expected);
}
static void hashes(const char *msg,const char *md5,const char *sha1,const char *sha384,const char *sha512){
 br_md5_context a;br_sha1_context b;br_sha384_context c;br_sha512_context d;uint8_t out[64];size_t n=strlen(msg);
 br_md5_init(&a);br_sha1_init(&b);br_sha384_init(&c);br_sha512_init(&d);
 for(size_t i=0;i<n;i++){br_md5_update(&a,msg+i,1);br_sha1_update(&b,msg+i,1);br_sha384_update(&c,msg+i,1);br_sha512_update(&d,msg+i,1);}
 br_md5_out(&a,out);equals(out,md5);br_sha1_out(&b,out);equals(out,sha1);br_sha384_out(&c,out);equals(out,sha384);br_sha512_out(&d,out);equals(out,sha512);
}
int main(void){
 aes("2b7e151628aed2a6abf7158809cf4f3c","7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b2");
 aes("8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b","4f021db243bc633d7178183a9fa071e8b4d9ada9ad7dedf4e5e738763f69145a");
 aes("603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4","f58c4c04d6e5f1ba779eabfb5f7bfbd69cfc4e967edb808d679f777bc6702c7d");
 hashes("","d41d8cd98f00b204e9800998ecf8427e","da39a3ee5e6b4b0d3255bfef95601890afd80709","38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b","cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e");
 hashes("abc","900150983cd24fb0d6963f7d28e17f72","a9993e364706816aba3e25717850c26c9cd0d89d","cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed8086072ba1e7cc2358baeca134c825a7","ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f");
 puts("PASS staged BearSSL: NIST SP800-38A AES-CBC128/192/256 encrypt/decrypt/chunking; MD5/SHA1/SHA384/SHA512 empty and abc");return 0;
}
