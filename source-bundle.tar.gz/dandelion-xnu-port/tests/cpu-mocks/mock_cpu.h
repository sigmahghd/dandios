#ifndef DANDELION_CPU_MOCK_H
#define DANDELION_CPU_MOCK_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <setjmp.h>
#include "../../work/xnu/pexpert/pexpert/arm64/DANDELION.h"
#define APPLE_KEXT_OVERRIDE override
#define OSDeclareDefaultStructors(c) public: c()=default; virtual ~c()=default; private:
#define OSDefineMetaClassAndStructors(c,b)
#define OSDynamicCast(c,o) dynamic_cast<c *>(o)
#define OSSafeReleaseNULL(o) do{if(o){(o)->release();(o)=NULL;}}while(0)
#define __builtin_arm_dsb(x) ((void)0)
#define __builtin_arm_isb(x) ((void)0)
#define __builtin_arm_wsr64(n,v) mock_sysreg_write(n,v)
#define DSB_ISHST 0
#define ISB_SY 0
#define NSEC_PER_SEC 1000000000ULL
#define CPU_BOOTED 1
#define kIOCPUStateRunning 1
#define KERN_SUCCESS 0
#define KERN_NOT_SUPPORTED 46
using kern_return_t=int;using vm_offset_t=uintptr_t;using cpu_id_t=uintptr_t;using boolean_t=int;
using thread_t=void *;using wait_result_t=int;using perfmon_interrupt_handler_func=void(*)();
class OSObject {public:virtual ~OSObject()=default;virtual void release() const {}};
class OSNumber:public OSObject {public:uint32_t value=0;uint32_t unsigned32BitValue(){return value;}};
class OSData:public OSObject {public:uint8_t data[4]={};unsigned length=4;unsigned getLength(){return length;}void *getBytesNoCopy(){return data;}};
extern int scenario,base_started,registered,published,sleeps,completed,terminated,maxcpus;
extern void *kOSBooleanTrue;extern const char *gIOAllCPUInitializedKey;
class OSSymbol:public OSObject {public:const char *text;static const OSSymbol *withCStringNoCopy(const char *t){static OSSymbol s;if(scenario==4)return NULL;s.text=t;return &s;}};
class IOService:public OSObject {public:OSNumber logical;OSData reg;
 virtual bool start(IOService *){return true;}
 virtual void free(){}
 virtual OSObject *getProperty(const char *name){if(!strcmp(name,"logical-cpu-id"))return &logical;if(!strcmp(name,"reg"))return &reg;return NULL;}
 void registerService(){registered++;}
 static void publishResource(const char *,void *){published++;}
};
class IOCPU:public IOService {unsigned number=0;public:void *machProcessor=NULL,*ipi_handler=NULL;
 bool start(IOService *) override {base_started++;return scenario!=3;}
 virtual void initCPU(bool){} virtual void signalCPU(IOCPU *){}
 virtual kern_return_t startCPU(vm_offset_t,vm_offset_t){return 0;}
 virtual void quiesceCPU(){}virtual void haltCPU(){}
 virtual const OSSymbol *getCPUName(){return NULL;}
 void setCPUNumber(unsigned n){number=n;}unsigned getCPUNumber(){return number;}
 void setCPUState(unsigned){} void cpusRunning(){}
};
struct ml_topology_cpu_t {unsigned phys_id=0,cpu_id=0,cluster_id=0,cluster_type=0,l2_cache_id=0,l3_cache_id=0;uint64_t l2_cache_size=0,l3_cache_size=0;};
struct ml_topology_info_t {unsigned num_cpus=1,max_cpu_id=0;ml_topology_cpu_t cpus[2];const ml_topology_cpu_t *boot_cpu=NULL;};
struct ml_processor_info_t {cpu_id_t cpu_id;unsigned phys_id,log_id,cluster_id,cluster_type,l2_cache_id;uint64_t l2_cache_size;unsigned l3_cache_id;uint64_t l3_cache_size;};
const ml_topology_info_t *ml_get_topology_info();
kern_return_t ml_processor_register(ml_processor_info_t *,void **,void **,perfmon_interrupt_handler_func *);
kern_return_t kernel_thread_start(void(*)(void *,wait_result_t),void *,thread_t *);
void thread_deallocate(thread_t);kern_return_t processor_start(void *);
void nanoseconds_to_deadline(uint64_t,uint64_t *);uint64_t mach_absolute_time();void IOSleep(unsigned);
void ml_cpu_init_completed();void ml_set_max_cpus(unsigned);void thread_terminate(thread_t);thread_t current_thread();
void ml_broadcast_cpu_event(unsigned,unsigned);int cpu_number();void IOLog(const char *,...);
[[noreturn]] void panic(const char *,...);void mock_sysreg_write(const char *,uint64_t);
#endif
