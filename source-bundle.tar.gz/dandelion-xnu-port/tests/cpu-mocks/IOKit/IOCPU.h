/* TEST-ONLY shim. Not real IOKit/SDK headers. */
