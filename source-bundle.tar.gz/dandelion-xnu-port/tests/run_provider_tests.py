#!/usr/bin/env python3
# SPDX-License-Identifier: MIT. Actual staged portable sources, NOT full kernel SDK build.
from pathlib import Path
import subprocess,os,json
R=Path(__file__).resolve().parents[1];W=R/'work/xnu';B=W/'libkern/crypto/sweet_bearssl'
names=['sweet_'+n for n in ['aes_ct','aes_ct_enc','aes_ct_dec','aes_ct_cbcenc','aes_ct_cbcdec','md5','dec32le','enc32le','sha1','dec32be','enc32be','sha2big','dec64be','enc64be']]
sources=[W/'libkern/crypto'/str(n+'.c') for n in names]
subprocess.run(['gcc','-std=c11','-O2','-DARM64_BOARD_CONFIG_DANDELION','-I'+str(B/'inc'),'-I'+str(B/'src'),str(R/'tests/test_bearssl.c'),*[str(s) for s in sources],'-o',str(R/'tests/test-bearssl')],check=True)
p=subprocess.run([str(R/'tests/test-bearssl')],capture_output=True,text=True,check=True);(R/'tests/BEARSSL_RESULTS.txt').write_text(p.stdout)
zig=os.environ.get('ZIG','/data/dandelion-toolchain/ziglang/zig');objects=[]
for s in sources:
 out=R/'tests/crypto-arm64'/str(s.stem+'.o');out.parent.mkdir(exist_ok=True)
 subprocess.run([zig,'cc','-target','aarch64-freestanding-none','-mcpu=cortex_a53','-mgeneral-regs-only','-ffreestanding','-fno-builtin','-fno-stack-protector','-O2','-DARM64_BOARD_CONFIG_DANDELION','-I'+str(R/'tests/crypto-freestanding'),'-I'+str(B/'inc'),'-I'+str(B/'src'),'-c',str(s),'-o',str(out)],check=True);objects.append(str(out.relative_to(R)))
report={'host_vectors':p.stdout.strip(),'arm64_compile_only_objects':objects,'notes':'14 actual thin wrapper/BearSSL source TUs. Freestanding test string.h declarations, NOT XNU SDK build. Legacy ccmode/corecrypto adapters and libpthread have NOT been fully compiled/linked. No FIPS validation claimed.'}
(R/'tests/PROVIDER_RESULTS.json').write_text(json.dumps(report,indent=2));print(p.stdout.strip());print('PASS: 14 Cortex-A53 portable-provider objects (compile-only, NOT full kernel)')
