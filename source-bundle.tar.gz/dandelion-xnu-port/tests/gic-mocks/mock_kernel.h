#ifndef TEST_MOCK_KERNEL_H
#define TEST_MOCK_KERNEL_H
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include "../../work/xnu/pexpert/pexpert/arm64/DANDELION.h"
typedef uintptr_t vm_offset_t;
typedef int DTEntry;
#define kSuccess 0
#define MPIDR_AFF1_MASK 0xff00
#define MPIDR_AFF0_MASK 0xff
#define ISB_SY 15
#define MACHINE_TIMEOUT_UNIT_NSEC 0
#define MACHINE_TIMEOUT(name,desc,value,unit,cb) uint64_t name=value
#define os_atomic_load(p,order) (*(p))
#define kprintf(...) ((void)0)
#define __builtin_arm_rsr64(name) mock_rsr(name)
#define __builtin_arm_wsr64(name,v) mock_wsr(name,v)
#define __builtin_arm_isb(v) ((void)0)
uint64_t mock_rsr(const char *);
void mock_wsr(const char *,uint64_t);
_Noreturn void panic(const char *,...);
int SecureDTLookupEntry(void *,const char *,DTEntry *);
int SecureDTGetProperty(DTEntry,const char *,const void **,unsigned *);
vm_offset_t pe_arm_get_soc_base_phys(void);
vm_offset_t ml_io_map(uint64_t,uint64_t);
unsigned ml_get_cpu_number(unsigned);
unsigned ml_get_cpu_number_local(void);
void nanoseconds_to_deadline(uint64_t,uint64_t *);
uint64_t mach_absolute_time(void);
#endif
