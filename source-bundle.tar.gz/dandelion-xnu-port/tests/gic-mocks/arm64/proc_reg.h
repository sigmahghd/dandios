/* TEST-ONLY API shim. Not production XNU headers. */
