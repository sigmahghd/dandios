/* TEST/compile-only freestanding libc declarations, NOT production SDK headers. */
#ifndef D9_TEST_STRING_H
#define D9_TEST_STRING_H
#include <stddef.h>
void *memcpy(void *,const void *,size_t);
void *memmove(void *,const void *,size_t);
void *memset(void *,int,size_t);
int memcmp(const void *,const void *,size_t);
size_t strlen(const char *);
#endif
