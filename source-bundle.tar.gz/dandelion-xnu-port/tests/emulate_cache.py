# SPDX-License-Identifier: MIT. Cache effects/barriers are intercepted, NOT modeled coherence.
from pathlib import Path
import io,json
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE
import unicorn.arm64_const as A
R=Path(__file__).resolve().parents[1];BASE=0x60000000
elf=ELFFile(io.BytesIO((R/'tests/cache-arm64.elf').read_bytes()))
sym={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()};md=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
funcs={'CleanPoU_DcacheRegion':('cvau',False),'CleanPoC_DcacheRegion_internal':('cvac',False),'FlushPoC_DcacheRegion':('civac',False),'InvalidatePoU_IcacheRegion':('cvau',True)}
vectors=[(0x90000000,0),(0x90000000,1),(0x9000003f,1),(0x9000003f,2),(0x90000000,64),(0x90000001,64),(0x9000003f,255),(2**64-64,64),(2**64-1,1),(2**64-64,65)]
def run(name,addr,length):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000)
 for s in elf.iter_segments():
  if s['p_type']=='PT_LOAD' and s['p_filesz']:u.mem_write(BASE+s['p_vaddr'],s.data())
 u.reg_write(A.UC_ARM64_REG_X0,addr);u.reg_write(A.UC_ARM64_REG_X1,length);u.reg_write(A.UC_ARM64_REG_X30,BASE+0xf000)
 trace=[];done=[]
 def hook(uc,pc,size,data):
  if pc==BASE+0xf000:done.append('return');u.emu_stop();return
  ins=next(md.disasm(bytes(u.mem_read(pc,4)),pc))
  if ins.mnemonic in ['dc','ic']:
   op,reg=ins.op_str.split(', ');trace.append((ins.mnemonic,op,u.reg_read(getattr(A,'UC_ARM64_REG_'+reg.upper()))));u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif ins.mnemonic in ['dsb','isb']:
   trace.append((ins.mnemonic,ins.op_str));u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif ins.mnemonic=='brk':done.append('reject');u.emu_stop()
 def forbidden(*args):raise AssertionError('cache routine dereferenced RAM')
 u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,forbidden)
 u.emu_start(BASE+sym[name],0,count=10000);assert len(done)==1
 reject=length>0 and addr+length-1>=2**64
 if reject:assert done==['reject'] and not trace
 else:
  assert done==['return'];lines=list(range(addr&~63,((addr+length-1)&~63)+1,64)) if length else []
  op,ic=funcs[name];assert [v for kind,o,*v in trace if kind=='dc']==[[p] for p in lines]
  assert all(o==op for kind,o,*v in trace if kind=='dc')
  assert [v for kind,o,*v in trace if kind=='ic']==([[p] for p in lines] if ic else [])
  assert all(o=='ivau' for kind,o,*v in trace if kind=='ic')
  if ic and lines:
   lastdc=max(i for i,t in enumerate(trace) if t[0]=='dc');firstic=min(i for i,t in enumerate(trace) if t[0]=='ic')
   assert any(t[0]=='dsb' for t in trace[lastdc+1:firstic]);assert any(t[0]=='isb' for t in trace)
 assert u.reg_read(A.UC_ARM64_REG_X0)==addr and u.reg_read(A.UC_ARM64_REG_X1)==length
 return {'function':name,'address':hex(addr),'length':length,'outcome':done[0],'cache_instructions':sum(t[0] in ['dc','ic'] for t in trace),'effects_intercepted':True}
report={'scope':'Actual extracted ARM64 leaf instructions; DC/IC/DSB/ISB intercepted, no hardware cache/MMU/coherence or XNU execution.','cases':[run(n,a,l) for n in funcs for a,l in vectors]}
(R/'tests/CACHE_ARM64_RESULTS.json').write_text(json.dumps(report,indent=2));print('PASS',len(report['cases']),'cache range control-flow/address cases; privileged effects intercepted')
