# SPDX-License-Identifier: MIT. Executes only loader C in synthetic RAM, NOT XNU.
from pathlib import Path
import sys,io,struct,json
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_WRITE
import unicorn.arm64_const as A
sys.path.insert(0,str(Path(__file__).parent))
from test_load import Tests,SIZE,BASE
R=Path(__file__).resolve().parents[1]
e=ELFFile(io.BytesIO((R/'tests/load-arm64.elf').read_bytes()))
sym={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
assert not [s.name for s in sym.values() if s.name and s['st_shndx']=='SHN_UNDEF']
def run(case):
 t=Tests();t.setUp();b=bytearray(t.b)
 if case=='bad_adt':b[4104]=0
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0x60000000,0x10000);u.mem_map(0x61000000,0x100000);u.mem_map(0x52000000,0x10000);u.mem_map(BASE,SIZE)
 for s in e.iter_segments():
  if s['p_type']=='PT_LOAD' and s['p_filesz']:u.mem_write(0x60000000+s['p_vaddr'],s.data())
 # Source deliberately unaligned; destination mapping in modeled physical window.
 u.mem_write(0x52000001,bytes(b));u.mem_write(BASE,b'\xa5'*SIZE);u.mem_write(0x61002000,b'\xa5'*24)
 u.mem_write(0x61001000,struct.pack('<8Q',0x40000000,0x80000000,BASE+4096 if case=='denied' else BASE,SIZE,0x52000001,len(b),0,0))
 args=[0x52000001,len(b),0x61001000,BASE,SIZE,0x61002000]
 for i,v in enumerate(args):u.reg_write(getattr(A,'UC_ARM64_REG_X'+str(i)),v)
 u.reg_write(A.UC_ARM64_REG_SP,0x610ff000);u.reg_write(A.UC_ARM64_REG_X30,0x6100f000)
 finished=[];writes=[0]
 def code(uc,pc,size,data):
  if pc==0x6100f000:finished.append(True);u.emu_stop()
  else:assert 0x60000000<=pc<0x60010000,hex(pc)
 def write(uc,access,addr,n,value,data):
  assert (BASE<=addr and addr+n<=BASE+SIZE) or (0x61002000<=addr and addr+n<=0x61002018) or (0x610f0000<=addr and addr+n<=0x61100000),hex(addr)
  if BASE<=addr<BASE+SIZE:writes[0]+=1
 u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_WRITE,write)
 u.emu_start(0x60000000+sym['dandelion_load']['st_value'],0,count=4000000);assert finished
 rc=u.reg_read(A.UC_ARM64_REG_X0);expected={'valid':0,'bad_adt':104,'denied':3}[case];assert rc==expected,(case,rc)
 d=bytes(u.mem_read(BASE,SIZE));out=bytes(u.mem_read(0x61002000,24))
 if rc:assert d==b'\xa5'*SIZE and out==b'\xa5'*24 and writes[0]==0
 else:
  assert d[:37]==bytes(range(37)) and d[37:512]==bytes(475)
  assert d[4096:4105]==b'DANDELION' and d[4105:4607]==bytes(502)
  assert d[8192:8192+len(t.tree)]==t.tree
  entry,ba,top=struct.unpack('<3Q',out);assert entry==BASE+4 and top==ba+4096
  assert d[ba-BASE:ba-BASE+4]==b'\x02\x00\x02\x00'
 assert bytes(u.mem_read(0x52000001,len(b)))==bytes(b)
 return {'case':case,'result':rc,'destination_write_instructions':writes[0],'kernel_executed':False,'privileged_instructions':False}
report={'scope':'Actual freestanding ARM64 loader instructions, synthetic mapped RAM and test data, no XNU execution or phone write.','cases':[run(c) for c in ['valid','bad_adt','denied']]}
(R/'tests/LOAD_ARM64_RESULTS.json').write_text(json.dumps(report,indent=2));print('PASS 3 ARM64 load/copy/rejection cases; NO XNU execution')
