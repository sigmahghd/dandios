/* SPDX-License-Identifier: MIT. RAM-backed integration of actual driver header.
 * XNU API mapping/ADT/barrier are TEST DOUBLES; no real scanout or kernel boot. */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define SECURITY_READ_ONLY_LATE(x) x
#define SERIAL_DANDELION_FBCON 0x40
#define DSB_SY 0
static unsigned barriers;
#define __builtin_arm_dsb(x) ((void)(x),barriers++)
typedef void *DTEntry;
#define kSuccess 0
struct pe_serial_functions {void (*init)(void);unsigned (*transmit_ready)(void);void (*transmit_data)(uint8_t);unsigned (*receive_ready)(void);uint8_t (*receive_data)(void);unsigned device;};
unsigned char iso_font[256*16];
static unsigned maps,registrations;static int enabled=1,missing,badprop,map_failure;
static uint8_t reg_raw[33],width_raw[5],height_raw[5],stride_raw[9];
static uint8_t *buffers[2];static size_t lengths[2]={2944*1600,2880*1600};
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static void put64(uint8_t *p,uint64_t v){for(unsigned i=0;i<8;i++)p[i]=(uint8_t)(v>>(i*8));}
static int PE_parse_boot_argn(const char *s,void *v,size_t n){assert(!strcmp(s,"dandelion-fbcon")&&n==sizeof(int));*(int *)v=enabled;return enabled!=-1;}
static int SecureDTFindEntry(const char *key,const char *value,DTEntry *e){assert(!strcmp(key,"name")&&!strcmp(value,"dandelion-fbcon"));*e=(void *)1;return missing?1:0;}
static int SecureDTGetProperty(DTEntry e,const char *key,const void **v,unsigned *n){
 assert(e==(void *)1);
 if(!strcmp(key,"reg")){*v=reg_raw+1;*n=badprop==1?31:32;}
 else if(!strcmp(key,"width")){*v=width_raw+1;*n=4;}
 else if(!strcmp(key,"height")){*v=height_raw+1;*n=4;}
 else if(!strcmp(key,"stride")){*v=stride_raw+1;*n=8;}
 else {abort();}
 return 0;
}
static uintptr_t ml_io_map_wcomb(uint64_t pa,uint64_t n){unsigned i=maps++;assert(i<2);assert(pa==(i?0x7f0ce000ULL:0x7ec50000ULL));assert(n==lengths[i]);return map_failure==(int)i+1?0:(uintptr_t)(buffers[i]+64);}
static void register_serial_functions(struct pe_serial_functions *f){assert(f->device==0x40);registrations++;}
#include "../platform/dandelion_fbcon.h"
static void guards(void){
 for(unsigned i=0;i<2;i++){
  for(unsigned j=0;j<64;j++){assert(buffers[i][j]==0xa5);assert(buffers[i][64+lengths[i]+j]==0xa5);}
  for(unsigned y=0;y<1600;y++)for(unsigned x=720*4;x<(i?2880u:2944u);x++)assert(buffers[i][64+y*(i?2880:2944)+x]==0xa5);
 }
}
int main(int argc,char **argv){
 assert(argc==2);const char *c=argv[1];
 for(unsigned i=0;i<2;i++){buffers[i]=malloc(lengths[i]+128);assert(buffers[i]);memset(buffers[i],0xa5,lengths[i]+128);}
 put64(reg_raw+1,0x7ec50000);put64(reg_raw+9,lengths[0]);put64(reg_raw+17,0x7f0ce000);put64(reg_raw+25,lengths[1]);put32(width_raw+1,720);put32(height_raw+1,1600);put32(stride_raw+1,2944);put32(stride_raw+5,2880);
 if(!strcmp(c,"disabled"))enabled=0;
 else if(!strcmp(c,"absent_arg"))enabled=-1;
 else if(!strcmp(c,"wrong_arg"))enabled=2;
 else if(!strcmp(c,"missing_node"))missing=1;
 else if(!strcmp(c,"short_reg"))badprop=1;
 else if(!strcmp(c,"bad_pa"))reg_raw[1]^=1;
 else if(!strcmp(c,"bad_size"))reg_raw[9]^=1;
 else if(!strcmp(c,"bad_width"))put32(width_raw+1,0xffffffffu);
 else if(!strcmp(c,"bad_height"))put32(height_raw+1,0xffffffffu);
 else if(!strcmp(c,"bad_pitch"))put32(stride_raw+5,2944);
 else if(!strcmp(c,"map1_failure"))map_failure=1;
 else if(!strcmp(c,"map2_failure"))map_failure=2;
 else assert(!strcmp(c,"success"));
 dandelion_fbcon_probe();
 if(strcmp(c,"success")){
  assert(registrations==0&&barriers==0);
  assert(maps==(map_failure?(unsigned)map_failure:0));
  for(unsigned i=0;i<2;i++)for(size_t j=0;j<lengths[i]+128;j++)assert(buffers[i][j]==0xa5);
 }else{
  assert(maps==2&&registrations==1);dandelion_fbcon_probe();assert(maps==2&&registrations==1);
  assert(d9fb_tx_ready()==1&&d9fb_rx_ready()==0&&d9fb_rx()==0);
  d9fb_init();memset(iso_font+'A'*16,0xff,16);d9fb_tx('A');
  for(unsigned i=0;i<2;i++)assert(*(uint32_t *)(buffers[i]+64)==0xffffffffu);
  for(unsigned i=0;i<256;i++)d9fb_tx((uint8_t)i);
  for(unsigned i=0;i<46*52;i++)d9fb_tx('A');
  assert(d9fb_col<=45&&d9fb_row<50);guards();
 }
 for(unsigned i=0;i<2;i++){free(buffers[i]);}
 puts(c);return 0;
}
