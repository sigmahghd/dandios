/* Actual DandelionCPU.cpp with modeled IOKit/kernel API; NOT real kernel/IRQ execution. */
#include "cpu-mocks/mock_cpu.h"
int scenario,base_started,registered,published,sleeps,completed,terminated,maxcpus;
void *kOSBooleanTrue=(void *)1;const char *gIOAllCPUInitializedKey="AllCPUInitialized";
static ml_topology_info_t topo;static void(*startup)(void *,wait_result_t);static void *startup_arg;
static uint64_t sgi;static char failure[256];static jmp_buf fail_env;
const ml_topology_info_t *ml_get_topology_info(){return &topo;}
kern_return_t ml_processor_register(ml_processor_info_t *i,void **m,void **ipi,perfmon_interrupt_handler_func *p){*m=(void *)i->cpu_id;*ipi=NULL;*p=NULL;return scenario==5?-1:0;}
kern_return_t kernel_thread_start(void(*fn)(void *,wait_result_t),void *arg,thread_t *t){startup=fn;startup_arg=arg;*t=(void *)1;return scenario==6?-1:0;}
void thread_deallocate(thread_t){}void nanoseconds_to_deadline(uint64_t n,uint64_t *d){*d=n;}
uint64_t mach_absolute_time(){return 0;}void IOSleep(unsigned){sleeps++;}
void ml_cpu_init_completed(){completed++;}void ml_set_max_cpus(unsigned n){maxcpus=n;}
void thread_terminate(thread_t){terminated++;}thread_t current_thread(){return (void *)1;}
void ml_broadcast_cpu_event(unsigned,unsigned){}int cpu_number(){return 0;}void IOLog(const char *,...){}
[[noreturn]] void panic(const char *fmt,...){va_list ap;va_start(ap,fmt);vsnprintf(failure,sizeof failure,fmt,ap);va_end(ap);longjmp(fail_env,1);}
void mock_sysreg_write(const char *name,uint64_t value){if(!strcmp(name,"ICC_SGI1R_EL1"))sgi=value;}
extern "C" boolean_t dandelion_cpu_signal_is_enabled(unsigned c){return c==0&&sgi!=0&&scenario!=7;}
#include "../work/xnu/iokit/Kernel/arm/DandelionCPU.cpp"
kern_return_t processor_start(void *p){((DandelionCPU *)p)->initCPU(true);return 0;}
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(int argc,char **argv){
 if(argc!=2)return 2;scenario=atoi(argv[1]);topo.boot_cpu=&topo.cpus[0];
 IOService provider;DandelionCPU driver;volatile bool started=false;
 if(scenario==1)topo.num_cpus=2;
 if(scenario==2)provider.reg.data[0]=1;
 int panicked=setjmp(fail_env);
 if(!panicked){
  started=driver.start(&provider);
  if(started&&startup)startup(startup_arg,0);
 }
 if(scenario==0){REQUIRE(!panicked&&started);REQUIRE(sgi==((1ULL<<24)|1));REQUIRE(completed==1&&published==1&&maxcpus==1&&terminated==1);REQUIRE(driver.startCPU(0,0)==KERN_NOT_SUPPORTED);}
 else if(scenario>=1&&scenario<=4){REQUIRE(!panicked&&!started);REQUIRE(!published);}
 else if(scenario>=5&&scenario<=7){REQUIRE(panicked);REQUIRE(!published&&!completed);if(scenario==7)REQUIRE(sleeps==5000);}
 printf("PASS CPU case%d%s%s\n",scenario,panicked?" panic: ":"",panicked?failure:"");return 0;
}
