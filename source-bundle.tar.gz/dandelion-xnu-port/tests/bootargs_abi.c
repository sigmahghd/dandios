/* Test extracts actual upstream ABI declarations; unrelated includes omitted. */
#include <stdint.h>
#include <stddef.h>
#define BOOT_LINE_LENGTH 608
struct Boot_Video {
	unsigned long   v_baseAddr;     /* Base address of video memory */
	unsigned long   v_display;      /* Display Code (if Applicable */
	unsigned long   v_rowBytes;     /* Number of bytes per pixel row */
	unsigned long   v_width;        /* Width */
	unsigned long   v_height;       /* Height */
	unsigned long   v_depth;        /* Pixel Depth and other parameters */
};
typedef struct Boot_Video Boot_Video;
typedef struct boot_args {
	uint16_t                Revision;                       /* Revision of boot_args structure */
	uint16_t                Version;                        /* Version of boot_args structure */
	uint64_t                virtBase;                       /* Virtual base of memory */
	uint64_t                physBase;                       /* Physical base of memory */
	uint64_t                memSize;                        /* Size of memory */
	uint64_t                topOfKernelData;        /* Highest physical address used in kernel data area */
	Boot_Video              Video;                          /* Video Information */
	uint32_t                machineType;            /* Machine Type */
	void                    *deviceTreeP;           /* Base of flattened device tree */
	uint32_t                deviceTreeLength;       /* Length of flattened tree */
	char                    CommandLine[BOOT_LINE_LENGTH];  /* Passed in command line */
	uint64_t                bootFlags;              /* Additional flags specified by the bootloader */
	uint64_t                memSizeActual;          /* Actual size of memory */
} boot_args;
_Static_assert(sizeof(void*)==8,"ARM64 pointer");
_Static_assert(sizeof(boot_args)==736,"boot_args size");
_Static_assert(offsetof(boot_args,virtBase)==8,"virtBase");
_Static_assert(offsetof(boot_args,Video)==40,"Video");
_Static_assert(offsetof(boot_args,deviceTreeP)==96,"deviceTreeP");
_Static_assert(offsetof(boot_args,CommandLine)==108,"CommandLine");
_Static_assert(offsetof(boot_args,bootFlags)==720,"bootFlags");
_Static_assert(offsetof(boot_args,memSizeActual)==728,"memSizeActual");
