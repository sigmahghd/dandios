# SPDX-License-Identifier: MIT. Local static/unit checks, NOT a hosted CI run.
from pathlib import Path
import sys,json,re,unittest,tempfile,subprocess,hashlib
import yaml
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'ci'))
from install_kdk import signature_is_apple
from prepare_dependencies import generate_recipe,WANTED
class Tests(unittest.TestCase):
 def setUp(self):self.w=yaml.safe_load((R/'.github/workflows/dandelion-xnu.yml').read_text())
 def test_manual_trigger_only(self):self.assertEqual(set(self.w['on']),{'workflow_dispatch'})
 def test_permissions(self):self.assertEqual(self.w['permissions'],{'contents':'read'})
 def test_runner_pinned_and_bounded(self):
  j=self.w['jobs']['xnu'];self.assertEqual(j['runs-on'],'macos-14');self.assertEqual(j['timeout-minutes'],180);self.assertIn('Xcode_15.4',j['env']['DEVELOPER_DIR'])
 def test_actions_commit_pins(self):
  locks=json.loads((R/'ci/actions-lock.json').read_text())
  for step in self.w['jobs']['xnu']['steps']:
   if 'uses' in step:
    name,sha=step['uses'].split('@');self.assertEqual(sha,locks[name.split('/')[1]]);self.assertRegex(sha,r'^[a-f0-9]{40}$')
 def test_no_credentials_persisted(self):
  s=next(s for s in self.w['jobs']['xnu']['steps'] if s.get('uses','').startswith('actions/checkout@'));self.assertFalse(s['with']['persist-credentials'])
 def test_upload_allowlist(self):
  for s in self.w['jobs']['xnu']['steps']:
   if s.get('uses','').startswith('actions/upload-artifact@'):
    self.assertEqual(s['with']['retention-days'],7)
    for line in s['with']['path'].splitlines():self.assertTrue(line.startswith(('ci-logs/','build/macos-dandelion/')))
    for forbidden in ['fakeroot','KDK','TargetConditionals','work/xnu','expdb','.img']:self.assertNotIn(forbidden,s['with']['path'])
 def test_logs_always(self):self.assertTrue(any(s.get('if')=='always()' and s.get('uses','').startswith('actions/upload-artifact@') for s in self.w['jobs']['xnu']['steps']))
 def test_kdk_lock(self):
  k=json.loads((R/'ci/kdk-lock.json').read_text());self.assertEqual(k['build'],'22G74');self.assertEqual(k['version'],'13.5');self.assertRegex(k['sha256'],r'^[0-9a-f]{64}$');self.assertTrue(k['url'].startswith('https://github.com/dortania/KdkSupportPkg/releases/download/22G74/'))
 def test_package_signer(self):
  self.assertTrue(signature_is_apple('Status: signed by a certificate trusted by macOS\n  1. Software Update\n  2. Apple Software Update Certification Authority\n  3. Apple Root CA'))
  self.assertFalse(signature_is_apple('1. Developer ID Installer: Somebody Else\n3. Apple Root CA'))
  self.assertFalse(signature_is_apple('1. Software Update\n3. Unknown Root CA'))
 def test_pinned_recipe_hash(self):
  b=(R/'ci/vendor/dxb-build.sh').read_bytes();self.assertEqual(hashlib.sha256(b).hexdigest(),json.loads((R/'SOURCE_LOCK.json').read_text())['files']['dxb-build.sh'])
 def test_reviewed_function_allowlist(self):
  recipe=generate_recipe((R/'ci/vendor/dxb-build.sh').read_text())
  names=re.findall(r'^(?:function )?(\w+)\(\) \{',recipe,re.M);self.assertEqual(names,WANTED)
  self.assertNotIn('ARCHS="x86_64 arm64e"',recipe)
  for name in ['install_deps','get_xnu','patches','choose_xnu','main']:
   self.assertNotRegex(recipe,r'(?m)^'+name+r'(?:\s|\()')
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'recipe.sh';p.write_text(recipe);subprocess.run(['/bin/bash','-n',str(p)],check=True)
 def test_shell_steps_syntax(self):
  with tempfile.TemporaryDirectory() as t:
   for i,s in enumerate(self.w['jobs']['xnu']['steps']):
    if 'run' in s:
     p=Path(t)/str(i);p.write_text(s['run']);subprocess.run(['/bin/bash','-n',str(p)],check=True)
 def test_dependency_commit_lock(self):
  records=json.loads((R/'ci/dependencies-lock.json').read_text());self.assertEqual(len(records),6)
  for i in records:self.assertRegex(i['commit'],r'^[0-9a-f]{40}$');self.assertTrue(i['repository'].startswith('https://github.com/apple-oss-distributions/'))
if __name__=='__main__':unittest.main()
