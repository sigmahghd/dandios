# SPDX-License-Identifier: MIT
import sys,unittest,struct,ctypes as C
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from mkadt_dandelion import build,serialize,node,u32
from test_load import lib,Policy,Range,VB
class Stats(C.Structure):_fields_=[('nodes',C.c_uint32),('properties',C.c_uint32),('max_depth',C.c_uint32)]
class Segment(C.Structure):_fields_=[('destination',C.c_uint64),('memory_size',C.c_uint64),('source_offset',C.c_uint64),('file_size',C.c_uint64)]
class Load(C.Structure):_fields_=[(n,C.c_uint64) for n in ['entry','adt_destination','adt_offset','adt_size','bootargs','top']]+[('segment_count',C.c_uint32),('segments',Segment*32)]
class Metadata(C.Structure):_fields_=[('load',Load),('tree',Stats),('bootargs',C.c_uint8*736)]
lib.adt_check.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Stats)]
lib.metadata_prepare.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.POINTER(Metadata)]
class Tests(unittest.TestCase):
 def test_structure(self):
  b=serialize(build(0x90000000,0x1000000,bytes(64)));s=Stats();buf=C.create_string_buffer(b)
  self.assertEqual(lib.adt_check(buf,len(b),C.byref(s)),0);self.assertEqual(s.nodes,8)
 def test_cpu_contract(self):
  n=build(0x90000000,0x1000000,bytes(64));cpus=next(c for c in n['children'] if c['name']=='cpus');self.assertEqual(len(cpus['children']),1);p=dict(cpus['children'][0]['props']);self.assertEqual(p['reg'],u32(0));self.assertEqual(p['state'],b'running\0');self.assertEqual(p['timebase-frequency'],u32(13000000))
 def test_gic_contract(self):
  n=build(0x90000000,0x1000000,bytes(64));arm=next(c for c in n['children'] if c['name']=='arm-io');self.assertEqual(struct.unpack('<3Q',dict(arm['props'])['ranges']),(0,0xc000000,0x400000));p=dict(arm['children'][0]['props']);self.assertEqual(struct.unpack('<4Q',p['reg']),(0,0x40000,0x100000,0x200000));self.assertEqual(p['virtual-timer-intid'],u32(27))
 def test_no_donor_identity_or_devices(self):
  b=serialize(build(0x90000000,0x1000000,bytes(64)))
  for token in [b'qcom,',b'samsung,',b'ufs',b'Apple',b'iPhone',b'D22AP']:self.assertNotIn(token,b)
 def test_invalid_windows(self):
  for base,size in [(0x90000001,0x1000000),(0x90000000,1),(0xbffff000,0x2000),(0x3ffff000,0x10000)]:
   with self.assertRaises(ValueError):build(base,size,bytes(64))
 def test_seed(self):
  with self.assertRaises(ValueError):build(0x90000000,0x1000000,bytes(63))
 def test_duplicate_props(self):
  with self.assertRaises(ValueError):serialize(node('x',[('name',b'x\0')]))
 def test_metadata_integration(self):
  tree=serialize(build(0x90000000,0x1000000,bytes(64)));b=bytearray(4096+len(tree));b[:8]=b'SWEETXNU';struct.pack_into('<II7Q',b,8,1,1,VB,VB+4,4096,len(tree),VB+8192,0x90000000,0x1000000);struct.pack_into('<4Q',b,680,VB,4096,1024,32);b[4096:]=tree
  p=Policy(Range(0x40000000,0x80000000),Range(0x90000000,0x1000000),Range(0x52000000,len(b)),None,0);o=Metadata();buf=C.create_string_buffer(bytes(b));self.assertEqual(lib.metadata_prepare(buf,len(b),C.byref(p),C.byref(o)),0);self.assertEqual(o.tree.nodes,8);self.assertEqual(struct.unpack_from('<I',bytes(o.bootargs),104)[0],len(tree))
if __name__=='__main__':unittest.main()
