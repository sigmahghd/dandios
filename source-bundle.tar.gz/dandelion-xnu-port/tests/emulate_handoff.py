# SPDX-License-Identifier: MIT
# Executes ordinary ARM64 control flow. ALL privileged effects modeled, ERET NOT executed.
from pathlib import Path
import io,json
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE
import unicorn.arm64_const as A
R=Path(__file__).resolve().parents[1];BASE=0x60000000
elf=ELFFile(io.BytesIO((R/'tests/handoff-el2-arm64.elf').read_bytes()))
symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()};assert elf.header['e_entry']==symbols['dandelion_enter_xnu_el2']
md=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
def run(name,arg_override=None,state_override=None,locked_sre=None):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000)
 for seg in elf.iter_segments():
  if seg['p_type']=='PT_LOAD' and seg['p_filesz']:u.mem_write(BASE+seg['p_vaddr'],seg.data())
 args=[0x90000004,0x90003000,0x90100000,0x40081800]
 if arg_override:args[arg_override[0]]=arg_override[1]
 for i,v in enumerate(args):u.reg_write(getattr(A,'UC_ARM64_REG_X'+str(i)),v)
 state={'currentel':8,'sctlr_el2':0x30c50830,'hcr_el2':0,'icc_sre_el2':0}
 if state_override:state.update(state_override)
 trace=[];stopped=[]
 def regval(n):return 0 if n=='xzr' else u.reg_read(getattr(A,'UC_ARM64_REG_'+n.upper()))
 def code(uc,pc,size,user):
  if pc==BASE+symbols['handoff_park']:stopped.append('rejected');u.emu_stop();return
  ins=next(md.disasm(bytes(u.mem_read(pc,4)),pc));op=ins.mnemonic
  if op=='mrs':
   dst,source=ins.op_str.split(', ')
   value=state[source]
   if source=='icc_sre_el2' and locked_sre is not None:value=locked_sre
   u.reg_write(getattr(A,'UC_ARM64_REG_'+dst.upper()),value);trace.append(('read',source,value));u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif op=='msr':
   target,source=ins.op_str.split(', ')
   value=int(source[1:],0) if source.startswith('#') else regval(source)
   state[target]=value;trace.append(('write',target,value));u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif op in ('dsb','isb','ic','tlbi'):
   trace.append((op,ins.op_str));u.reg_write(A.UC_ARM64_REG_PC,pc+4)
  elif op=='eret':
   stopped.append('prepared_eret');u.emu_stop() # Never execute a modeled ERET as hardware proof.
 def data_access(*unused):raise AssertionError('Handoff unexpectedly dereferenced memory')
 u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,data_access)
 u.emu_start(BASE+symbols['dandelion_enter_xnu_el2'],0,count=10000)
 assert len(stopped)==1,(name,stopped)
 if name=='valid':
  assert stopped[0]=='prepared_eret'
  expected={'hcr_el2':1<<31,'vttbr_el2':0,'cptr_el2':0x33ff,'mdcr_el2':0,'cnthctl_el2':3,'cntvoff_el2':0,'icc_sre_el2':9,'sctlr_el1':0x30d00800,'cpacr_el1':0,'vbar_el1':args[3],'sp_el1':args[2],'cntv_ctl_el0':0,'cntp_ctl_el0':0,'elr_el2':args[0],'spsr_el2':0x3c5}
  for k,v in expected.items():assert state[k]==v,(k,state.get(k),v)
  assert [u.reg_read(getattr(A,'UC_ARM64_REG_X'+str(i))) for i in range(4)]==[args[1],0,0,0]
  assert any(t[0]=='tlbi' for t in trace) and any(t[0]=='ic' for t in trace)
 else:
  assert stopped[0]=='rejected',(name,stopped)
  assert u.reg_read(A.UC_ARM64_REG_X19)==0x4439414641494c31
 assert all(u.reg_read(getattr(A,'UC_ARM64_REG_X'+str(20+i)))==v for i,v in enumerate(args))
 return {'case':name,'result':stopped[0],'privileged_effects':'mocked','eret_executed':False,'memory_dereferences':0,'kernel_executed':False}
cases=[run('valid')]
for i in range(4):cases += [run('zero_arg'+str(i),(i,0)),run('misaligned_arg'+str(i),(i,1))]
for el in [4,12]:cases.append(run('wrong_el'+str(el),state_override={'currentel':el}))
for bit in [0,2,12,25]:cases.append(run('unsafe_sctlr_bit'+str(bit),state_override={'sctlr_el2':0x30c50830|(1<<bit)}))
cases.append(run('stage2_active',state_override={'hcr_el2':1}))
for value in [0,1]:cases.append(run('sre_locked'+str(value),locked_sre=value))
report={'scope':'Ordinary instructions/control-flow of linked ARM64 helper in Unicorn. MRS/MSR/TLBI/IC/barriers modeled; ERET intercepted, never executed. No ATF/GIC/real EL transition or XNU execution.','cases':cases}
(R/'tests/HANDOFF_MODEL_RESULTS.json').write_text(json.dumps(report,indent=2));print('PASS',len(cases),'EL2 handoff control-flow/model cases; NO hardware ERET or kernel execution')
