# SPDX-License-Identifier: MIT. Unit tests only, NOT a macOS build.
from pathlib import Path
import sys,tempfile,json,struct,unittest
from unittest.mock import patch
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'build_support'))
from build_kernel_macos import verify_tree,inspect_kernel,inspect_environment,digest
class Tests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.r=Path(self.tmp.name);self.f=self.r/'kernel'
 def tearDown(self):self.tmp.cleanup()
 def image(self,cpu=0x100000c,subtype=0,kind=2,ncmd=1,size=8):self.f.write_bytes(struct.pack('<8I',0xfeedfacf,cpu,subtype,kind,ncmd,size,0,0)+bytes(8))
 def test_source_ok(self):self.f.write_bytes(b'abc');self.assertEqual(verify_tree(self.r,{'kernel':digest(self.f)}),[])
 def test_source_changed(self):self.f.write_bytes(b'abc');self.assertEqual(len(verify_tree(self.r,{'kernel':'0'*64})),1)
 def test_source_missing(self):self.assertEqual(len(verify_tree(self.r,{'missing':'0'*64})),1)
 def test_source_symlink(self):self.f.write_bytes(b'abc');(self.r/'link').symlink_to(self.f);self.assertEqual(len(verify_tree(self.r,{'link':digest(self.f)})),1)
 def test_plain_arm64_header(self):self.image();v=inspect_kernel(self.f);self.assertFalse(v['boot_verified']);self.assertTrue(v['format_check_only'])
 def test_arm64e_rejected(self):
  self.image(subtype=2)
  with self.assertRaises(ValueError):inspect_kernel(self.f)
 def test_x86_rejected(self):
  self.image(cpu=0x1000007)
  with self.assertRaises(ValueError):inspect_kernel(self.f)
 def test_wrong_type(self):
  self.image(kind=1)
  with self.assertRaises(ValueError):inspect_kernel(self.f)
 def test_truncated(self):
  self.f.write_bytes(b'\xcf\xfa\xed\xfe')
  with self.assertRaises(ValueError):inspect_kernel(self.f)
 def test_bad_command_region(self):
  for n,size in [(0,8),(1,9),(65537,8)]:
   self.image(ncmd=n,size=size)
   with self.assertRaises(ValueError):inspect_kernel(self.f)
 def test_linux_does_not_run_xcode(self):
  with patch('build_kernel_macos.platform.system',return_value='Linux'),patch('build_kernel_macos.command') as run:
   info,errors=inspect_environment(self.r,self.r,self.r,{})
   self.assertEqual(info['platform'],'Linux');self.assertEqual(len(errors),1);run.assert_not_called()
if __name__=='__main__':unittest.main()
