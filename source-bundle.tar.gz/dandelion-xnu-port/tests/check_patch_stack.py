# SPDX-License-Identifier: MIT. Reverse entire local patch stack on a throwaway copy.
from pathlib import Path
import tempfile,shutil,subprocess
R=Path(__file__).resolve().parents[1];patches=sorted(R.glob('030[0-6]-*.patch'));paths=set()
for p in patches:
 for line in p.read_text().splitlines():
  if line.startswith('+++ b/'):paths.add(line[6:].split('\t')[0])
with tempfile.TemporaryDirectory(prefix='d9-patch-check-') as t:
 d=Path(t)
 for path in paths:
  src=R/'work/xnu'/path;dst=d/path
  if src.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 for p in reversed(patches):subprocess.run(['git','apply','--reverse',str(p)],cwd=d,check=True,capture_output=True)
print('PASS: all seven local patches reverse in order on throwaway copies; original tree unchanged')
