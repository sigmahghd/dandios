# SPDX-License-Identifier: MIT
import ctypes as C, struct, subprocess, sys, unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from mkadt_dandelion import build,serialize
S=R/'loader';SO=R/'tests/load-test.so'
subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-shared','-fPIC','-O2',*[str(S/n) for n in ['payload.c','metadata.c','load.c']],'-o',str(SO)],check=True)
class Range(C.Structure):_fields_=[('base',C.c_uint64),('size',C.c_uint64)]
class Policy(C.Structure):_fields_=[('dram',Range),('approved_window',Range),('source',Range),('forbidden',C.POINTER(Range)),('forbidden_count',C.c_size_t)]
class Loaded(C.Structure):_fields_=[('entry',C.c_uint64),('bootargs',C.c_uint64),('top',C.c_uint64)]
lib=C.CDLL(str(SO));f=lib.dandelion_load;f.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Policy),C.c_void_p,C.c_size_t,C.POINTER(Loaded)];f.restype=C.c_int
BASE=0x90000000;VB=0xfffffff007004000;SIZE=0x10000
class Tests(unittest.TestCase):
 def setUp(self):
  self.tree=serialize(build(BASE,SIZE,bytes(64)));self.b=bytearray(4096+len(self.tree));self.b[:8]=b'SWEETXNU'
  struct.pack_into('<II7Q',self.b,8,1,2,VB,VB+4,4096,len(self.tree),VB+8192,BASE,SIZE)
  # Odd source lengths catch rounded-up copies, especially the donor copy64 bug.
  struct.pack_into('<4Q',self.b,680,VB,512,1024,37)
  struct.pack_into('<4Q',self.b,712,VB+4096,511,1100,9)
  self.b[1024:1061]=bytes(range(37));self.b[1100:1109]=b'DANDELION';self.b[4096:]=self.tree
  self.src=C.create_string_buffer(bytes(self.b));self.dst=(C.c_ubyte*SIZE)(*([0xa5]*SIZE));self.out=Loaded(1,2,3)
  self.p=Policy(Range(0x40000000,0x80000000),Range(BASE,SIZE),Range(0x52000000,len(self.b)),None,0)
 def call(self):return f(self.src,len(self.b),C.byref(self.p),self.dst,SIZE,C.byref(self.out))
 def test_exact_copy_zero_metadata_and_unwritten_gaps(self):
  self.assertEqual(self.call(),0);d=bytes(self.dst)
  self.assertEqual(d[:37],bytes(range(37)));self.assertEqual(d[37:512],bytes(475));self.assertEqual(d[512:4096],bytes([0xa5])*3584)
  self.assertEqual(d[4096:4105],b'DANDELION');self.assertEqual(d[4105:4607],bytes(502));self.assertEqual(d[4607:8192],bytes([0xa5])*(8192-4607))
  self.assertEqual(d[8192:8192+len(self.tree)],self.tree)
  ba=self.out.bootargs-BASE;self.assertEqual(d[ba:ba+4],b'\x02\x00\x02\x00');self.assertEqual(d[ba+736:ba+4096],bytes(4096-736))
  self.assertEqual(self.out.entry,BASE+4);self.assertEqual(self.out.top,self.out.bootargs+4096)
  self.assertEqual(d[self.out.top-BASE:],bytes([0xa5])*(SIZE-(self.out.top-BASE)))
 def assert_unchanged(self,code):
  self.assertEqual(self.call(),code);self.assertEqual(bytes(self.dst),bytes([0xa5])*SIZE);self.assertEqual((self.out.entry,self.out.bootargs,self.out.top),(1,2,3))
 def test_bad_header_no_write(self):self.src[0]=b'X';self.assert_unchanged(2)
 def test_denied_ram_no_write(self):self.p.approved_window.base+=4096;self.assert_unchanged(3)
 def test_wrong_mapping_length(self):self.p.approved_window.size-=4096;self.assert_unchanged(300)
 def test_reserved_range(self):
  forbidden=(Range*1)(Range(BASE+4096,4096));self.p.forbidden=forbidden;self.p.forbidden_count=1;self.assert_unchanged(4)
 def test_invalid_adt_no_write(self):self.src[4096+8]=b'\0';self.assert_unchanged(104)
 def test_source_destination_alias(self):
  d=(C.c_ubyte*SIZE)();C.memmove(d,self.src,len(self.b));before=bytes(d)
  self.assertEqual(f(d,len(self.b),C.byref(self.p),d,SIZE,C.byref(self.out)),301);self.assertEqual(bytes(d),before)
 def test_output_destination_alias(self):
  self.assertEqual(f(self.src,len(self.b),C.byref(self.p),self.dst,SIZE,C.cast(self.dst,C.POINTER(Loaded))),301);self.assertEqual(bytes(self.dst),bytes([0xa5])*SIZE)
 def test_output_source_alias(self):
  before=self.src.raw;self.assertEqual(f(self.src,len(self.b),C.byref(self.p),self.dst,SIZE,C.cast(self.src,C.POINTER(Loaded))),301);self.assertEqual(before,self.src.raw)
 def test_null_pointer(self):self.assertEqual(f(None,1,C.byref(self.p),self.dst,SIZE,C.byref(self.out)),300)
if __name__=='__main__':unittest.main()
