/* SPDX-License-Identifier: MIT
 * Compile-only stand-in declarations; NOT actual complete XNU headers. */
#include <stdint.h>
#include <stddef.h>
#define SECURITY_READ_ONLY_LATE(x) x
#define SERIAL_DANDELION_FBCON 0x40
#define DSB_SY 15
#define kSuccess 0
typedef void *DTEntry;
struct pe_serial_functions {void (*init)(void);unsigned (*transmit_ready)(void);void (*transmit_data)(uint8_t);unsigned (*receive_ready)(void);uint8_t (*receive_data)(void);unsigned device;};
extern int PE_parse_boot_argn(const char *,void *,int);
extern int SecureDTFindEntry(const char *,const char *,DTEntry *);
extern int SecureDTGetProperty(DTEntry,const char *,const void **,unsigned *);
extern uintptr_t ml_io_map_wcomb(uint64_t,uint64_t);
extern void register_serial_functions(struct pe_serial_functions *);
#include "../platform/dandelion_fbcon.h"
void compile_dandelion_fbcon(void){dandelion_fbcon_probe();}
