/* SPDX-License-Identifier: MIT
 * Cortex-A53 range maintenance, 64-byte lines. Caller owns valid mappings and
 * DMA synchronization. This does NOT turn cache maintenance into DMA fencing.
 * Preserves x0/x1, clobbers x9/x10 and flags. No address dereferences.
 * A wrapping address range traps instead of maintaining arbitrary memory.
 */
#ifndef DANDELION_CACHE_ASM_H
#define DANDELION_CACHE_ASM_H
.macro D9_CACHE_RANGE operation, instruction=0
 cbz x1, 90f
 sub x10, x1, #1
 adds x10, x0, x10
 b.cs 99f
 and x10, x10, #0xffffffffffffffc0
 and x9, x0, #0xffffffffffffffc0
 dsb sy
91:
 dc \operation, x9
 cmp x9, x10
 b.eq 92f
 add x9, x9, #64
 b 91b
92:
 dsb sy
.if \instruction
 and x9, x0, #0xffffffffffffffc0
93:
 ic ivau, x9
 cmp x9, x10
 b.eq 94f
 add x9, x9, #64
 b 93b
94:
 dsb sy
 isb
.endif
90:
 dsb sy
 ret
99:
 brk #0xd9
 b 99b
.endmacro
#endif
