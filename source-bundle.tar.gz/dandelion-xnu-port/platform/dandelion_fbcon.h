/* SPDX-License-Identifier: MIT
 * Diagnostic console for LK's TWO inherited Redmi 9A scanout surfaces.
 * Not a display driver: no DSI/panel/clock/power/DMA programming.
 * Opt-in only, after the caller has preserved the framebuffer reservation and
 * established compatible write-combining mappings without cached aliases.
 * Driver registration uses the existing polling serial serialization contract.
 */
#ifndef DANDELION_FBCON_H
#define DANDELION_FBCON_H
extern unsigned char iso_font[256 * 16];
struct d9fb_surface { volatile uint32_t *pixels; uint32_t stride; };
static struct d9fb_surface d9fb[2];
static uint32_t d9fb_col, d9fb_row;
static unsigned d9fb_registered;
#define D9FB_WIDTH 720u
#define D9FB_HEIGHT 1600u
#define D9FB_COLS 45u
#define D9FB_ROWS 50u
static uint64_t d9fb_le64(const uint8_t *p)
{uint64_t v=0;for(unsigned i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);return v;}
static uint32_t d9fb_le32(const uint8_t *p)
{uint32_t v=0;for(unsigned i=0;i<4;i++)v|=(uint32_t)p[i]<<(8*i);return v;}
static void d9fb_barrier(void)
{__builtin_arm_dsb(DSB_SY);}
static void d9fb_clear_row(uint32_t row)
{
 for(unsigned s=0;s<2;s++)for(uint32_t y=row*32;y<(row+1)*32;y++){
  volatile uint32_t *line=d9fb[s].pixels+y*(d9fb[s].stride/4);
  for(uint32_t x=0;x<D9FB_WIDTH;x++)line[x]=0xff000000u;
 }
}
static void d9fb_newline(void)
{
 d9fb_col=0;d9fb_row=(d9fb_row+1)%D9FB_ROWS;
 d9fb_clear_row(d9fb_row);d9fb_clear_row((d9fb_row+1)%D9FB_ROWS);
}
static void d9fb_init(void)
{
 d9fb_col=d9fb_row=0;
 for(uint32_t r=0;r<D9FB_ROWS;r++)d9fb_clear_row(r);
 d9fb_barrier();
}
static unsigned int d9fb_tx_ready(void){return 1;}
static unsigned int d9fb_rx_ready(void){return 0;}
static uint8_t d9fb_rx(void){return 0;}
static void d9fb_tx(uint8_t c)
{
 if(c=='\r'){d9fb_col=0;return;}
 if(c=='\n'){d9fb_newline();d9fb_barrier();return;}
 if(d9fb_col==D9FB_COLS)d9fb_newline();
 const unsigned char *glyph=iso_font+(uint32_t)c*16;
 for(unsigned s=0;s<2;s++)for(uint32_t gy=0;gy<16;gy++)for(uint32_t sy=0;sy<2;sy++){
  volatile uint32_t *line=d9fb[s].pixels+(d9fb_row*32+gy*2+sy)*(d9fb[s].stride/4)+d9fb_col*16;
  for(uint32_t gx=0;gx<8;gx++){
   uint32_t px=(glyph[gy]&(1u<<gx))?0xffffffffu:0xff000000u;
   line[gx*2]=px;line[gx*2+1]=px;
  }
 }
 d9fb_col++;d9fb_barrier();
}
SECURITY_READ_ONLY_LATE(static struct pe_serial_functions) d9fb_functions={
 .init=d9fb_init,.transmit_ready=d9fb_tx_ready,.transmit_data=d9fb_tx,
 .receive_ready=d9fb_rx_ready,.receive_data=d9fb_rx,.device=SERIAL_DANDELION_FBCON
};
static void dandelion_fbcon_probe(void)
{
 DTEntry entry;const void *property;unsigned int size;int enabled=0;
 if(d9fb_registered || !PE_parse_boot_argn("dandelion-fbcon",&enabled,sizeof enabled) || enabled!=1)return;
 if(SecureDTFindEntry("name","dandelion-fbcon",&entry)!=kSuccess)return;
 /* Exact, bytewise descriptor matching BEFORE mapping either region. */
 if(SecureDTGetProperty(entry,"reg",&property,&size)!=kSuccess || size!=32)return;
 const uint8_t *r=(const uint8_t *)property;
 const uint64_t pa[2]={0x7ec50000ULL,0x7f0ce000ULL};
 const uint32_t pitch[2]={2944,2880};
 for(unsigned i=0;i<2;i++)if(d9fb_le64(r+i*16)!=pa[i] || d9fb_le64(r+i*16+8)!=(uint64_t)pitch[i]*D9FB_HEIGHT)return;
 const char *names[3]={"width","height","stride"};
 const uint32_t values[4]={D9FB_WIDTH,D9FB_HEIGHT,2944,2880};
 for(unsigned i=0;i<3;i++){
  if(SecureDTGetProperty(entry,names[i],&property,&size)!=kSuccess || size!=(i==2?8u:4u))return;
  if(d9fb_le32((const uint8_t *)property)!=values[i])return;
  if(i==2 && d9fb_le32((const uint8_t *)property+4)!=values[3])return;
 }
 for(unsigned i=0;i<2;i++){
  d9fb[i].pixels=(volatile uint32_t *)ml_io_map_wcomb(pa[i],(uint64_t)pitch[i]*D9FB_HEIGHT);
  d9fb[i].stride=pitch[i];
  if(!d9fb[i].pixels){
   /* Boot-only mappings; retain an earlier successful mapping, but never use
    * partially initialized surfaces or register a broken serial interface. */
   return;
  }
 }
 d9fb_registered=1;register_serial_functions(&d9fb_functions);
}
#endif
