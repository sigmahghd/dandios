/* SPDX-License-Identifier: MIT
 * Single boot-CPU registration for experimental Redmi 9A XNU bring-up.
 * No PSCI CPU_ON, firmware writes, suspend, power or secondary support.
 */
#include <pexpert/arm64/board_config.h>
#if defined(DANDELION)
#include <IOKit/IOCPU.h>
#include <IOKit/IOLib.h>
#include <libkern/c++/OSData.h>
#include <libkern/c++/OSNumber.h>
#include <arm64/proc_reg.h>
#include <kern/processor.h>
#include <kern/thread.h>
#include <kern/clock.h>
#include <mach/mach_time.h>
#include <pexpert/pexpert.h>
extern "C" boolean_t dandelion_cpu_signal_is_enabled(unsigned int);

class DandelionCPU : public IOCPU {
 OSDeclareDefaultStructors(DandelionCPU);
 const OSSymbol *name = NULL;
 uint32_t initialized = 0;
 static void startBoot(void *, wait_result_t);
public:
 bool start(IOService *) APPLE_KEXT_OVERRIDE;
 void free(void) APPLE_KEXT_OVERRIDE;
 void initCPU(bool) APPLE_KEXT_OVERRIDE;
 void signalCPU(IOCPU *) APPLE_KEXT_OVERRIDE;
 kern_return_t startCPU(vm_offset_t, vm_offset_t) APPLE_KEXT_OVERRIDE;
 void quiesceCPU(void) APPLE_KEXT_OVERRIDE;
 void haltCPU(void) APPLE_KEXT_OVERRIDE;
 const OSSymbol *getCPUName(void) APPLE_KEXT_OVERRIDE;
};
OSDefineMetaClassAndStructors(DandelionCPU, IOCPU);

bool DandelionCPU::start(IOService *provider)
{
 const ml_topology_info_t *topology=ml_get_topology_info();
 if(!provider || !topology || topology->num_cpus!=1 ||
    !topology->boot_cpu || topology->boot_cpu!=&topology->cpus[0] ||
    topology->boot_cpu->phys_id!=DANDELION_BOOT_MPIDR ||
    topology->boot_cpu->cpu_id!=0 || topology->max_cpu_id!=0) return false;
 OSNumber *logical=OSDynamicCast(OSNumber,provider->getProperty("logical-cpu-id"));
 OSData *reg=OSDynamicCast(OSData,provider->getProperty("reg"));
 if(!logical || logical->unsigned32BitValue()!=0 || !reg || reg->getLength()!=4) return false;
 const uint8_t *raw=(const uint8_t *)reg->getBytesNoCopy();
 if(!raw || raw[0] || raw[1] || raw[2] || raw[3]) return false;
 if(!IOCPU::start(provider)) return false;
 name=OSSymbol::withCStringNoCopy("Cortex-A53");
 if(!name) return false;
 setCPUNumber(0);
 const ml_topology_cpu_t *cpu=topology->boot_cpu;
 ml_processor_info_t info={};
 info.cpu_id=reinterpret_cast<cpu_id_t>(this);
 info.phys_id=cpu->phys_id;info.log_id=0;
 info.cluster_id=cpu->cluster_id;info.cluster_type=cpu->cluster_type;
 info.l2_cache_id=cpu->l2_cache_id;info.l2_cache_size=cpu->l2_cache_size;
 info.l3_cache_id=cpu->l3_cache_id;info.l3_cache_size=cpu->l3_cache_size;
 perfmon_interrupt_handler_func pmi=NULL;
 kern_return_t kr=ml_processor_register(&info,&machProcessor,&ipi_handler,&pmi);
 if(kr!=KERN_SUCCESS || pmi!=NULL) panic("DANDELION: boot CPU registration/PMI unsupported");
 registerService();
 thread_t thread;
 kr=kernel_thread_start(&DandelionCPU::startBoot,this,&thread);
 if(kr!=KERN_SUCCESS) panic("DANDELION: boot CPU startup thread failed");
 thread_deallocate(thread);
 return true;
}
void DandelionCPU::startBoot(void *arg,wait_result_t)
{
 DandelionCPU *self=(DandelionCPU *)arg;
 if(processor_start(self->machProcessor)!=KERN_SUCCESS) panic("DANDELION: processor_start failed");
 uint64_t deadline;nanoseconds_to_deadline(5*NSEC_PER_SEC,&deadline);
 /* Iteration bound assumes IOSleep returns; it cannot bound a stuck scheduler. */
 unsigned iterations=0;
 while(!__atomic_load_n(&self->initialized,__ATOMIC_ACQUIRE) ||
       !dandelion_cpu_signal_is_enabled(0)) {
  if(++iterations>5000 || mach_absolute_time()>deadline)
   panic("DANDELION: boot CPU initialization/self-SGI timeout");
  IOSleep(1);
 }
 ml_cpu_init_completed();
 self->cpusRunning();
 IOService::publishResource(gIOAllCPUInitializedKey,kOSBooleanTrue);
 ml_set_max_cpus(1);
 IOLog("DANDELION: boot CPU initialized, self-SGI observed\n");
 thread_terminate(current_thread());
}
void DandelionCPU::initCPU(bool boot)
{
 if(!boot || getCPUNumber()!=0 || cpu_number()!=0) panic("DANDELION: CPU resume/topology unsupported");
 ml_broadcast_cpu_event(CPU_BOOTED,0);
 signalCPU(this);
 setCPUState(kIOCPUStateRunning);
 __atomic_store_n(&initialized,1,__ATOMIC_RELEASE);
}
void DandelionCPU::signalCPU(IOCPU *target)
{
 if(target!=this || getCPUNumber()!=0) panic("DANDELION: secondary IPI unsupported");
 __builtin_arm_dsb(DSB_ISHST);
 __builtin_arm_wsr64("ICC_SGI1R_EL1",((uint64_t)DANDELION_IPI_SGI<<24)|1ULL);
 __builtin_arm_isb(ISB_SY);
}
kern_return_t DandelionCPU::startCPU(vm_offset_t,vm_offset_t){return KERN_NOT_SUPPORTED;}
void DandelionCPU::quiesceCPU(void){panic("DANDELION: CPU quiesce unsupported");}
void DandelionCPU::haltCPU(void){panic("DANDELION: CPU halt/suspend unsupported");}
const OSSymbol *DandelionCPU::getCPUName(void){return name;}
void DandelionCPU::free(void){OSSafeReleaseNULL(name);IOCPU::free();}
#endif
