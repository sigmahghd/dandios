/* SPDX-License-Identifier: MIT. GICv3 redistributor bounds/affinity helper.
 * No MMIO unless caller explicitly supplies a hardware-reading callback.
 * Header-only so kernel and host tests exercise the same implementation. */
#ifndef DANDELION_GIC_HELPER_H
#define DANDELION_GIC_HELPER_H
#include <stdint.h>
#include <stddef.h>
typedef uint64_t (*dgic_read64_fn)(void *, uint64_t);
static inline int dgic_find_redistributor(dgic_read64_fn read64,void *ctx,
 uint64_t length,uint64_t mpidr,uint64_t *result)
{
 uint64_t off=0;unsigned count=0;
 uint32_t affinity=(uint32_t)(mpidr&0xffffffu)|(uint32_t)((mpidr>>8)&0xff000000u);
 if(!read64||!result||length<0x20000||length>0x200000)return 1;
 while(off<length&&count++<32){
  uint64_t typer,stride;
  if(length-off<0x20000)return 2;
  typer=read64(ctx,off+8);
  stride=(typer&2)?0x40000:0x20000; /* VLPIS implies two extra frames. */
  if(length-off<stride)return 2;
  if((uint32_t)(typer>>32)==affinity){*result=off;return 0;}
  if(typer&0x10)return 3;
  off+=stride;
 }
 return 3;
}
static inline uint64_t dgic_property_u64(const void *property,unsigned index)
{
 const uint8_t *p=(const uint8_t *)property+8u*index;uint64_t v=0;unsigned i;
 for(i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);
 return v;
}
#endif
