/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_PREPARE_FROM_FDT_H
#define DANDELION_PREPARE_FROM_FDT_H
#include "prepare_in_image.h"
#include "../platform/lk_fdt.h"
/* fdt must be the actual incoming LK x0 pointer, with readable bytes independently
 * bounded by its DTB reservation and verified CPU/memory state. No recovery-file
 * parameter or fallback. Caller still supplies accurate code-derived Image bounds.
 * Does not itself establish freshness/identity or perform ERET. */
int dandelion_prepare_from_fdt(const uint8_t *fdt,size_t fdt_bytes,
 const uint8_t *source,size_t source_bytes,const struct policy *,uint8_t *mapping,
 size_t mapping_bytes,const struct handoff_storage *,const struct range *image,
 struct handoff_args *out);
#endif
