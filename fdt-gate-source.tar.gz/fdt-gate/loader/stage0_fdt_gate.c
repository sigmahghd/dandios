/* SPDX-License-Identifier: MIT */
#include "stage0_fdt_gate.h"
static int alias(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;return !a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y||(x<y+bn&&y<x+an);}
static uint32_t be32(const uint8_t *b){return (uint32_t)b[0]<<24|(uint32_t)b[1]<<16|(uint32_t)b[2]<<8|b[3];}
int dandelion_stage0_fdt_checked(const uint8_t *fdt,const struct stage0_fdt_context *c,struct handoff_args *out)
{
 struct stage0_fdt_context ctx;struct handoff_storage storage;size_t fn,i;
 /* Exact PA check precedes the first FDT/header or context dereference.
  * Requires the assembly guard and caller-owned stack/identity mapping. */
 if((uintptr_t)fdt!=0x47880000u)return LK_ARENA_FDT;
 if(!c||!out)return 300;
 if(be32(fdt)!=0xd00dfeedu)return LK_FDT_HEADER;
 fn=be32(fdt+4);if(fn<40||fn>0x80000)return LK_FDT_HEADER;
 if(alias(out,sizeof *out,c,sizeof *c)||alias(out,sizeof *out,fdt,fn))return 301;
 {volatile uint8_t *d=(volatile uint8_t *)&ctx;const volatile uint8_t *v=(const volatile uint8_t *)c;for(i=0;i<sizeof ctx;i++)d[i]=v[i];}
 if(!ctx.storage||!ctx.policy||!ctx.image)return 300;
 if(alias(out,sizeof *out,ctx.storage,sizeof *ctx.storage)||alias(ctx.mapping,ctx.mapping_size,c,sizeof *c))return 301;
 {volatile uint8_t *d=(volatile uint8_t *)&storage;const volatile uint8_t *v=(const volatile uint8_t *)ctx.storage;for(i=0;i<sizeof storage;i++)d[i]=v[i];}
 storage.input_fdt.base=(uintptr_t)fdt;storage.input_fdt.size=fn;
 return dandelion_prepare_from_fdt(fdt,fn,ctx.source,ctx.source_size,ctx.policy,ctx.mapping,ctx.mapping_size,&storage,ctx.image,out);
}
