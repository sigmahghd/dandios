/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_STAGE0_FDT_GATE_H
#define DANDELION_STAGE0_FDT_GATE_H
#include "prepare_from_fdt.h"
struct stage0_fdt_context {
 const uint8_t *source;size_t source_size;const struct policy *policy;
 uint8_t *mapping;size_t mapping_size;const struct handoff_storage *storage;
 const struct range *image;
};
/* Assembly callable adapter, NOT an Image entry or Boot image. x0 must retain
 * LK's incoming DTB pointer; x1=context, x2=out. Caller supplies an already
 * owned, writable, aligned EL2 stack and Image-derived addresses in context.
 * Checks EL2/M/C/I/endian/stage2 before any data-memory access; then derives
 * FDT size from the header at the exact observed DTB PA. No recovery fallback.
 * Privileged caller only. Returns 700 for incompatible CPU state; otherwise
 * existing errors. Never ERET/jump or change control registers/MMIO.
 * Pointer accessibility/freshness and linker/Stage0 integration remain caller
 * responsibilities. CPU register reads may be trapped by firmware policy.
 */
int dandelion_stage0_fdt_gate(const uint8_t *,const struct stage0_fdt_context *,struct handoff_args *);
int dandelion_stage0_fdt_checked(const uint8_t *,const struct stage0_fdt_context *,struct handoff_args *);
#endif
