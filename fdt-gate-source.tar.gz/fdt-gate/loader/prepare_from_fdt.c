/* SPDX-License-Identifier: MIT */
#include "prepare_from_fdt.h"
static int alias(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;return !a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y||(x<y+bn&&y<x+an);}
int dandelion_prepare_from_fdt(const uint8_t *fdt,size_t fn,const uint8_t *b,size_t n,
 const struct policy *p,uint8_t *mapping,size_t mn,const struct handoff_storage *s,
 const struct range *image,struct handoff_args *out)
{
 struct lk_fdt_view view;int rc;
 if(!fdt||!fn||!b||!n||!p||!mapping||!mn||!s||!image||!out)return 300;
 if(fn>0x80000||s->input_fdt.base!=0x47880000u||s->input_fdt.size!=(uint64_t)fn)return LK_ARENA_FDT;
 if(alias(out,sizeof *out,fdt,fn)||alias(mapping,mn,fdt,fn))return 301;
 rc=dandelion_lk_fdt(fdt,fn,image,&view);if(rc)return rc;
 return dandelion_prepare_in_image(b,n,p,mapping,mn,s,image,fdt+view.mblock_offset,view.mblock_size,out);
}
