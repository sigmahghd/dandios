/* SPDX-License-Identifier: MIT */
#ifndef DANDELION_LK_FDT_H
#define DANDELION_LK_FDT_H
#include "lk_arena.h"
struct lk_fdt_view {uint32_t mblock_offset,mblock_size,total_size,reservation_count;};
enum lk_fdt_error { LK_FDT_ARGUMENT=600,LK_FDT_HEADER=601,LK_FDT_BOUNDS=602,LK_FDT_STRUCTURE=603,LK_FDT_MBLOCK=604,LK_FDT_RESERVATION=605 };
/* Bounded read of FDT v17 /memory/mblock_info. No fallback snapshot, allocation,
 * write to source, MMIO or dereference outside supplied accessible bytes.
 * Rejects ambiguity, malformed structure and image-conflicting memreserve.
 * Caller must establish pointer accessibility/identity/freshness and Image
 * extent before reading. out must not alias input/extent; unchanged on error.
 * No general DT address translation or reserved-memory binding interpretation.
 */
int dandelion_lk_fdt(const uint8_t *fdt,size_t bytes,const struct range *image,struct lk_fdt_view *out);
#endif
