/* SPDX-License-Identifier: MIT */
#include "lk_fdt.h"
static uint32_t be32(const uint8_t *b){return (uint32_t)b[0]<<24|(uint32_t)b[1]<<16|(uint32_t)b[2]<<8|b[3];}
static uint64_t be64(const uint8_t *b){return (uint64_t)be32(b)<<32|be32(b+4);}
static int bounded(size_t off,size_t n,size_t end){return off<=end&&n<=end-off;}
static int intervals(size_t a,size_t n,size_t b,size_t m){return a<b+m&&b<a+n;}
static int alias(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;return !a||!b||!an||!bn||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y||(x<y+bn&&y<x+an);}
static int text_end(const uint8_t *b,size_t at,size_t end,size_t *nul){size_t i;for(i=at;i<end&&i-at<128;i++){if(!b[i]){*nul=i;return 1;}if(b[i]<32||b[i]>126)return 0;}return 0;}
static int equal(const uint8_t *b,size_t n,const char *s){size_t i;for(i=0;i<n;i++)if(!s[i]||b[i]!=(uint8_t)s[i])return 0;return s[n]==0;}
int dandelion_lk_fdt(const uint8_t *b,size_t n,const struct range *image,struct lk_fdt_view *out)
{
 size_t os,ss,ot,ts,orr,rend,pos,end,nul,nameoff,length,data,depth=0,nodes=0,props=0,i;uint32_t token,count=0,memories=0,found=0;int closed=0,memory[64];struct lk_fdt_view result;
 if(!b||!image||!out||n<40||n>0x80000||image->size==0||image->base>UINT64_MAX-image->size)return LK_FDT_ARGUMENT;
 if(alias(out,sizeof *out,b,n)||alias(out,sizeof *out,image,sizeof *image))return LK_FDT_ARGUMENT;
 if(be32(b)!=0xd00dfeedu||be32(b+4)!=n||be32(b+20)!=17||be32(b+24)>17)return LK_FDT_HEADER;
 os=be32(b+8);ot=be32(b+12);orr=be32(b+16);ts=be32(b+32);ss=be32(b+36);
 if(os<40||(os&3)||ot<40||orr<40||(orr&7)||!ss||!ts||!bounded(os,ss,n)||!bounded(ot,ts,n)||!bounded(orr,16,n)||intervals(os,ss,ot,ts))return LK_FDT_BOUNDS;
 rend=orr;
 for(;;){uint64_t base,size;
  if(!bounded(rend,16,n)||intervals(rend,16,0,40)||intervals(rend,16,os,ss)||intervals(rend,16,ot,ts))return LK_FDT_BOUNDS;
  base=be64(b+rend);size=be64(b+rend+8);rend+=16;if(!base&&!size)break;
  if(++count>128||!size||base>UINT64_MAX-size)return LK_FDT_RESERVATION;
  if(base<image->base+image->size&&image->base<base+size)return LK_FDT_RESERVATION;
 }
 pos=os;end=os+ss;result.mblock_offset=0;result.mblock_size=0;
 while(bounded(pos,4,end)){
  token=be32(b+pos);pos+=4;
  if(token==1){
   if(closed||depth==64||++nodes>4096||!text_end(b,pos,end,&nul)||nul-pos>127)return LK_FDT_STRUCTURE;
   if((!depth&&nul!=pos)||(depth&&nul==pos))return LK_FDT_STRUCTURE;
   for(i=pos;i<nul;i++)if(b[i]=='/')return LK_FDT_STRUCTURE;
   memory[depth]=(depth==1&&equal(b+pos,nul-pos,"memory"));
   if(memory[depth]&&++memories!=1)return LK_FDT_MBLOCK;
   depth++;pos=(nul+4)&~(size_t)3;if(pos>end)return LK_FDT_STRUCTURE;
  }else if(token==2){if(!depth)return LK_FDT_STRUCTURE;depth--;if(!depth)closed=1;
  }else if(token==3){
   if(!depth||++props>16384||!bounded(pos,8,end))return LK_FDT_STRUCTURE;
   length=be32(b+pos);nameoff=be32(b+pos+4);pos+=8;data=pos;
   if(!bounded(pos,length,end)||nameoff>=ts||!text_end(b,ot+nameoff,ot+ts,&nul)||nul==ot+nameoff)return LK_FDT_BOUNDS;
   if(depth==2&&memory[1]&&equal(b+ot+nameoff,nul-ot-nameoff,"mblock_info")){
    if(found++||length!=LK_MBLOCK_V2_BYTES)return LK_FDT_MBLOCK;
    result.mblock_offset=(uint32_t)data;result.mblock_size=(uint32_t)length;
   }
   pos=(pos+length+3)&~(size_t)3;if(pos>end)return LK_FDT_BOUNDS;
  }else if(token==4){
  }else if(token==9){
   if(depth||!closed)return LK_FDT_STRUCTURE;
   for(i=pos;i<end;i++)if(b[i])return LK_FDT_STRUCTURE;
   if(memories!=1||found!=1)return LK_FDT_MBLOCK;
   result.total_size=(uint32_t)n;result.reservation_count=count;
   {volatile uint8_t *d=(volatile uint8_t *)out;const volatile uint8_t *s=(const volatile uint8_t *)&result;for(i=0;i<sizeof result;i++)d[i]=s[i];}
   return 0;
  }else return LK_FDT_STRUCTURE;
 }
 return LK_FDT_STRUCTURE;
}
