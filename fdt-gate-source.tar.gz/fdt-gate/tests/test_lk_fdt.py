#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Bounded FDT wire reader tests. Synthetic data only, no device access."""
import ctypes as C,platform,struct,subprocess,unittest
from pathlib import Path
from test_lk_arena import fixture
from test_handoff_contract import Range
R=Path(__file__).resolve().parents[1]
class View(C.Structure):_fields_=[('offset',C.c_uint32),('size',C.c_uint32),('total',C.c_uint32),('reservations',C.c_uint32)]
def fdt_fixture(mb=None,*,duplicate=False,memory_name=b'memory',include=True,reservations=(),other=False):
 if mb is None:mb=fixture()
 def w(*x):return struct.pack('>'+'I'*len(x),*x)
 def node(name):return w(1)+name+b'\0'+bytes(-(len(name)+1)%4)
 def prop():return w(3,len(mb),0)+bytes(mb)+bytes(-len(mb)%4)
 reserve=b''.join(struct.pack('>QQ',*r) for r in reservations)+bytes(16)
 body=node(b'')
 if other:body+=node(b'wrong-parent')+node(memory_name)
 else:body+=node(memory_name)
 if include:body+=prop()
 if duplicate:body+=prop()
 body+=w(2)
 if other:body+=w(2)
 body+=w(2,9);strings=b'mblock_info\0';os=40+len(reserve);ot=os+len(body)
 return bytearray(w(0xd00dfeed,ot+len(strings),os,ot,40,17,16,0,len(strings),len(body))+reserve+body+strings)
so=R/'tests/lk-fdt-test.so';subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',str(R/'platform/lk_fdt.c'),'-o',str(so)],check=True)
f=C.CDLL(str(so)).dandelion_lk_fdt;f.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(Range),C.POINTER(View)];f.restype=C.c_int
class Tests(unittest.TestCase):
 def setUp(self):self.b=fdt_fixture();self.image=Range(0x40080000,0x43210000-0x40080000);self.out=View(1,2,3,4)
 def w(self,offset,*v):struct.pack_into('>'+'I'*len(v),self.b,offset,*v)
 def call(self):self.buf=C.create_string_buffer(bytes(self.b));return f(self.buf,len(self.b),C.byref(self.image),C.byref(self.out))
 def reject(self,rc):old=bytes(self.out);self.assertEqual(self.call(),rc);self.assertEqual(bytes(self.out),old);self.assertEqual(self.buf.raw[:-1],bytes(self.b))
 def os(self):return struct.unpack_from('>I',self.b,8)[0]
 def test_valid(self):self.assertEqual(self.call(),0);self.assertEqual(bytes(self.b[self.out.offset:self.out.offset+self.out.size]),bytes(fixture()));self.assertEqual(self.out.total,len(self.b))
 def test_short_header(self):self.b=self.b[:39];self.reject(600)
 def test_max_size(self):self.b+=bytes(0x80001-len(self.b));self.reject(600)
 def test_bad_magic(self):self.w(0,0);self.reject(601)
 def test_wrong_version(self):self.w(20,16);self.reject(601)
 def test_future_compatibility(self):self.w(24,18);self.reject(601)
 def test_total_small(self):self.w(4,len(self.b)-1);self.reject(601)
 def test_total_big(self):self.w(4,len(self.b)+1);self.reject(601)
 def test_structure_inside_header(self):self.w(8,36);self.reject(602)
 def test_unaligned_structure(self):self.w(8,self.os()+1);self.reject(602)
 def test_unaligned_reservations(self):self.w(16,41);self.reject(602)
 def test_structure_outside(self):self.w(36,len(self.b));self.reject(602)
 def test_strings_outside(self):self.w(12,len(self.b));self.reject(602)
 def test_blocks_overlap(self):self.w(12,self.os());self.reject(602)
 def test_reserve_overlaps_structure(self):self.w(16,self.os());self.reject(602)
 def test_reserve_conflicts_image(self):self.b=fdt_fixture(reservations=[(0x41200000,4096)]);self.reject(605)
 def test_reserve_overflow(self):self.b=fdt_fixture(reservations=[((1<<64)-4096,8192)]);self.reject(605)
 def test_zero_reserve_size(self):self.b=fdt_fixture(reservations=[(0x70000000,0)]);self.reject(605)
 def test_unrelated_reserve(self):self.b=fdt_fixture(reservations=[(0x70000000,4096)]);self.assertEqual(self.call(),0);self.assertEqual(self.out.reservations,1)
 def test_unknown_token(self):self.w(self.os(),0xaabbccdd);self.reject(603)
 def test_root_name_not_empty(self):self.b[self.os()+4]=ord('x');self.reject(603)
 def test_end_node_without_begin(self):self.w(self.os(),2);self.reject(603)
 def test_early_end(self):self.w(self.os()+8,9);self.reject(603)
 def test_missing_end(self):self.w(struct.unpack_from('>I',self.b,12)[0]-4,4);self.reject(603)
 def test_bad_name_offset(self):self.w(self.os()+20+8,0xffffffff);self.reject(602)
 def test_property_length_overflow(self):self.w(self.os()+20+4,0xffffffff);self.reject(602)
 def test_duplicate_mblock(self):self.b=fdt_fixture(duplicate=True);self.reject(604)
 def test_missing_mblock(self):self.b=fdt_fixture(include=False);self.reject(604)
 def test_short_mblock(self):self.b=fdt_fixture(mb=fixture()[:-1]);self.reject(604)
 def test_wrong_node(self):self.b=fdt_fixture(memory_name=b'other');self.reject(604)
 def test_nested_decoy(self):self.b=fdt_fixture(other=True);self.reject(604)
 def test_slash_node(self):self.b=fdt_fixture(memory_name=b'memory/x');self.reject(603)
 def test_long_node(self):self.b=fdt_fixture(memory_name=b'x'*128);self.reject(603)
 def test_unterminated_property_name(self):self.b[-1]=ord('x');self.reject(602)
 def test_empty_property_name(self):self.b[-12]=0;self.reject(602)
 def test_image_overflow(self):self.image.base=(1<<64)-1;self.reject(600)
 def test_output_alias_input(self):
  self.buf=C.create_string_buffer(bytes(self.b));old=self.buf.raw;rc=f(self.buf,len(self.b),C.byref(self.image),C.cast(self.buf,C.POINTER(View)));self.assertEqual(rc,600);self.assertEqual(self.buf.raw,old)
 def test_output_alias_image(self):
  self.buf=C.create_string_buffer(bytes(self.b));old=bytes(self.image);rc=f(self.buf,len(self.b),C.byref(self.image),C.cast(C.byref(self.image),C.POINTER(View)));self.assertEqual(rc,600);self.assertEqual(bytes(self.image),old)
 def test_null(self):self.assertEqual(f(None,len(self.b),C.byref(self.image),C.byref(self.out)),600)
if __name__=='__main__':unittest.main()
