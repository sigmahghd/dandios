#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Incoming-FDT -> mblock -> Image contract -> actual kernel copy. Offline only."""
import argparse,ctypes as C,hashlib,json,platform,struct,subprocess,sys,unittest
from pathlib import Path
from test_lk_fdt import fdt_fixture
from test_lk_arena import fixture,layout
from test_handoff_contract import Range,Policy,Storage,Args
from test_real_kernel_fixture import check_mapping
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from pack_kernel_fixture import package_fixture,WINDOW
class Tests(unittest.TestCase):
 def setUp(self):
  self.p,self.s,self.image=layout(len(PAYLOAD));self.fd=fdt_fixture();self.s.input_fdt.size=len(self.fd);self.src=C.create_string_buffer(PAYLOAD);self.dst=C.create_string_buffer(WINDOW);C.memset(self.dst,0xa5,WINDOW);self.out=Args(1,2,3,4)
 def call(self):
  self.fbuf=C.create_string_buffer(bytes(self.fd));return F(self.fbuf,len(self.fd),self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),C.byref(self.out))
 def reject(self,rc):
  old=bytes(self.out);self.assertEqual(self.call(),rc);self.assertEqual(bytes(self.out),old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW);self.assertEqual(self.src.raw[:-1],PAYLOAD);self.assertEqual(self.fbuf.raw[:-1],bytes(self.fd))
 def test_real_kernel_valid(self):
  self.assertEqual(self.call(),0);RESULT['host_mapping_sha256']=check_mapping(self.dst.raw,PAYLOAD,REPORT,(self.out.entry,self.out.bootargs,self.out.bootargs+4096));self.assertEqual(self.fbuf.raw[:-1],bytes(self.fd))
 def test_bad_magic_no_write(self):self.fd[0]=0;self.reject(601)
 def test_extent_mismatch_no_write(self):self.s.input_fdt.size+=1;self.reject(506)
 def test_wrong_fdt_base_no_write(self):self.s.input_fdt.base+=4096;self.reject(506)
 def test_unknown_mblock_version_no_write(self):
  mb=fixture();struct.pack_into('<I',mb,3084,1);self.fd=fdt_fixture(mb);self.reject(501)
 def test_missing_mblock_no_write(self):self.fd=fdt_fixture(include=False);self.s.input_fdt.size=len(self.fd);self.reject(604)
 def test_duplicate_mblock_no_write(self):self.fd=fdt_fixture(duplicate=True);self.s.input_fdt.size=len(self.fd);self.reject(604)
 def test_reservation_conflict_no_write(self):self.fd=fdt_fixture(reservations=[(0x42000000,4096)]);self.s.input_fdt.size=len(self.fd);self.reject(605)
 def test_old_arbitrary_window_no_write(self):self.p.approved_window.base=0x90000000;self.reject(505)
 def test_invalid_structure_no_write(self):struct.pack_into('>I',self.fd,56,0xffffffff);self.reject(603)
 def test_bad_vectors_no_write(self):self.s.el1_vectors.base+=4;self.reject(402)
 def test_short_stack_no_write(self):self.s.el1_stack.size=8192;self.reject(402)
 def test_output_alias_fdt(self):
  self.fbuf=C.create_string_buffer(bytes(self.fd));old=self.fbuf.raw;rc=F(self.fbuf,len(self.fd),self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),C.cast(self.fbuf,C.POINTER(Args)));self.assertEqual(rc,301);self.assertEqual(self.fbuf.raw,old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
 def test_mapping_alias_fdt(self):
  rc=F(self.dst,len(self.fd),self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),C.byref(self.out));self.assertEqual(rc,301);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
 def test_output_alias_image(self):
  self.fbuf=C.create_string_buffer(bytes(self.fd));old=bytes(self.image);rc=F(self.fbuf,len(self.fd),self.src,len(PAYLOAD),C.byref(self.p),self.dst,WINDOW,C.byref(self.s),C.byref(self.image),C.cast(C.byref(self.image),C.POINTER(Args)));self.assertEqual(rc,301);self.assertEqual(bytes(self.image),old);self.assertEqual(self.dst.raw,b'\xa5'*WINDOW)
def main():
 global PAYLOAD,REPORT,F,RESULT
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();kernel=a.kernel.read_bytes();assert hashlib.sha256(kernel).hexdigest()==a.expect_sha256
 if a.out.exists():p.error('refusing existing output')
 a.out.mkdir(parents=True);PAYLOAD,REPORT=package_fixture(kernel,base=0x41200000,source=0x40090000,window=WINDOW)
 so=a.out.resolve()/'prepare-from-fdt.so';src=[R/'loader'/n for n in ['load.c','payload.c','metadata.c','prepare_boot.c','prepare_in_image.c','prepare_from_fdt.c','stage0_fdt_gate.c']]+[R/'platform'/n for n in ['handoff_contract.c','lk_arena.c','lk_fdt.c']]
 subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',('-dynamiclib' if platform.system()=='Darwin' else '-shared'),'-fPIC',*map(str,src),'-o',str(so)],check=True)
 lib=C.CDLL(str(so));F=lib.dandelion_prepare_from_fdt;F.argtypes=[C.c_void_p,C.c_size_t,C.c_void_p,C.c_size_t,C.POINTER(Policy),C.c_void_p,C.c_size_t,C.POINTER(Storage),C.POINTER(Range),C.POINTER(Args)];F.restype=C.c_int
 RESULT={'kernel_sha256':a.expect_sha256,'synthetic_only':True,'hardware_tested':False,'kernel_executed':False,'live_ownership_verified':False,'fdt_extraction_executed':True,'recovery_fallback':False}
 res=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));RESULT.update(host_prepare_from_fdt_tests=res.testsRun,all_passed=res.wasSuccessful());(a.out/'results.json').write_text(json.dumps(RESULT,indent=2)+'\n');print(json.dumps(RESULT,indent=2));raise SystemExit(0 if res.wasSuccessful() else 1)
if __name__=='__main__':main()
