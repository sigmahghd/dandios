#!/bin/sh
# SPDX-License-Identifier: MIT. Offline ELF only; NOT a phone image.
set -eu
cd "$(dirname "$0")/.."
: "${ZIG:=/data/dandelion-toolchain/ziglang/zig}"
for src in loader/load.c loader/payload.c loader/metadata.c loader/prepare_boot.c loader/prepare_in_image.c loader/prepare_from_fdt.c loader/stage0_fdt_gate.c platform/handoff_contract.c platform/lk_arena.c platform/lk_fdt.c; do
 name="$(basename "$src" .c)"
 "$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -std=c11 -mgeneral-regs-only -mstrict-align -ffreestanding -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror -c "$src" -o "tests/arena-$name-arm64.o"
done
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -c platform/handoff_el2.S -o tests/arena-handoff-arm64.o
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -c loader/stage0_fdt_gate.S -o tests/arena-stage0-gate-asm-arm64.o
"$ZIG" cc -target aarch64-freestanding-none -mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2 -nostdlib -Wl,-T,loader/module.ld -Wl,-e,dandelion_stage0_fdt_gate tests/arena-load-arm64.o tests/arena-payload-arm64.o tests/arena-metadata-arm64.o tests/arena-prepare_boot-arm64.o tests/arena-prepare_in_image-arm64.o tests/arena-prepare_from_fdt-arm64.o tests/arena-stage0_fdt_gate-arm64.o tests/arena-stage0-gate-asm-arm64.o tests/arena-handoff_contract-arm64.o tests/arena-lk_arena-arm64.o tests/arena-lk_fdt-arm64.o tests/arena-handoff-arm64.o -o tests/prepare-from-fdt-arm64.elf
