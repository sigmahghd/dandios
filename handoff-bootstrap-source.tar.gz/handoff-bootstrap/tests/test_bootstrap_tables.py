#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
import struct,unittest
from check_bootstrap_tables import walk,check
TCR=25|(25<<16)|(2<<30)
class WalkTests(unittest.TestCase):
 def setUp(self):
  self.mem={0x1000+8:0x2003,0x2000+9*8:0x41200401}
 def read(self,pa,n):
  if pa not in self.mem:raise ValueError('outside fixture')
  assert n==8
  return struct.pack('<Q',self.mem[pa])
 def low(self,va=0x41204123):return walk(self.read,0x1000,va,high=False,tcr=TCR)
 def test_low_block(self):self.assertEqual(self.low()['pa'],0x41204123)
 def test_leaf_level(self):self.assertEqual(self.low()['level'],2)
 def test_last_block_byte(self):self.assertEqual(self.low(0x413fffff)['pa'],0x413fffff)
 def test_invalid_root(self):
  self.mem[0x1008]=0
  with self.assertRaisesRegex(ValueError,'invalid descriptor'):self.low()
 def test_invalid_leaf(self):
  self.mem[0x2048]=0
  with self.assertRaisesRegex(ValueError,'invalid descriptor'):self.low()
 def test_unset_af(self):
  self.mem[0x2048]&=~1024
  with self.assertRaisesRegex(ValueError,'access flag'):self.low()
 def test_misaligned_block(self):
  self.mem[0x2048]|=4096
  with self.assertRaisesRegex(ValueError,'misaligned'):self.low()
 def test_unmapped_root_pointer(self):
  self.mem[0x1008]=0x3003
  with self.assertRaisesRegex(ValueError,'outside fixture'):self.low()
 def test_noncanonical_low(self):
  with self.assertRaisesRegex(ValueError,'noncanonical'):self.low(0x1000041204123)
 def test_unsupported_granule(self):
  with self.assertRaisesRegex(ValueError,'4K'):walk(self.read,0x1000,0x41204123,high=False,tcr=TCR|(1<<14))
 def test_high_block(self):
  va=0xfffffff007004123;self.mem={0x1000+((va>>30)&511)*8:0x2003,0x2000+((va>>21)&511)*8:0x41200401}
  self.assertEqual(walk(self.read,0x1000,va,high=True,tcr=TCR)['pa'],0x41204123)
 def test_high_canonical_required(self):
  with self.assertRaisesRegex(ValueError,'noncanonical'):walk(self.read,0x1000,0x7004123,high=True,tcr=TCR)
 def test_mismatch_report(self):
  c=check(self.read,{'ttbr0_el1':0x1000,'ttbr1_el1':0x1000,'tcr_el1':TCR},[('bad',0x41204123,0x41200123)])
  self.assertFalse(c['all_match'])
 def test_4k_page_leaf(self):
  self.mem[0x2048]=0x3003;self.mem[0x3020]=0x41204403
  self.assertEqual(self.low()['pa'],0x41204123)
if __name__=='__main__':unittest.main()
