# SPDX-License-Identifier: MIT
"""Independent bounded Armv8-A 4K stage-1 table walk; not a hardware MMU model."""
import struct
MASK48=(1<<48)-1

def walk(read,root,va,*,high,tcr):
 if (tcr>>14)&3!=0 or (tcr>>30)&3!=2:raise ValueError('only 4K TG0/TG1 supported')
 sz=(tcr>>(16 if high else 0))&63
 if not 16<=sz<=39:raise ValueError('unsupported VA width')
 width=64-sz;low=va&((1<<width)-1);signmask=((1<<64)-1)^((1<<width)-1)
 if (va&signmask)!=(signmask if high else 0):raise ValueError('noncanonical VA')
 level=4-((width-12+8)//9);table=root&MASK48&~4095;path=[]
 for lev in range(level,4):
  shift=12+9*(3-lev);address=table+((low>>shift)&511)*8;desc=struct.unpack('<Q',read(address,8))[0];path.append([address,desc])
  if not desc&1:raise ValueError('invalid descriptor')
  if lev<3 and desc&3==3:table=desc&MASK48&~4095;continue
  if lev==0 or (lev==3 and desc&3!=3) or (lev<3 and desc&3!=1):raise ValueError('invalid block/page level')
  blockmask=(1<<shift)-1
  if desc&MASK48&blockmask&~4095:raise ValueError('misaligned output address')
  if not desc&(1<<10):raise ValueError('access flag unset')
  return {'pa':(desc&MASK48&~blockmask)|(low&blockmask),'level':lev,'descriptor':desc,'path':path}
 raise ValueError('no leaf descriptor')

def check(read,cpu,points):
 rows=[]
 for name,va,expected in points:
  high=bool(va>>63)
  try:
   result=walk(read,cpu['ttbr1_el1' if high else 'ttbr0_el1'],va,high=high,tcr=cpu['tcr_el1']);rows.append({'name':name,'va':va,'expected_pa':expected,'matches':result['pa']==expected,**result})
  except ValueError as e:rows.append({'name':name,'va':va,'expected_pa':expected,'matches':False,'error':str(e)})
 return {'all_match':all(r['matches'] for r in rows),'points':rows,'scope':'Software walk of real XNU-generated tables; not hardware TLB/cache/permission execution'}
