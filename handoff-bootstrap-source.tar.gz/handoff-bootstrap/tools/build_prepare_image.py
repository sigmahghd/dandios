#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Build a complete, fixed-layout ARM64 PREPARE-ONLY Image. NOT Android Boot.
Embeds synthetic-test ADT/seed. Default prepare-only; opt-in handoff CPU model is NOT for phone use. No phone interaction.
Requires explicit experimental flag and caller-supplied pinned Zig 0.13.0.
"""
import argparse,gzip,hashlib,json,struct,subprocess,sys
from pathlib import Path
from pack_kernel_fixture import package_fixture,WINDOW
R=Path(__file__).resolve().parents[1]
HEAD=0x40080000;END=0x43210000
SOURCES=['loader/load.c','loader/payload.c','loader/metadata.c','loader/prepare_boot.c','loader/prepare_in_image.c','loader/prepare_from_fdt.c','loader/stage0_fdt_gate.c','platform/handoff_contract.c','platform/lk_arena.c','platform/lk_fdt.c','image/prepare.c']
def sha(b):return hashlib.sha256(b).hexdigest()
def elf_info(b):
 if b[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',b,18)[0]!=183:raise ValueError('need little-endian ELF64 AArch64')
 entry,ph,sh=struct.unpack_from('<QQQ',b,24);ps,pn,ss,sn,st=struct.unpack_from('<5H',b,54)
 if ps!=56 or ss!=64 or not 0<sn<128 or st>=sn or sh+sn*ss>len(b) or ph+pn*ps>len(b):raise ValueError('ELF tables')
 raw=[struct.unpack_from('<II4QII2Q',b,sh+i*ss) for i in range(sn)]
 def contents(s):
  off,size=s[4:6]
  if off>len(b) or size>len(b)-off:raise ValueError('ELF section bounds')
  return b[off:off+size]
 strings=contents(raw[st])
 def name(table,off):
  if off>=len(table) or table.find(b'\0',off)<0:raise ValueError('ELF string')
  return table[off:table.index(0,off)].decode('ascii')
 sections={name(strings,s[0]):s for s in raw};symbols={};undefined=[]
 for s in raw:
  if s[1]!=2:continue
  if s[6]>=sn or s[9]!=24 or s[5]%24:raise ValueError('ELF symbols')
  names=contents(raw[s[6]])
  for off in range(s[4],s[4]+s[5],24):
   no,info,other,index,value,size=struct.unpack_from('<IBBHQQ',b,off);n=name(names,no)
   if n:symbols[n]=value
   if n and index==0:undefined.append(n)
 if undefined:raise ValueError('undefined symbols: '+repr(undefined))
 segments=[]
 for i in range(pn):
  typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<II6Q',b,ph+i*ps)
  if typ==1:
   if fs>ms or off>len(b) or fs>len(b)-off or va<HEAD or va+ms>END:raise ValueError('ELF load outside private Image')
   segments.append({'base':va,'size':ms,'file_bytes':fs,'flags':flags})
 return entry,symbols,sections,segments

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--expect-sha256',required=True);p.add_argument('--zig',type=Path,required=True);p.add_argument('--out',type=Path,required=True);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--experimental-prepare-only',action='store_true');g.add_argument('--experimental-handoff-model-only',action='store_true');a=p.parse_args();model=a.experimental_handoff_model_only
 kernel=a.kernel.read_bytes()
 if sha(kernel)!=a.expect_sha256:p.error('kernel SHA256 mismatch')
 if a.out.exists():p.error('refusing existing output directory')
 zig=a.zig.resolve();version=subprocess.check_output([str(zig),'version'],text=True).strip()
 if version!='0.13.0':p.error('this recipe is validated only with Zig 0.13.0')
 payload,report=package_fixture(kernel,base=0x41200000,source=0x40090000,window=WINDOW,bootstrap_align_2m=model)
 if len(payload)>0x41200000-0x40090000:p.error('payload too large for fixed source region')
 out=a.out.resolve();out.mkdir(parents=True);(out/'payload.dxnu').write_bytes(payload)
 (out/'embedded.S').write_text('.section .payload,"a"\n.incbin '+json.dumps(str(out/'payload.dxnu'))+'\n')
 base=[str(zig),'cc','-target','aarch64-freestanding-none','-mcpu=cortex_a53-neon-fp_armv8-crypto-aes-sha2']
 cflags=['-std=c11','-mgeneral-regs-only','-mstrict-align','-ffreestanding','-fno-stack-protector','-fno-builtin','-fno-pic','-fno-pie','-O2','-Wall','-Wextra','-Werror']
 objects=[]
 with (out/'build.log').open('w') as log:
  def run(cmd):
   log.write('COMMAND '+repr(cmd)+'\n');log.flush();subprocess.run(cmd,check=True,cwd=R,stdout=log,stderr=subprocess.STDOUT)
  for i,src in enumerate(SOURCES):
   obj=out/('c'+str(i)+'.o');run(base+cflags+['-c',str(R/src),'-o',str(obj)]);objects.append(str(obj))
  asm=[R/'image/start.S',R/'loader/stage0_fdt_gate.S',out/'embedded.S']
  if model:asm.append(R/'platform/handoff_el2.S')
  for i,src in enumerate(asm):
   obj=out/('s'+str(i)+'.o');run(base+(['-DDANDELION_HANDOFF_MODEL_ONLY=1'] if model else [])+['-c',str(src),'-o',str(obj)]);objects.append(str(obj))
  stem='MODEL-ONLY-NOT-FOR-PHONE-handoff' if model else 'NOT-FLASHABLE-prepare-only'
  elf=out/('handoff-model.elf' if model else 'prepare-only.elf');raw=out/(stem+'.Image')
  run(base+['-nostdlib','-Wl,-e,_head','-Wl,-T,'+str(R/'image/prepare.ld'),'-Wl,--build-id=none',*objects,'-o',str(elf)])
  run([str(zig),'objcopy','-O','binary',str(elf),str(raw)])
 b=raw.read_bytes();entry,sym,sections,segments=elf_info(elf.read_bytes())
 if entry!=HEAD or sym['_head']!=HEAD or sym['_image_end']!=END or len(b)!=END-HEAD:raise ValueError('fixed Image extent/entry mismatch')
 if struct.unpack_from('<Q',b,16)[0]!=len(b) or b[56:60]!=b'ARM\x64' or struct.unpack_from('<Q',b,24)[0]!=0xa:raise ValueError('Image header')
 word=struct.unpack_from('<I',b)[0];imm=word&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm
 if word>>26!=5 or HEAD+imm*4!=sym['image_start']:raise ValueError('Image entry branch')
 if b[sym['_payload_start']-HEAD:sym['_payload_end']-HEAD]!=payload:raise ValueError('embedded payload mismatch')
 for start,end in [('_kernel_window_start','_kernel_window_end'),('_el1_stack_bottom','_el1_stack_top'),('_el2_stack_bottom','_el2_stack_top'),('_bss_start','_bss_end')]:
  if any(b[sym[start]-HEAD:sym[end]-HEAD]):raise ValueError('nonzero initial private workspace '+start)
 if sym['_el2_stack_top']>sym['_loader_end'] or sym['_loader_end']!=sym['_payload_start']:raise ValueError('EL2 prefix')
 gz=gzip.compress(b,compresslevel=9,mtime=0);(out/(stem+'.Image.gz')).write_bytes(gz)
 layout={'kind':('ARM64_HANDOFF_CPU_MODEL_ONLY_NOT_FOR_PHONE' if model else 'FIXED_ARM64_PREPARE_ONLY_IMAGE_NOT_ANDROID_BOOT'),'handoff_model_only':model,'prepare_only':not model,'flashable':False,'hardware_tested':False,'xnu_executed':False,'boot_entropy':False,'predictable_test_seed':True,'framebuffer_io':False,'storage_io':False,'compiler_version':version,'kernel_sha256':sha(kernel),'payload_sha256':sha(payload),'payload_bytes':len(payload),'image_sha256':sha(b),'image_bytes':len(b),'gzip_sha256':sha(gz),'gzip_bytes':len(gz),'entry':entry,'symbols':{k:v for k,v in sym.items() if k in ['_head','_image_end','_image_size','_loader_end','_payload_start','_payload_end','_kernel_window_start','_kernel_window_end','_el1_stack_bottom','_el1_stack_top','_el2_stack_bottom','_el2_stack_top','_bss_start','_bss_end','image_record','image_start','image_wait','image_main_return','image_el1_vectors','image_el2_vectors','image_early_fail','image_exception_el1','image_exception_el2','image_exception_park','image_start_asm_end','image_read_el','image_read_sctlr','image_read_hcr','image_read_mpidr','image_read_cntfrq','dandelion_enter_xnu_el2','handoff_eret','handoff_fail','handoff_park','handoff_read_el','handoff_read_sctlr','handoff_read_hcr','handoff_read_sre','handoff_read_sre_back','stage0_gate_el','stage0_gate_sctlr','stage0_gate_hcr','stage0_gate_fail','dandelion_stage0_fdt_gate']},'load_segments':segments,'payload_report':report}
 (out/'layout.json').write_text(json.dumps(layout,indent=2)+'\n')
 (out/'DO-NOT-FLASH.txt').write_text(('EMULATOR HANDOFF MODEL ONLY. Contains an ERET path; NOT for phone execution. Predictable seed, unverified hardware ABI/entropy/cache/GIC state. No Android Boot packaging. No phone interaction.\n' if model else 'PREPARE ONLY. NOT Android Boot or iOS. No ERET/XNU jump path. Fixed synthetic seed; no hardware test or boot validation. Do not use fastboot flash/boot with these raw Image/ELF files. No phone partitions were accessed.\n'))
 print(json.dumps({k:layout[k] for k in ['kind','kernel_sha256','image_bytes','image_sha256','gzip_bytes','prepare_only','hardware_tested']},indent=2))
if __name__=='__main__':main()
